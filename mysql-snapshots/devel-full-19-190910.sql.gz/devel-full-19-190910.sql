-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 20, 2010 at 12:25 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pierotof_sito2`
--

-- --------------------------------------------------------

--
-- Table structure for table `adv_chapters`
--

CREATE TABLE IF NOT EXISTS `adv_chapters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guide_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `chapter` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `context` longtext NOT NULL,
  `validated` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `adv_chapters`
--


-- --------------------------------------------------------

--
-- Table structure for table `adv_chapters1`
--

CREATE TABLE IF NOT EXISTS `adv_chapters1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guide_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `chapter` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `context` longtext NOT NULL,
  `validated` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=459 ;

--
-- Dumping data for table `adv_chapters1`
--


-- --------------------------------------------------------

--
-- Table structure for table `adv_guides`
--

CREATE TABLE IF NOT EXISTS `adv_guides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `descr` text NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adv_guides`
--

INSERT INTO `adv_guides` (`id`, `name`, `descr`, `admin_id`) VALUES
(1, 'Guida X', 'Prova di guida', 4);

-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_bans`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_bans` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ajax_chat_bans`
--


-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_invitations`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_invitations` (
  `userID` int(11) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ajax_chat_invitations`
--


-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_messages`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `text` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ajax_chat_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_online`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_online` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  KEY `userID` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ajax_chat_online`
--


-- --------------------------------------------------------

--
-- Table structure for table `algorithm`
--

CREATE TABLE IF NOT EXISTS `algorithm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `program_id_referer` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `context` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id_referer` (`program_id_referer`),
  KEY `module_name` (`module_name`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4347 ;

--
-- Dumping data for table `algorithm`
--


-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer_code` text,
  `answer_comment` text,
  `email_notify` varchar(255) DEFAULT NULL,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `answers`
--


-- --------------------------------------------------------

--
-- Table structure for table `approval_tutorials_votes`
--

CREATE TABLE IF NOT EXISTS `approval_tutorials_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tutorial_id` int(11) DEFAULT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=432 ;

--
-- Dumping data for table `approval_tutorials_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `approval_votes`
--

CREATE TABLE IF NOT EXISTS `approval_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9113 ;

--
-- Dumping data for table `approval_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `aptchat`
--

CREATE TABLE IF NOT EXISTS `aptchat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(60) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37538 ;

--
-- Dumping data for table `aptchat`
--


-- --------------------------------------------------------

--
-- Table structure for table `bad_queries`
--

CREATE TABLE IF NOT EXISTS `bad_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `page` varchar(255) NOT NULL,
  `stacktrace` text NOT NULL,
  `ip` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bad_queries`
--

INSERT INTO `bad_queries` (`id`, `query`, `timestamp`, `uid`, `page`, `stacktrace`, `ip`) VALUES
(1, 'SELECT COUNT(t.id) AS records\r\nFROM tutorials t\r\nINNER JOIN tutorials_categories c\r\nON c.dir_id = t.dir_id\r\nWHERE t.dir_id =  AND t.approved = 1', 1283644350, 0, '/pages/guide_tutorials/Google/', '	 at 0  C:\\wamp\\pierotofy.it\\trunk\\etc\\commonconf.php (line 228) -> getDebugBacktrace(\n)\n	 at 1  C:\\wamp\\pierotofy.it\\trunk\\pages\\guide_tutorials\\guide.php (line 125) -> exequery(SELECT COUNT(t.id) AS records\r\nFROM tutorials t\r\nINNER JOIN tutorials_categories c\r\nON c.dir_id = t.dir_id\r\nWHERE t.dir_id =  AND t.approved = 1)\nDebug backtrace end\n', '127.0.0.1'),
(2, 'SELECT fn.topic_id, fp.subject FROM forum_notifications fn, forum_posts fp WHERE\r\n	  fp.id = fn.topic_id AND\r\n	  fn.user_id = \r\n	  ORDER BY fn.id DESC', 1283644616, 0, '/pages/login/registerpass.php', '	 at 0  C:\\wamp\\pierotofy.it\\trunk\\etc\\commonconf.php (line 228) -> getDebugBacktrace(\n)\n	 at 1  C:\\wamp\\pierotofy.it\\trunk\\etc\\bottombar.php (line 154) -> exequery(SELECT fn.topic_id, fp.subject FROM forum_notifications fn, forum_posts fp WHERE\r\n	  fp.id = fn.topic_id AND\r\n	  fn.user_id = \r\n	  ORDER BY fn.id DESC)\n	 at 2  C:\\wamp\\pierotofy.it\\trunk\\etc\\footer.php (line 110) -> include(C:\\wamp\\pierotofy.it\\trunk\\etc\\bottombar.php)\n	 at 3  C:\\wamp\\pierotofy.it\\trunk\\etc\\interface.php (line 293) -> include(C:\\wamp\\pierotofy.it\\trunk\\etc\\footer.php)\n	 at 4  C:\\wamp\\pierotofy.it\\trunk\\pages\\login\\registerpass.php (line 197) -> close_pag()\nDebug backtrace end\n', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `bestbanner`
--

CREATE TABLE IF NOT EXISTS `bestbanner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `preference` varchar(255) NOT NULL DEFAULT '',
  `voter_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `bestbanner`
--


-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `image` blob,
  `size` int(11) DEFAULT '0',
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `blog`
--


-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE IF NOT EXISTS `blog_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(255) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=321 ;

--
-- Dumping data for table `blog_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `burningtools`
--

CREATE TABLE IF NOT EXISTS `burningtools` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `refer` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `filename` varchar(128) NOT NULL DEFAULT '',
  `size` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `burningtools`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_blocks`
--

CREATE TABLE IF NOT EXISTS `cache_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` blob NOT NULL,
  `block_id` varchar(40) NOT NULL,
  `expiration` int(11) NOT NULL DEFAULT '0',
  `dirty` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cache_blocks`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_pages`
--

CREATE TABLE IF NOT EXISTS `cache_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` blob NOT NULL,
  `group_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `page_num` int(11) NOT NULL DEFAULT '0',
  `expiration` int(11) NOT NULL DEFAULT '0',
  `dirty` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`,`page_id`),
  KEY `page_page` (`page_num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24243 ;

--
-- Dumping data for table `cache_pages`
--

INSERT INTO `cache_pages` (`id`, `content`, `group_id`, `page_id`, `page_num`, `expiration`, `dirty`) VALUES
(24241, 0x0d0a3c646976207374796c653d276261636b67726f756e642d636f6c6f723a20236565656565653b2070616464696e673a203470783b20626f726465723a2031707820736f6c69642023636330303030273e496c206e756f766f20706965726f746f66792e697420e820696e206661736520646920626574612074657374696e6721200d0a51756573746f2076756f6c206469726520636865206572726f7269206f206d616c66756e7a696f6e616d656e746920706f747265626265726f206573736572652070726573656e74692e2041697574616369206120636f7272656767657265206920706f73736962696c69206572726f7269207365676e616c616e646f20696c2070726f626c656d610d0a6e656c6c612073657a696f6e65203c6120687265663d272f70616765732f6578747261732f666f72756d2f3537322f273e466565646261636b733c2f613e2064656c20666f72756d21204772617a6965213c2f6469763e3c62722f3e0d0a0d0a3c64697620636c6173733d27626c6f636b20726967687420616473273e0d0a093c64697620636c6173733d27626c6f636b48656164657220616473273e0d0a093c696d67207372633d272f646174612f696d616765732f6970686f6e6532302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d276950686f6e65272f3e0d0a093c623e5376696c75707061746f7269206950686f6e65213c2f623e0d0a093c2f6469763e0d0a093c64697620636c6173733d2774657874273e0d0a09094c273c6120687265663d27687474703a2f2f7777772e696e64696561707073616c6c69616e63652e6f7267273e496e646965204170707320416c6c69616e63653c2f613e20e820756e61206e756f7661206f7267616e697a7a617a696f6e6520666f6e64617461206461203c6120687265663d272f70616765732f6d656d626572732f70726f66696c652e7068703f6e69636b6e616d653d506965726f253230546f6679273e506965726f20546f66793c2f613e20706572206f666672697265200d0a090961676c69207376696c75707061746f7269206e756f7669206d6f6469207065722070726f6d756f76657265206c652070726f7072696520617070732e200d0a093c2f6469763e0d0a3c2f6469763e0d0a0d0a0d0a0d0a3c64697620636c6173733d27696e646578486561646572273e0d0a093c683220636c6173733d27736974655469746c65273e42656e76656e75746f20737520506965726f546f66792e69743c2f68323e0d0a093c6120687265663d272f70616765732f70726f6772616d6d692f273e50726f6772616d6d693c2f613e2c203c6120687265663d272f70616765732f67756964655f7475746f7269616c732f273e61727469636f6c693c2f613e2c203c6120687265663d272f70616765732f6578747261732f666f72756d2f273e64697363757373696f6e693c2f613e2065203c6120687265663d272f70616765732f686f6d652f73686f775f6e6577735f617263686976652e706870273e6e6577733c2f613e2073756c6c27696e666f726d6174696361202d20747574746f20696e20756e612064656c6c65203c6120687265663d272f70616765732f636f6e637461742f77686f2e706870273e436f6d756e6974e03c2f613e2073756c6c612070726f6772616d6d617a696f6e65207069f9206772616e64692064274974616c69612e200d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27636c656172273e3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b2066656564732072696768742067726f757031273e0d0a093c64697620636c6173733d27626c6f636b48656164657220666565647327203e0d0a09093c696d67207372633d272f646174612f696d616765732f666565646172726f7732302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d274665656473272f3e203c623e41747469766974e020726563656e746920646569203c6120687265663d272f70616765732f6d656d626572732f6d656d626572732e706870273e6d656d6272693c2f613e3c2f623e0d0a093c2f6469763e0d0a093c2f6469763e0d0a0d0a0d0a3c64697620636c6173733d27626c6f636b206e6577732067726f757031273e0d0a093c64697620636c6173733d27626c6f636b486561646572206e657773273e0d0a09093c696d67207372633d272f646174612f696d616765732f776f726c6432302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d274e6577732064616c206d6f6e646f272f3e203c623e4e6577732064616c206d6f6e646f2064656c6c27696e666f726d61746963613c2f623e0d0a093c2f6469763e0d0a090d0a093c756c3e0d0a09093c2f756c3e0d0a093c64697620636c6173733d27626c6f636b466f6f746572206e657773273e0d0a093c6120687265663d272f70616765732f6578747261732f6e6577736f6e796f7572736974652f6e6577732e706870273e41676769756e67693c2f613e20717565737465206e65777320616c2074756f207369746f206f707075726520677561726461203c6120687265663d272f70616765732f686f6d652f73686f775f6e6577735f617263686976652e706870273e6c27617263686976696f3c2f613e0d0a093c2f6469763e0d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27636c656172273e3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b2072616e646f6d70726f6772616d2067726f757032207269676874273e0d0a093c64697620636c6173733d27626c6f636b4865616465722072616e646f6d70726f6772616d273e0d0a09093c696d67207372633d272f646174612f696d616765732f70726f6772616d32302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d2750726f6772616d6d612061206361736f272f3e203c623e50726f6772616d6d692061206361736f3c2f623e0d0a093c2f6469763e0d0a090d0a09090d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b20666f72756d2067726f757032273e0d0a093c64697620636c6173733d27626c6f636b48656164657220666f72756d273e0d0a09093c696d67207372633d272f646174612f696d616765732f646f63756d656e7432302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d27466f72756d20746f70696373272f3e203c623e556c74696d6920746f7069637320617065727469206e656c203c6120687265663d272f70616765732f6578747261732f666f72756d2f273e666f72756d3c2f613e3c2f623e0d0a093c2f6469763e0d0a0d0a093c756c20636c6173733d27706f696e746564273e0d0a09093c2f756c3e0d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27636c656172273e3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b2070726f6a65637473206c6566742067726f757033273e0d0a093c64697620636c6173733d27626c6f636b4865616465722070726f6a65637473273e0d0a09093c696d67207372633d272f646174612f696d616765732f746f6f6c7332302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d2750726f6765747469272f3e203c623e556c74696d69203c6120687265663d272f70616765732f70726f6a656374732f73756d6d6172792e706870273e70726f67657474693c2f613e3c2f623e0d0a093c2f6469763e0d0a0d0a093c756c20636c6173733d27706f696e746564273e0d0a09093c2f756c3e0d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b2070726f6772616d73206c6566742067726f757033273e0d0a093c64697620636c6173733d27626c6f636b4865616465722070726f6772616d73273e0d0a09093c696d67207372633d272f646174612f696d616765732f636f6e736f6c6532302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d27466f72756d20746f70696373272f3e203c623e556c74696d69203c6120687265663d272f70616765732f70726f6772616d6d692f273e70726f6772616d6d693c2f613e3c2f623e0d0a093c2f6469763e0d0a0d0a093c756c20636c6173733d27706f696e746564273e0d0a09093c2f756c3e0d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b207475746f7269616c73206c6566742067726f757033273e0d0a093c64697620636c6173733d27626c6f636b486561646572207475746f7269616c73273e0d0a09093c696d67207372633d272f646174612f696d616765732f70617065725f70656e63696c32302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d2741727469636f6c69272f3e203c623e556c74696d69203c6120687265663d272f70616765732f67756964655f7475746f7269616c732f273e61727469636f6c693c2f613e3c2f623e0d0a093c2f6469763e0d0a0d0a093c756c20636c6173733d27706f696e746564273e0d0a09093c2f756c3e0d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27636c656172273e3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b20737570706f72742067726f757034207269676874273e0d0a093c64697620636c6173733d27626c6f636b48656164657220737570706f7274273e0d0a09093c696d67207372633d272f646174612f696d616765732f6561676c6532302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d27537570706f7274616369272f3e203c623e3c6120687265663d272f70616765732f737570706f72746163692e706870273e537570706f7274613c2f613e206c6120436f6d6d756e6974793c2f623e0d0a093c2f6469763e0d0a0d0a093c64697620636c6173733d2774657874273e51756573746f207369746f20666f726e6973636520756e206772616e20617263686976696f206469207269736f7273652073756c6c612070726f6772616d6d617a696f6e652061206e657373756e20636f73746f2e2053636f70726920696e20636865206d6f646f2070756f69203c6120687265663d272f70616765732f737570706f72746163692e706870273e737570706f72746172653c2f613e20696c206e6f7374726f206c61766f726f2065206c61206e6f7374726120436f6d6d756e6974792e0d0a09506572206661722066726f6e746520616920636f737469206469206d616e7574656e7a696f6e65206520646920686f7374696e6720636f6e66696469616d6f20616e636865206e656c20737570706f72746f2064656c6c6520706572736f6e6520636f6d652074652e200d0a093c2f6469763e0d0a3c2f6469763e0d0a0d0a3c64697620636c6173733d27626c6f636b20626c6f672067726f757034273e0d0a093c64697620636c6173733d27626c6f636b48656164657220626c6f67273e0d0a09093c696d67207372633d272f646174612f696d616765732f626c6f6732302e706e6727207374796c653d27766572746963616c2d616c69676e3a206d6964646c652720616c743d27426c6f67272f3e203c623e556c74696d6920696e74657276656e74692064616c203c6120687265663d272f70616765732f626c6f672f273e626c6f673c2f613e3c2f623e0d0a093c2f6469763e0d0a0d0a093c756c20636c6173733d27706f696e746564273e0d0a09093c2f756c3e0d0a3c2f6469763e0d0a0d0a3c62722f3e0d0a3c666f6e7420636c6173733d27736d616c6c273e224c61207363756f6c612064656c6c276f62626c69676f206974616c69616e61206e6f6e206661766f7269736365206c6f2073747564696f2064656c6c612070726f6772616d6d617a696f6e652c206465692063616c636f6c61746f72692c2064656c6c6520726574692c20636f6d652061767669656e65200d0a696e76656365206e6569207061657369207069f9207376696c75707061746920636f6d65205553412065204765726d616e69612e2051756573746f20706f6e65206c274974616c696120696e20756e6f20737461746f206469206172726574726174657a7a612065206e6f69207369616d6f207175692070657220666172652063696f27200d0a636865206e6f6e207669656e6520666174746f2064616c6c6f20537461746f2e2e2e20617070617373696f6e61726520692067696f76616e692074616c656e746920737520717565737461206d61746572696120616666617363696e616e74652c20636f6e66726f6e7461726520696465652065207376696c757070617265200d0a696e7369656d65206170706c6963617a696f6e692070726f66657373696f6e616c6920616c2066696e652064692063726561726520756e61206772616e646520636f6d756e6974e02e223c62722f3e3c62722f3e0d0a0d0a3c7370616e207374796c653d27666c6f61743a2072696768743b273e3c6120687265663d27687474703a2f2f6c6f63616c686f73742f70616765732f6d61702e68746d6c273e3c696d67207372633d272f646174612f696d616765732f6d617031362e6769662720616c743d274d617070612064656c207369746f27202f3e3c2f613e203c6120687265663d272f70616765732f7365617263682f73656172636865732e706870273e3c696d67207372633d272f646174612f696d616765732f73656172636831362e6769662720616c743d27526963657263686527202f3e3c2f613e3c2f7370616e3e0d0a436f6e636f7264693f20446976656e74612066616e2064656c6c61206e6f7374726120696e697a696174697661207375203c6120687265663d27687474703a2f2f7777772e66616365626f6f6b2e636f6d2f686f6d652e7068703f23212f67726f75702e7068703f6769643d313436303733333435343231333135267265663d7473273e46616365626f6f6b3c2f613e210d0a3c2f666f6e743e3c7363726970743e0d0a66756e6374696f6e20646f4e65777353756d6d61727928756964297b0d0a097661722072656f70656e203d2066616c73653b0d0a097661722073756d6d617279203d20246a2827236e6577735f73756d6d6172795f27202b20756964293b0d0a096966202873756d6d6172792e697328273a76697369626c652729292072656f70656e203d20747275653b0d0a09246a28272e6e65777353756d6d61727927292e6869646528293b090d0a096966202872656f70656e292073756d6d6172792e73686f7728293b0d0a0d0a0d0a090d0a0973756d6d6172792e736c696465546f67676c6528323530293b090d0a7d0d0a0d0a657175616c48656967687428246a28222e67726f7570312229293b0d0a657175616c48656967687428246a28222e67726f7570322229293b0d0a657175616c48656967687428246a28222e67726f7570332229293b0d0a657175616c48656967687428246a28222e67726f7570342229293b0d0a0d0a246a28272e626c6f636b27292e636f726e6572282733707827293b0d0a246a28272e626c6f636b48656164657227292e636f726e65722827746f702033707827293b0d0a246a28272e626c6f636b466f6f74657227292e636f726e65722827626f74746f6d2033707827293b0d0a0d0a3c2f7363726970743e0d0a, 0, 0, 0, 1284264861, 1),
(24242, 0x3c64697620616c69676e3d2763656e746572273e3c7461626c6520626f726465723d30206267636f6c6f723d236565656565652077696474683d313030253e3c74723e3c7464206267636f6c6f723d23444545334537207374796c653d2777696474683a20343070783b273e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e4465736372697074696f6e3c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e546f706963733c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e506f7374733c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e4c61737420506f73743c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e4d6f64657261746f72733c2f666f6e743e3c2f74643e3c2f74723e3c2f7461626c653e, 1, 0, 0, 1284943372, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `mail` varchar(64) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `date` varchar(19) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=606 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `compilers`
--

CREATE TABLE IF NOT EXISTS `compilers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL DEFAULT '',
  `descrizione` text NOT NULL,
  `filename` varchar(128) NOT NULL DEFAULT '',
  `size` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `compilers`
--


-- --------------------------------------------------------

--
-- Table structure for table `copypastebin`
--

CREATE TABLE IF NOT EXISTS `copypastebin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` longtext NOT NULL,
  `language` varchar(100) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `cid` varchar(100) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `copypastebin`
--


-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE IF NOT EXISTS `counter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `browser` varchar(255) NOT NULL DEFAULT '',
  `referer` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `counter`
--


-- --------------------------------------------------------

--
-- Table structure for table `counter_old`
--

CREATE TABLE IF NOT EXISTS `counter_old` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL,
  `os_browser` varchar(255) DEFAULT NULL,
  `heures` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `counter_old`
--


-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=244 ;

--
-- Dumping data for table `countries`
--


-- --------------------------------------------------------

--
-- Table structure for table `daily_ip_accesses`
--

CREATE TABLE IF NOT EXISTS `daily_ip_accesses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `daily_ip_accesses`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloads_count`
--

CREATE TABLE IF NOT EXISTS `downloads_count` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(128) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `program_name` (`program_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3489 ;

--
-- Dumping data for table `downloads_count`
--


-- --------------------------------------------------------

--
-- Table structure for table `external_urls`
--

CREATE TABLE IF NOT EXISTS `external_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18606 ;

--
-- Dumping data for table `external_urls`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_arguments`
--

CREATE TABLE IF NOT EXISTS `forum_arguments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `root` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `moderators` varchar(255) DEFAULT NULL,
  `private` int(1) unsigned NOT NULL DEFAULT '0',
  `priority` int(11) DEFAULT NULL,
  `developers_only` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=640 ;

--
-- Dumping data for table `forum_arguments`
--

INSERT INTO `forum_arguments` (`id`, `root`, `title`, `subject`, `moderators`, `private`, `priority`, `developers_only`) VALUES
(638, 'Categoria', 'Forum 1', 'Forum di esempio #1', 'Piero Tofy', 0, 10, 0),
(639, 'Categoria', 'Forum 2', 'Forum di esempio #2', 'Piero Tofy', 0, 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `forum_arguments_old`
--

CREATE TABLE IF NOT EXISTS `forum_arguments_old` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `root` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `moderators` varchar(255) DEFAULT NULL,
  `private` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=542 ;

--
-- Dumping data for table `forum_arguments_old`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_notifications`
--

CREATE TABLE IF NOT EXISTS `forum_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `notify_tm` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_id` (`topic_id`,`user_id`,`notify_tm`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forum_notifications`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_notifications_add_list`
--

CREATE TABLE IF NOT EXISTS `forum_notifications_add_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forum_notifications_add_list`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_notifications_skip_list`
--

CREATE TABLE IF NOT EXISTS `forum_notifications_skip_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forum_notifications_skip_list`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_poll`
--

CREATE TABLE IF NOT EXISTS `forum_poll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_id` (`topic_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8052 ;

--
-- Dumping data for table `forum_poll`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_posts`
--

CREATE TABLE IF NOT EXISTS `forum_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(9) NOT NULL DEFAULT '0',
  `argument` int(9) NOT NULL DEFAULT '0',
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext,
  `type` int(1) NOT NULL DEFAULT '0',
  `root_topic` varchar(255) DEFAULT NULL,
  `post_date` int(9) DEFAULT '0',
  `edit_date` int(9) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `locked` int(1) DEFAULT NULL,
  `show_as` int(1) NOT NULL DEFAULT '0',
  `last_post_date` int(9) NOT NULL DEFAULT '0',
  `edit_by` int(9) NOT NULL DEFAULT '0',
  `notifies_list` text,
  `attachment_filename` varchar(255) DEFAULT NULL,
  `attachment_data` longblob,
  `attachment_size` int(11) DEFAULT NULL,
  `attachment_type` varchar(255) DEFAULT NULL,
  `poll` varchar(1200) DEFAULT NULL,
  `show_poll_in_menu` tinyint(4) DEFAULT '0',
  `question` tinyint(1) DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `best` tinyint(1) NOT NULL DEFAULT '0',
  `replies` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `argument` (`argument`),
  KEY `user_id` (`user_id`),
  KEY `root_topic` (`root_topic`),
  KEY `type` (`type`),
  KEY `show_poll_in_menu` (`show_poll_in_menu`),
  FULLTEXT KEY `subject` (`subject`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1015049 ;

--
-- Dumping data for table `forum_posts`
--

INSERT INTO `forum_posts` (`id`, `user_id`, `argument`, `subject`, `message`, `type`, `root_topic`, `post_date`, `edit_date`, `ip`, `locked`, `show_as`, `last_post_date`, `edit_by`, `notifies_list`, `attachment_filename`, `attachment_data`, `attachment_size`, `attachment_type`, `poll`, `show_poll_in_menu`, `question`, `score`, `best`, `replies`) VALUES
(1015047, 8, 638, 'Primo post', 'Esempio di post', 0, NULL, 1284945343, NULL, '127.0.0.1', 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL),
(1015048, 8, 639, 'Secondo post', 'Esempio di post', 0, NULL, 1284945343, NULL, '127.0.0.1', 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `forum_reports`
--

CREATE TABLE IF NOT EXISTS `forum_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_id` (`forum_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=465 ;

--
-- Dumping data for table `forum_reports`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_scores`
--

CREATE TABLE IF NOT EXISTS `forum_scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `voted_post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `voted_post_id` (`voted_post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=215 ;

--
-- Dumping data for table `forum_scores`
--


-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `banner_url` varchar(255) NOT NULL DEFAULT '',
  `approved` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `approved` (`approved`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=92 ;

--
-- Dumping data for table `friends`
--


-- --------------------------------------------------------

--
-- Table structure for table `hosts`
--

CREATE TABLE IF NOT EXISTS `hosts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `target` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `hosts`
--


-- --------------------------------------------------------

--
-- Table structure for table `images_upload`
--

CREATE TABLE IF NOT EXISTS `images_upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `data` longblob,
  `size` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `images_upload`
--


-- --------------------------------------------------------

--
-- Table structure for table `join_requests`
--

CREATE TABLE IF NOT EXISTS `join_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `born_date` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `date` varchar(50) NOT NULL DEFAULT '',
  `motivation` text,
  `program_name` varchar(255) NOT NULL DEFAULT '',
  `program_data` longblob NOT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '',
  `passport` varchar(255) NOT NULL DEFAULT '',
  `agreed` tinyint(4) NOT NULL DEFAULT '0',
  `refused_because` text,
  `handled_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `handled_by` (`handled_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1028 ;

--
-- Dumping data for table `join_requests`
--


-- --------------------------------------------------------

--
-- Table structure for table `jokes`
--

CREATE TABLE IF NOT EXISTS `jokes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `jokes`
--


-- --------------------------------------------------------

--
-- Table structure for table `library_books`
--

CREATE TABLE IF NOT EXISTS `library_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '',
  `author` varchar(100) NOT NULL DEFAULT '',
  `pags` int(11) NOT NULL DEFAULT '0',
  `year` int(11) NOT NULL DEFAULT '0',
  `rate` int(11) NOT NULL DEFAULT '0',
  `available` tinyint(1) DEFAULT '1',
  `original_owner` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=107 ;

--
-- Dumping data for table `library_books`
--


-- --------------------------------------------------------

--
-- Table structure for table `library_feedbacks`
--

CREATE TABLE IF NOT EXISTS `library_feedbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_id` int(11) NOT NULL DEFAULT '0',
  `sender_id` int(11) NOT NULL DEFAULT '0',
  `rate` int(11) NOT NULL DEFAULT '0',
  `operation_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `library_feedbacks`
--


-- --------------------------------------------------------

--
-- Table structure for table `library_operations`
--

CREATE TABLE IF NOT EXISTS `library_operations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `book_wanted` int(11) NOT NULL DEFAULT '0',
  `book_exchanged` int(11) DEFAULT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `agreed` int(11) NOT NULL DEFAULT '0',
  `closed` int(11) NOT NULL DEFAULT '0',
  `price_offert` varchar(100) DEFAULT NULL,
  `starter_id` int(11) NOT NULL DEFAULT '0',
  `receiver_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `library_operations`
--


-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE IF NOT EXISTS `links` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `links`
--


-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112463 ;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `ip`, `timestamp`, `user_id`, `text`) VALUES
(112455, '127.0.0.1', 1283644565, 8, 'pierotofy (8) effettua il login'),
(112456, '127.0.0.1', 1283644674, 17008, 'utente (17008) effettua il login'),
(112457, '127.0.0.1', 1283644689, 17008, 'utente (17008) effettua il login'),
(112458, '127.0.0.1', 1283646310, 8, 'pierotofy (8) effettua il login'),
(112459, '127.0.0.1', 1283648376, 8, 'Creata nuova guida: Guida X'),
(112460, '127.0.0.1', 1283648406, 8, 'Creata nuova guida: Guida X'),
(112461, '127.0.0.1', 1284251700, 8, 'pierotofy (8) effettua il login'),
(112462, '127.0.0.1', 1284261274, 8, 'pierotofy (8) effettua il login');

-- --------------------------------------------------------

--
-- Table structure for table `medals`
--

CREATE TABLE IF NOT EXISTS `medals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `medals`
--


-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `description` longtext,
  `age` varchar(10) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `born_date` int(11) DEFAULT NULL,
  `last_login` varchar(30) DEFAULT NULL,
  `is_founder` char(1) DEFAULT NULL,
  `interests` varchar(255) DEFAULT NULL,
  `employ` varchar(255) DEFAULT NULL,
  `icq` varchar(255) DEFAULT NULL,
  `msn` varchar(255) DEFAULT NULL,
  `aim` varchar(255) DEFAULT NULL,
  `yahoo` varchar(255) DEFAULT NULL,
  `web` varchar(255) DEFAULT NULL,
  `medals` varchar(255) DEFAULT NULL,
  `review_message_shown` tinyint(1) DEFAULT '0',
  `library_disclaimer_shown` tinyint(4) DEFAULT '0',
  `personal_info` text,
  `real_name` varchar(255) DEFAULT NULL,
  `real_surname` varchar(255) DEFAULT NULL,
  `working_exp` text,
  `reunion_pass` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `email_activated` int(11) DEFAULT '0',
  `webhost_activated` tinyint(4) DEFAULT '0',
  `webhost_pass` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=501 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `nickname`, `description`, `age`, `location`, `mail`, `image`, `born_date`, `last_login`, `is_founder`, `interests`, `employ`, `icq`, `msn`, `aim`, `yahoo`, `web`, `medals`, `review_message_shown`, `library_disclaimer_shown`, `personal_info`, `real_name`, `real_surname`, `working_exp`, `reunion_pass`, `skype`, `email_activated`, `webhost_activated`, `webhost_pass`, `twitter`) VALUES
(4, 'Piero Tofy', 'Analista e programmatore C, C++, Java (con conoscenze avanzate sulla crittografia e sullo sviluppo di applicazioni per dispositivi portatili), Delphi, Visual Basic 6 e Php. Ho anche solide basi di VB.NET, C#, Javascript, Html, Pascal, Assembly x86 e MIPS, Python, PL/SQL, Perl, Ruby e Objective-C. Conosco le basi di Ruby on Rails e quelle sull''uso dei Web Services, possiedo una discreta conoscenza sul Reverse Engineering, conosco le librerie MFC, Managed DirectX e le OpenGL. Padroneggio discretamente il programma di modeling 3D Blender, Adobe Photoshop CS2 e Adobe Flash MX. Da marzo 2009 ho cominciato a sviluppare per l''iPhone/iTouch e subito dopo ho iniziato a sviluppare per Android. Ho una buona conoscenza nell''uso di Drupal.', '16', 'Duluth, MN', 'admin@pierotofy.it', 'pierotofy_piero.png', 607903200, '12/09/2010 3:14', '1', 'Hockey su ghiaccio, pallavolo, camminate in montagna, programmazione e aikido.', 'Studente', '318386970', '', '', '', 'http://www.pierotofy.it', '|4çMedaglia per il progetto Multiplayer Poker||2çMedaglia al vincitore della 3° edizione per il miglior banner del sito.|', 1, 1, 'PieroçToffaninçAmericaçDuluthç12345çBrainerd Aveç2187286412', 'Piero', 'Toffanin', 'Lavorato per l''azienda Info-Synergy nella costruzione di una libreria crittografica.\r\nLavorato per Icslab.it nella costruzione di un applicativo per la memorizzazione, gestione e stampa di cedolini.\r\nLavorato per 3 settimane come stagista alla Euris Solutions S.p.A. dove ho svolto un lavoro di ricerca sulla tecnologia Silverlight.\r\nHo sviluppato il gioco 3D Tunnel per l''iPhone (www.3dtunnelonline.com)\r\nLavoro come sviluppatore e amministratore server per il dipartimento di Business ed Economia all''University of Minnesota Duluth.\r\nHo sviluppato l''app "Pro Card Counter" per Android (www.procardcounter.indieappsalliance.org)\r\n', 'k8s19AP5', '', 1, 1, NULL, 'pierotofy');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_tm` int(11) NOT NULL,
  `viewed` tinyint(1) NOT NULL DEFAULT '0',
  `important` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `from_id` (`from_id`),
  KEY `to_id` (`to_id`),
  KEY `viewed` (`viewed`),
  KEY `deleted` (`deleted`),
  KEY `multiple` (`multiple`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `messenger`
--

CREATE TABLE IF NOT EXISTS `messenger` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `msgfrom_id` varchar(255) DEFAULT NULL,
  `msgto_id` varchar(255) DEFAULT NULL,
  `message` longtext,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `msgfrom_id` (`msgfrom_id`),
  KEY `msgto_id` (`msgto_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19445 ;

--
-- Dumping data for table `messenger`
--


-- --------------------------------------------------------

--
-- Table structure for table `midi`
--

CREATE TABLE IF NOT EXISTS `midi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `artist` varchar(255) DEFAULT NULL,
  `song` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18883 ;

--
-- Dumping data for table `midi`
--


-- --------------------------------------------------------

--
-- Table structure for table `most_visited`
--

CREATE TABLE IF NOT EXISTS `most_visited` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(255) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=200 ;

--
-- Dumping data for table `most_visited`
--


-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `small_text` text NOT NULL,
  `full_text` longtext NOT NULL,
  `data` bigint(20) NOT NULL DEFAULT '0',
  `read_count` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `refer` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5591 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `small_text`, `full_text`, `data`, `read_count`, `member_id`, `refer`) VALUES
(5590, 'News di esempio', 'Questo è il paragrafo di una news.', '<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>', 1284941544, 1, 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6066 ;

--
-- Dumping data for table `newsletter`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_queue`
--

CREATE TABLE IF NOT EXISTS `newsletter_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `body` text NOT NULL,
  `type` int(11) NOT NULL,
  `headers` text NOT NULL,
  `resume_from` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `newsletter_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `news_comments`
--

CREATE TABLE IF NOT EXISTS `news_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `news_id` (`news_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `news_comments`
--

INSERT INTO `news_comments` (`id`, `news_id`, `user_id`, `comment`, `ip`, `timestamp`) VALUES
(1, 5590, 8, 'Commento news!', '127.0.0.1', 1284941564);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `notifications`
--


-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8646602 ;

--
-- Dumping data for table `online`
--

INSERT INTO `online` (`id`, `ip`, `timestamp`, `user_id`) VALUES
(8646601, '127.0.0.1', 1284942196, 8);

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE IF NOT EXISTS `partners` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `partner_name` varchar(255) DEFAULT NULL,
  `partner_url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `top` tinyint(1) DEFAULT '0',
  `position` int(11) DEFAULT '99',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

--
-- Dumping data for table `partners`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll`
--

CREATE TABLE IF NOT EXISTS `poll` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `vote_id` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2805 ;

--
-- Dumping data for table `poll`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll_questions`
--

CREATE TABLE IF NOT EXISTS `poll_questions` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `poll_questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE IF NOT EXISTS `programs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `program_name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `programmer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `categoria` varchar(64) NOT NULL DEFAULT '',
  `pro_votes` int(11) DEFAULT '0',
  `cons_votes` int(11) DEFAULT '0',
  `approved` int(11) DEFAULT '0',
  `screenshot_filename` varchar(255) DEFAULT NULL,
  `rates_score` float DEFAULT '0',
  `rates_count` int(11) DEFAULT '0',
  `comments` int(11) DEFAULT '0',
  `website` varchar(255) DEFAULT NULL,
  `long_description` text,
  `support_windows` tinyint(1) DEFAULT '1',
  `support_linux` tinyint(1) DEFAULT '0',
  `support_mac` tinyint(1) DEFAULT '0',
  `support_bsd` tinyint(1) DEFAULT '0',
  `timestamp` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `approved` (`approved`),
  KEY `programmer` (`programmer`),
  KEY `screenshot_filename` (`screenshot_filename`),
  KEY `program_name` (`program_name`),
  KEY `type` (`type`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18741 ;

--
-- Dumping data for table `programs`
--


-- --------------------------------------------------------

--
-- Table structure for table `programs_categories`
--

CREATE TABLE IF NOT EXISTS `programs_categories` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `descr` varchar(64) NOT NULL DEFAULT '',
  `descr_long` varchar(255) DEFAULT NULL,
  `congiunzione` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `programs_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `programs_comments`
--

CREATE TABLE IF NOT EXISTS `programs_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id` (`program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `programs_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `admins` text NOT NULL,
  `developers` text NOT NULL,
  `recruitment` varchar(128) NOT NULL DEFAULT '',
  `os` varchar(128) NOT NULL DEFAULT '',
  `license` varchar(128) NOT NULL DEFAULT '',
  `programming_languages` varchar(128) NOT NULL DEFAULT '',
  `creation_date` varchar(128) NOT NULL DEFAULT '',
  `forum_id` int(11) NOT NULL DEFAULT '0',
  `releases_count` int(11) NOT NULL DEFAULT '0',
  `svn_requested` int(11) DEFAULT '0',
  `svn_repname` varchar(255) DEFAULT NULL,
  `svn_pass` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `svn_requested` (`svn_requested`),
  KEY `name` (`name`),
  KEY `programming_languages` (`programming_languages`),
  KEY `forum_id` (`forum_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=553 ;

--
-- Dumping data for table `projects`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects_bugs`
--

CREATE TABLE IF NOT EXISTS `projects_bugs` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `submitted_by` varchar(128) NOT NULL DEFAULT '',
  `fixed` int(1) NOT NULL DEFAULT '0',
  `priority` int(5) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `fixed` (`fixed`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=202 ;

--
-- Dumping data for table `projects_bugs`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects_files`
--

CREATE TABLE IF NOT EXISTS `projects_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `size` bigint(20) NOT NULL DEFAULT '0',
  `version` varchar(20) NOT NULL DEFAULT '',
  `release_date` varchar(128) NOT NULL DEFAULT '',
  `notes` text NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT '',
  `release_require` text NOT NULL,
  `owner` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1602 ;

--
-- Dumping data for table `projects_files`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects_todo`
--

CREATE TABLE IF NOT EXISTS `projects_todo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '0',
  `sender` varchar(10) NOT NULL DEFAULT '',
  `assigned_to` varchar(10) NOT NULL DEFAULT '',
  `date` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=570 ;

--
-- Dumping data for table `projects_todo`
--


-- --------------------------------------------------------

--
-- Table structure for table `query_stats`
--

CREATE TABLE IF NOT EXISTS `query_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` varchar(255) DEFAULT NULL,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=536710 ;

--
-- Dumping data for table `query_stats`
--


-- --------------------------------------------------------

--
-- Table structure for table `quiz_attempts`
--

CREATE TABLE IF NOT EXISTS `quiz_attempts` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `mail` varchar(128) NOT NULL DEFAULT '',
  `language` varchar(128) NOT NULL DEFAULT '',
  `rank` int(2) NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `browser` varchar(128) NOT NULL DEFAULT '',
  `hour` varchar(5) NOT NULL DEFAULT '',
  `day` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `quiz_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE IF NOT EXISTS `quiz_questions` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer1` text NOT NULL,
  `answer2` text NOT NULL,
  `answer3` text NOT NULL,
  `answer4` text NOT NULL,
  `lang` varchar(128) NOT NULL DEFAULT '',
  `rank` int(2) NOT NULL DEFAULT '0',
  `true` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `question` (`question`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `quiz_questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `referendum`
--

CREATE TABLE IF NOT EXISTS `referendum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `preference` varchar(255) NOT NULL DEFAULT '',
  `voter_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=87 ;

--
-- Dumping data for table `referendum`
--


-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `descr` varchar(255) NOT NULL DEFAULT '',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `context` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `reviews`
--


-- --------------------------------------------------------

--
-- Table structure for table `reviews_cats`
--

CREATE TABLE IF NOT EXISTS `reviews_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `descr` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `reviews_cats`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_queries`
--

CREATE TABLE IF NOT EXISTS `search_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `query` (`query`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1594 ;

--
-- Dumping data for table `search_queries`
--


-- --------------------------------------------------------

--
-- Table structure for table `stallman_editions`
--

CREATE TABLE IF NOT EXISTS `stallman_editions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_date` int(11) NOT NULL DEFAULT '0',
  `end_date` int(11) NOT NULL DEFAULT '0',
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `winner_id` int(11) NOT NULL DEFAULT '0',
  `manual_title` text NOT NULL,
  `work_url` varchar(255) NOT NULL DEFAULT '',
  `judges` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `stallman_editions`
--


-- --------------------------------------------------------

--
-- Table structure for table `stallman_partecipants`
--

CREATE TABLE IF NOT EXISTS `stallman_partecipants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edition_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `subscription_date` int(11) NOT NULL DEFAULT '0',
  `work_url` varchar(255) NOT NULL DEFAULT '',
  `comments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=120 ;

--
-- Dumping data for table `stallman_partecipants`
--


-- --------------------------------------------------------

--
-- Table structure for table `tutorials`
--

CREATE TABLE IF NOT EXISTS `tutorials` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `dir_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `members_name` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `cache` longtext,
  `timestamp` int(11) DEFAULT '0',
  `old_text_format` tinyint(1) NOT NULL DEFAULT '0',
  `pro_votes` int(11) NOT NULL DEFAULT '0',
  `cons_votes` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `body` longtext,
  PRIMARY KEY (`id`),
  KEY `approved` (`approved`),
  KEY `dir_id` (`dir_id`),
  KEY `type` (`type`),
  KEY `members_name` (`members_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1181 ;

--
-- Dumping data for table `tutorials`
--


-- --------------------------------------------------------

--
-- Table structure for table `tutorials_categories`
--

CREATE TABLE IF NOT EXISTS `tutorials_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dir_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dir_id` (`dir_id`,`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tutorials_categories`
--

INSERT INTO `tutorials_categories` (`id`, `dir_id`, `name`) VALUES
(7, 1, 'Informatica'),
(11, 3, 'Linux'),
(21, 4, 'Internet'),
(5, 6, 'Sicurezza e OS'),
(29, 7, 'Protocolli'),
(8, 8, 'Hardware'),
(25, 9, 'Visual Basic'),
(3, 10, 'Java'),
(15, 11, 'PHP'),
(4, 12, 'Pascal'),
(16, 13, 'Perl'),
(24, 14, 'Windows'),
(26, 15, 'C'),
(10, 16, 'C++'),
(12, 17, 'Delphi'),
(6, 18, 'C#'),
(1, 19, 'Masterizzare CD'),
(13, 20, 'Masterizzare DVD'),
(20, 22, 'Files Immagine'),
(19, 23, 'Video Digitale'),
(27, 24, 'Mp3 e Audio'),
(14, 25, 'Prolog'),
(17, 26, 'Ruby'),
(28, 27, 'ASP'),
(23, 28, 'Python'),
(18, 29, 'Google'),
(22, 32, 'Ruby On Rails'),
(2, 38, 'Scheme'),
(9, 39, 'iPhone');

-- --------------------------------------------------------

--
-- Table structure for table `tutorials_comments`
--

CREATE TABLE IF NOT EXISTS `tutorials_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tutorial_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id` (`tutorial_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tutorials_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `usenet_groups`
--

CREATE TABLE IF NOT EXISTS `usenet_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `usenet_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `usenet_posts`
--

CREATE TABLE IF NOT EXISTS `usenet_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT '1',
  `messageid` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `post_date` int(11) NOT NULL DEFAULT '0',
  `post_from` varchar(255) NOT NULL DEFAULT '',
  `post_references` varchar(1200) DEFAULT NULL,
  `replyto` varchar(255) DEFAULT NULL,
  `contenttype` varchar(255) DEFAULT NULL,
  `contenttransfenc` varchar(255) DEFAULT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `subject` (`subject`),
  KEY `messageid` (`messageid`),
  KEY `post_references` (`post_references`(1000)),
  FULLTEXT KEY `body` (`body`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86275 ;

--
-- Dumping data for table `usenet_posts`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `os_browser` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `permission` int(11) DEFAULT NULL,
  `verified` int(11) DEFAULT NULL,
  `md5` varchar(255) DEFAULT NULL,
  `previous_login_timestamp` int(11) DEFAULT '0',
  `last_login_timestamp` int(11) DEFAULT '0',
  `signature` varchar(255) DEFAULT NULL,
  `last_login_ip` varchar(16) DEFAULT NULL,
  `biometric_hash` varchar(255) DEFAULT NULL,
  `disable_biometric` varchar(255) NOT NULL DEFAULT '',
  `wiki_enabled` tinyint(1) DEFAULT '1',
  `avatar` varchar(255) DEFAULT NULL,
  `banned` int(11) DEFAULT NULL,
  `banned_reason` text,
  `newsletter` tinyint(1) NOT NULL,
  `forum_votes_pro` int(11) NOT NULL DEFAULT '0',
  `forum_votes_cons` int(11) NOT NULL DEFAULT '0',
  `forum_post_count` int(11) NOT NULL DEFAULT '0',
  `requirepwdreset` tinyint(1) NOT NULL DEFAULT '0',
  `developerpermission` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `md5` (`md5`),
  KEY `user` (`user`),
  KEY `mail` (`mail`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17009 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `code`, `user`, `pass`, `mail`, `ip`, `os_browser`, `date`, `description`, `permission`, `verified`, `md5`, `previous_login_timestamp`, `last_login_timestamp`, `signature`, `last_login_ip`, `biometric_hash`, `disable_biometric`, `wiki_enabled`, `avatar`, `banned`, `banned_reason`, `newsletter`, `forum_votes_pro`, `forum_votes_cons`, `forum_post_count`, `requirepwdreset`, `developerpermission`) VALUES
(8, NULL, 'pierotofy', '', 'admin@pierotofy.it', NULL, NULL, '04/12/2003 15:12', '<font class=small color=yellow>Admin</font>', 0, 1, '2e0f9a29bed76d2e7c635eacb307e4d7', 1284251700, 1284261274, '[left]\r\nFai quello che ti piace, e fallo bene.\r\n\r\n[b]TheKaneB[/b]: [i]sta chat sta diventando un ritrovo di pazzi esaltati e scimmie ubriache %-)[/i]', '127.0.0.1', '', '', 0, 'pierotofy_1283542569.png', NULL, NULL, 1, 12, 2, 4085, 0, 2),
(17008, NULL, 'utente', '', 'pierotofy@libero.it', '127.0.0.1', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8', '04/09/2010 23:56', 'Normal User', 9, 1, 'a0cdd710cf4e43b2230da91aeb3bc12b', 1283644674, 1283644689, NULL, '127.0.0.1', NULL, '', 1, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wall_followers`
--

CREATE TABLE IF NOT EXISTS `wall_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `following_user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`following_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wall_followers`
--


-- --------------------------------------------------------

--
-- Table structure for table `wall_posts`
--

CREATE TABLE IF NOT EXISTS `wall_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `trusted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`timestamp`,`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wall_posts`
--

INSERT INTO `wall_posts` (`id`, `user_id`, `author_id`, `body`, `timestamp`, `type`, `trusted`) VALUES
(1, 8, 0, '<b><a href=''/pages/members/profile.php?uid=8''>pierotofy</a></b> ha commentato la news <a href=''http://localhost/pages/home/news/5590-news_di_esempio/''>News di esempio</a>', 1284941564, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wiki`
--

CREATE TABLE IF NOT EXISTS `wiki` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` int(11) DEFAULT NULL,
  `term` varchar(255) NOT NULL DEFAULT '',
  `text` text,
  `source` varchar(255) DEFAULT NULL,
  `feedback_pos` int(11) DEFAULT '0',
  `feedback_neg` int(11) DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `member_nick` varchar(255) DEFAULT NULL,
  `abbr_for` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3029 ;

--
-- Dumping data for table `wiki`
--

