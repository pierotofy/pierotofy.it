-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 09, 2011 at 07:03 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pierotof_sito2`
--

-- --------------------------------------------------------

--
-- Table structure for table `adv_chapters`
--

CREATE TABLE IF NOT EXISTS `adv_chapters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guide_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `chapter` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `context` longtext NOT NULL,
  `validated` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `adv_chapters`
--


-- --------------------------------------------------------

--
-- Table structure for table `adv_chapters1`
--

CREATE TABLE IF NOT EXISTS `adv_chapters1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guide_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `chapter` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `context` longtext NOT NULL,
  `validated` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=459 ;

--
-- Dumping data for table `adv_chapters1`
--


-- --------------------------------------------------------

--
-- Table structure for table `adv_guides`
--

CREATE TABLE IF NOT EXISTS `adv_guides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `descr` text NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adv_guides`
--

INSERT INTO `adv_guides` (`id`, `name`, `descr`, `admin_id`) VALUES
(1, 'Guida X', 'Prova di guida', 4);

-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_bans`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_bans` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ajax_chat_bans`
--


-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_invitations`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_invitations` (
  `userID` int(11) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ajax_chat_invitations`
--


-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_messages`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `text` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ajax_chat_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `ajax_chat_online`
--

CREATE TABLE IF NOT EXISTS `ajax_chat_online` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  KEY `userID` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ajax_chat_online`
--


-- --------------------------------------------------------

--
-- Table structure for table `algorithm`
--

CREATE TABLE IF NOT EXISTS `algorithm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `program_id_referer` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `context` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id_referer` (`program_id_referer`),
  KEY `module_name` (`module_name`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4347 ;

--
-- Dumping data for table `algorithm`
--


-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer_code` text,
  `answer_comment` text,
  `email_notify` varchar(255) DEFAULT NULL,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `answers`
--


-- --------------------------------------------------------

--
-- Table structure for table `approval_tutorials_votes`
--

CREATE TABLE IF NOT EXISTS `approval_tutorials_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tutorial_id` int(11) DEFAULT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=432 ;

--
-- Dumping data for table `approval_tutorials_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `approval_votes`
--

CREATE TABLE IF NOT EXISTS `approval_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9113 ;

--
-- Dumping data for table `approval_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `aptchat`
--

CREATE TABLE IF NOT EXISTS `aptchat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(60) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37538 ;

--
-- Dumping data for table `aptchat`
--


-- --------------------------------------------------------

--
-- Table structure for table `bad_queries`
--

CREATE TABLE IF NOT EXISTS `bad_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `page` varchar(255) NOT NULL,
  `stacktrace` text NOT NULL,
  `ip` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bad_queries`
--

INSERT INTO `bad_queries` (`id`, `query`, `timestamp`, `uid`, `page`, `stacktrace`, `ip`) VALUES
(1, 'SELECT COUNT(t.id) AS records\r\nFROM tutorials t\r\nINNER JOIN tutorials_categories c\r\nON c.dir_id = t.dir_id\r\nWHERE t.dir_id =  AND t.approved = 1', 1283644350, 0, '/pages/guide_tutorials/Google/', '	 at 0  C:\\wamp\\pierotofy.it\\trunk\\etc\\commonconf.php (line 228) -> getDebugBacktrace(\n)\n	 at 1  C:\\wamp\\pierotofy.it\\trunk\\pages\\guide_tutorials\\guide.php (line 125) -> exequery(SELECT COUNT(t.id) AS records\r\nFROM tutorials t\r\nINNER JOIN tutorials_categories c\r\nON c.dir_id = t.dir_id\r\nWHERE t.dir_id =  AND t.approved = 1)\nDebug backtrace end\n', '127.0.0.1'),
(2, 'SELECT fn.topic_id, fp.subject FROM forum_notifications fn, forum_posts fp WHERE\r\n	  fp.id = fn.topic_id AND\r\n	  fn.user_id = \r\n	  ORDER BY fn.id DESC', 1283644616, 0, '/pages/login/registerpass.php', '	 at 0  C:\\wamp\\pierotofy.it\\trunk\\etc\\commonconf.php (line 228) -> getDebugBacktrace(\n)\n	 at 1  C:\\wamp\\pierotofy.it\\trunk\\etc\\bottombar.php (line 154) -> exequery(SELECT fn.topic_id, fp.subject FROM forum_notifications fn, forum_posts fp WHERE\r\n	  fp.id = fn.topic_id AND\r\n	  fn.user_id = \r\n	  ORDER BY fn.id DESC)\n	 at 2  C:\\wamp\\pierotofy.it\\trunk\\etc\\footer.php (line 110) -> include(C:\\wamp\\pierotofy.it\\trunk\\etc\\bottombar.php)\n	 at 3  C:\\wamp\\pierotofy.it\\trunk\\etc\\interface.php (line 293) -> include(C:\\wamp\\pierotofy.it\\trunk\\etc\\footer.php)\n	 at 4  C:\\wamp\\pierotofy.it\\trunk\\pages\\login\\registerpass.php (line 197) -> close_pag()\nDebug backtrace end\n', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `bestbanner`
--

CREATE TABLE IF NOT EXISTS `bestbanner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `preference` varchar(255) NOT NULL DEFAULT '',
  `voter_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `bestbanner`
--


-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `image` blob,
  `size` int(11) DEFAULT '0',
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `blog`
--


-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE IF NOT EXISTS `blog_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(255) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=321 ;

--
-- Dumping data for table `blog_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `burningtools`
--

CREATE TABLE IF NOT EXISTS `burningtools` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `refer` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `filename` varchar(128) NOT NULL DEFAULT '',
  `size` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `burningtools`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_blocks`
--

CREATE TABLE IF NOT EXISTS `cache_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` blob NOT NULL,
  `block_id` varchar(40) NOT NULL,
  `expiration` int(11) NOT NULL DEFAULT '0',
  `dirty` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cache_blocks`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_pages`
--

CREATE TABLE IF NOT EXISTS `cache_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` blob NOT NULL,
  `group_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `page_num` int(11) NOT NULL DEFAULT '0',
  `expiration` int(11) NOT NULL DEFAULT '0',
  `dirty` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`,`page_id`),
  KEY `page_page` (`page_num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cache_pages`
--

INSERT INTO `cache_pages` (`id`, `content`, `group_id`, `page_id`, `page_num`, `expiration`, `dirty`) VALUES
(1, 0x434f4d5052455353283c64697620616c69676e3d2763656e746572273e3c7461626c6520626f726465723d30206267636f6c6f723d236565656565652077696474683d313030253e3c74723e3c7464206267636f6c6f723d23444545334537207374796c653d2777696474683a20343070783b273e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e4465736372697074696f6e3c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e546f706963733c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e506f7374733c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e4c61737420506f73743c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e4d6f64657261746f72733c2f666f6e743e3c2f74643e3c2f74723e3c74723e3c7464206267636f6c6f723d2344314437444320636f6c7370616e3d363e3c64697620616c69676e3d276c656674273e3c666f6e7420434c4153533d276e6f726d616c2720636f6c6f723d233030303030303e43617465676f7269613c2f666f6e743e3c2f74643e3c2f74723e3c74723e3c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c696d67207372633d27687474703a2f2f6c6f63616c686f73742f646174612f696d616765732f666f72756d2e6769662720616c743d27466f72756d2720626f726465723d303e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d276c656674273e3c6120687265663d27687474703a2f2f6c6f63616c686f73742f70616765732f6578747261732f666f72756d2f3633382f2720434c4153533d27646f776e6c6f6164273e3c666f6e7420434c4153533d276e6f726d616c273e466f72756d20313c2f666f6e743e3c2f613e3c64697620616c69676e3d276c656674273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e466f72756d206469206573656d70696f2023313c2f666f6e743e3c2f74643e0d0a2020093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e333c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e303c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e32342f30392f32303130202d2032313a32323c62723e627920706965726f746f66793c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c6120687265663d27687474703a2f2f6c6f63616c686f73742f70616765732f6d656d626572732f70726f66696c652e7068703f6e69636b6e616d653d506965726f20546f66792720434c4153533d27646f776e6c6f6164273e3c666f6e7420434c4153533d27736d616c6c273e506965726f20546f66793c2f666f6e743e3c2f613e3c2f74643e3c2f74723e3c74723e3c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c696d67207372633d27687474703a2f2f6c6f63616c686f73742f646174612f696d616765732f666f72756d2e6769662720616c743d27466f72756d2720626f726465723d303e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d276c656674273e3c6120687265663d27687474703a2f2f6c6f63616c686f73742f70616765732f6578747261732f666f72756d2f3633392f2720434c4153533d27646f776e6c6f6164273e3c666f6e7420434c4153533d276e6f726d616c273e466f72756d20323c2f666f6e743e3c2f613e3c64697620616c69676e3d276c656674273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e466f72756d206469206573656d70696f2023323c2f666f6e743e3c2f74643e0d0a2020093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e323c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e323c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c666f6e7420434c4153533d27736d616c6c2720636f6c6f723d233030303030303e31352f31312f32303130202d20333a30383c62723e627920706965726f746f66793c2f666f6e743e3c2f74643e0d0a093c7464206267636f6c6f723d234445453345373e3c64697620616c69676e3d2763656e746572273e3c6120687265663d27687474703a2f2f6c6f63616c686f73742f70616765732f6d656d626572732f70726f66696c652e7068703f6e69636b6e616d653d506965726f20546f66792720434c4153533d27646f776e6c6f6164273e3c666f6e7420434c4153533d27736d616c6c273e506965726f20546f66793c2f666f6e743e3c2f613e3c2f74643e3c2f74723e3c2f7461626c653e29, 1, 0, 0, 1305917055, 0),
(4, 0x971a0000789cbd595f73db36127f7666f21d10f7ae94e7625292ed34b16575dcdee49a99b4e39edda79b1b0d4482d22620c000a01ce7e6beeb3df62bdc5b770150962c99b1da4ca76944828bc5fef9ed6277332a60c172c9ad3d4fa652e7ef19fe3d63066673978c9f3ed91bdd27f841f042184fe609f64650cd9835f9799215dcf10c2a3e13362382613fadd52c61d6dd4a719e2c8471907379c825ccd429aba028a4481897ee3cf98e186663369a8e7f910e2a60a09c300ba11cb0824b36e26c6e4489c7d4cb03b2644c3fa38c8f47d9d4cb9ba1c0f8408f8d6c25af35312ba2c05923f1e18e92fe5bd51354213e063d830de6c3f6930527aec1a1d4e3ef8442e11aa7996dd82508a3af75799b821b65f3a1df764fe0dae899e1550528f565fb4ca23fdfd06dd64021260e991be0d2e2064ea6d3f2017af1d1196eb3529ba642e2026cde580b5a797a263636cc7525323bd73713256eec849b7c0e0b91d6f33a19d38adf661b29d118c8b5e2e43876c850245418146b14678590729375ae55eeb8cb6ee63af0fb5e578d02f7bf254fce5a53f04f28a36035fc9fe1bb2ad0d3c91b87f0e0295bf5d0aa77722938fa65fbc780e15288c20610235fddd4834e2c7bf28475a19948b831fa661748bff67c03a62f9c83051a81199107480bd8305d25aaa930cbdf603e7a31b005e26bfadc70296b6d1db3153e250c8abbb549503f2ad72299e83c05e4c9168d735d5528e8d130e8eb15fa5a4d6d7d861a056eb6e6eafef90ea1186508541b61d02a891828417acc7d8b703f7f998c6b8a228751e4a132e72c0ac11173881a02e69dcde6ced5a759867ee4728e27af229b28b3939357fd430fef0226c28aaa068dc1f1137141a4c5153a2aa893913ee8ac6d6aa165c49a69eb89abc8ae181341cd613febbf62fdd3c170955bf0d56aaad944ab57eb113025bace947ba38d2c7601683005e6d64aab4247a4ae2ffa205f4d02f74118126dfb24c10b188c114cd33a6cff1d5f709b1ba8dd69a1e994ab063380b9ed91a30ecef6b779666fcd1aea6e537083f7ae0d2b1362b30af44d03f9242ac5e04530d126d73798bc566cd322fde7465884e0af0c24abb9e198ab4a4d925216a4ed295b15d3a0bf2a6df08ef8d752f9df87d6fdf15b319b4148bb648f7faf030add102cbe72af6de2e7b5d66e153f0fdc1ef45dab5bdd18bae5fc6bc840172842a366e12ef940b61001b40812d7e0fd07681c5dd78d116cd67053f09dee1b9984d7652cb6dafdeefc4f5789aee22513426bf8889a666d5b67a4459a5d62adbdf139c3b4c66d1b6dcb42202e6f09afbd872c112f3bbaf4a392ddd71c1176aa55e8bca17cbbd325e78f771aaf11bb5ebf8535c66bda8e80d92ce1ee952dfe77b75a6e99711e0275e0fde2e85536e80f4efa278343f4dd8287126cc13da47b9fdd9b8c839a43a23fd85b86dde3cf7f19cfef1f725b503d678b479dfd7279f6e08f9e7dfcead061ec22c36bfcf9d34e8f963f7e7968454e57ca842e54647c155e19bdfed97e38fe067100d552964b7a79bc241d76d9e82e76cc5d08cf772277964951c6eaf5a833acdb0d9d91edb49676d77425b0665d0fe92d2d8d3f3b8b777048e875dcfb07dbb2adb6a164b9936dfc864edb200aad96e2cb24bdaea6af5e6dfabea861969de2a32db3dcd17dcf51f29ed442e52077b1cf45ec56bb6dd3dde57e21033d22e46c53d7da44b31d3fa250881b3a4d27f86c374c5d05a63c6fad76df5c764910c2acdde03316b647d867fb46fb768be55614a10e2d19c792d6976e98d514d85c6039ebdb70d6d66354e21ab0da58b1bd71a7ead75adc9663e6d429bbca35a6559a0fe473810d0465f7466f7afebe2aedbb115e192cb3153234d4f52d34fe08dffed1d28a9a292a7649750dc7ff8d463c300e5e1220c12bae1a27541054d00ad5dda0b003d6aa840238667cae4850aa4da2083a4e3510f7963662072a9813348ef84c5d1ab01431c40bdb89a0e5f7ede0817a8e87ef821eb8a41da16141ec5c2d40a2429c428b856fcfbac607011404e7b7c9fd0efbe6e626055580e0756db10306349a48b59925e337b4cc2e709d5dc40fde81bf86cea8c10a8b212157f0e953844c89773e6acab63409db26030af2f78a57e2dc4fd8fe3aecd3900def6b7a63d7eda800bdc574591ac00e8494c0d80366576d40b20021123c311e51e18a407a72b621d8227c5091073cedbd3d3564df11aae0d6c628c978ff2d67366fb40c53b1444fa7e824cdc00fb3c8165a215011cc3ed024469e6b0a0868bb1f56cffd70083d8da9d04bff3c82d20887cf1e927cb100a1485b500b91138651332e2cf869da527708e4bf5c5d600cfc436013af68b816c3bf268fc838720b633d928ce62d68286ef040c39d40e7e16e85816c7dd47c68821531f23042402728868f2354328855729a1316681bcdae885f9aa6645eeea792b40dd80c101e0afb042efd44cc36a1b9e418bad8afa240bc2cb9cd41718cede73e6c29ccfdee425050b76a9a60080ba2f25e941827644a20cb96221c8a90c086b504e593418e5dba111ea77ef4e843ddcf29d37defe8e86df4b71f08c5202ca5e6ee34dc1167c9f873d3a88ad7e9dc55889007221d09062fd21994318e7f242391bb7d6a4e18ca4100df48a0827274fc11b14f7fe08840b476ca3f2117b4b1e51fa7554f9f7caf55ae4d01dfb2bf038dde397a524590c6fc0b18cc80c0c2d0468f6d4b1625cfc554ebf7295ad477fe3e92bf7a96f9e4e85f66509c0f8e5ff4bf393a3a3e391e0e8e06275f131b2a635fc7ed24d8338a418ab7f1288c8e50c6b251b94387b2f52912161307ffc1d85de0756084c6a2859da3f4d28ab3b81a8b545cfecbbb5ef2d5daf028617f63c48168a164bdb6a005db4b4e1760618aa9f6e0e08eb3338d674cacd2d5c1d4413a4774f60ecef622abb0e5a03d3ea531488f0ef25733fe597e90b8f15acfb070e80d4ffa9ec37f89487c68b8fc4110e67a78de7e1aa685fb07c465fbc761d7c7a3ae8fc7e1e3d3275e337f69a14e880a254c2f39aa3f26f4f9ee63fc87923b122c8bd926591842ad904d35a6886a49498e5ebaf83776d8a537, 0, 0, 0, 1307642305, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `mail` varchar(64) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `date` varchar(19) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=606 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `compilers`
--

CREATE TABLE IF NOT EXISTS `compilers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL DEFAULT '',
  `descrizione` text NOT NULL,
  `filename` varchar(128) NOT NULL DEFAULT '',
  `size` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `compilers`
--


-- --------------------------------------------------------

--
-- Table structure for table `copypastebin`
--

CREATE TABLE IF NOT EXISTS `copypastebin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` longtext NOT NULL,
  `language` varchar(100) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `cid` varchar(100) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `copypastebin`
--


-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE IF NOT EXISTS `counter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `browser` varchar(255) NOT NULL DEFAULT '',
  `referer` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `counter`
--


-- --------------------------------------------------------

--
-- Table structure for table `counter_old`
--

CREATE TABLE IF NOT EXISTS `counter_old` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL,
  `os_browser` varchar(255) DEFAULT NULL,
  `heures` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `counter_old`
--


-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=244 ;

--
-- Dumping data for table `countries`
--


-- --------------------------------------------------------

--
-- Table structure for table `daily_ip_accesses`
--

CREATE TABLE IF NOT EXISTS `daily_ip_accesses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `daily_ip_accesses`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloads_count`
--

CREATE TABLE IF NOT EXISTS `downloads_count` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(128) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `program_name` (`program_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3489 ;

--
-- Dumping data for table `downloads_count`
--


-- --------------------------------------------------------

--
-- Table structure for table `external_urls`
--

CREATE TABLE IF NOT EXISTS `external_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18606 ;

--
-- Dumping data for table `external_urls`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_arguments`
--

CREATE TABLE IF NOT EXISTS `forum_arguments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `root` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `moderators` varchar(255) DEFAULT NULL,
  `private` int(1) unsigned NOT NULL DEFAULT '0',
  `priority` int(11) DEFAULT NULL,
  `developers_only` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=640 ;

--
-- Dumping data for table `forum_arguments`
--

INSERT INTO `forum_arguments` (`id`, `root`, `title`, `subject`, `moderators`, `private`, `priority`, `developers_only`) VALUES
(638, 'Categoria', 'Forum 1', 'Forum di esempio #1', 'Piero Tofy', 0, 10, 0),
(639, 'Categoria', 'Forum 2', 'Forum di esempio #2', 'Piero Tofy', 0, 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `forum_arguments_old`
--

CREATE TABLE IF NOT EXISTS `forum_arguments_old` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `root` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `moderators` varchar(255) DEFAULT NULL,
  `private` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=542 ;

--
-- Dumping data for table `forum_arguments_old`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_comments`
--

CREATE TABLE IF NOT EXISTS `forum_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `forum_comments`
--

INSERT INTO `forum_comments` (`id`, `post_id`, `user_id`, `text`, `timestamp`) VALUES
(18, 1015051, 8, 'test!', 1289790082),
(12, 1015051, 8, 'test', 1289789361),
(17, 1015051, 8, 'Grazie mille!!!', 1289789981),
(5, 1015051, 8, 'test', 1289788016),
(15, 1015051, 8, 'grazie!!', 1289789503),
(16, 1015051, 8, 'grazie...', 1289789755),
(20, 1015052, 8, 'we!', 1289790160),
(21, 1015052, 8, 'ti ringrazio, ma hai provato con un altro metodo? Ad esempio usare public_html() nel mai', 1289790225),
(22, 1015052, 8, 'lol', 1289790359),
(23, 1015052, 8, 'we!', 1289790481);

-- --------------------------------------------------------

--
-- Table structure for table `forum_notifications`
--

CREATE TABLE IF NOT EXISTS `forum_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `notify_tm` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_id` (`topic_id`,`user_id`,`notify_tm`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forum_notifications`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_notifications_add_list`
--

CREATE TABLE IF NOT EXISTS `forum_notifications_add_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forum_notifications_add_list`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_notifications_skip_list`
--

CREATE TABLE IF NOT EXISTS `forum_notifications_skip_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forum_notifications_skip_list`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_poll`
--

CREATE TABLE IF NOT EXISTS `forum_poll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vote` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_id` (`topic_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8052 ;

--
-- Dumping data for table `forum_poll`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_posts`
--

CREATE TABLE IF NOT EXISTS `forum_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(9) NOT NULL DEFAULT '0',
  `argument` int(9) NOT NULL DEFAULT '0',
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext,
  `type` int(1) NOT NULL DEFAULT '0',
  `root_topic` varchar(255) DEFAULT NULL,
  `post_date` int(9) DEFAULT '0',
  `edit_date` int(9) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `locked` int(1) DEFAULT NULL,
  `show_as` int(1) NOT NULL DEFAULT '0',
  `last_post_date` int(9) NOT NULL DEFAULT '0',
  `edit_by` int(9) NOT NULL DEFAULT '0',
  `notifies_list` text,
  `attachment_filename` varchar(255) DEFAULT NULL,
  `attachment_data` longblob,
  `attachment_size` int(11) DEFAULT NULL,
  `attachment_type` varchar(255) DEFAULT NULL,
  `poll` varchar(1200) DEFAULT NULL,
  `show_poll_in_menu` tinyint(4) DEFAULT '0',
  `question` tinyint(1) DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `best` tinyint(1) NOT NULL DEFAULT '0',
  `replies` int(11) DEFAULT NULL,
  `has_comments` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `argument` (`argument`),
  KEY `user_id` (`user_id`),
  KEY `root_topic` (`root_topic`),
  KEY `type` (`type`),
  KEY `show_poll_in_menu` (`show_poll_in_menu`),
  FULLTEXT KEY `subject` (`subject`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1015054 ;

--
-- Dumping data for table `forum_posts`
--

INSERT INTO `forum_posts` (`id`, `user_id`, `argument`, `subject`, `message`, `type`, `root_topic`, `post_date`, `edit_date`, `ip`, `locked`, `show_as`, `last_post_date`, `edit_by`, `notifies_list`, `attachment_filename`, `attachment_data`, `attachment_size`, `attachment_type`, `poll`, `show_poll_in_menu`, `question`, `score`, `best`, `replies`, `has_comments`) VALUES
(1015047, 8, 638, 'Primo post', 'Esempio di post', 0, NULL, 1284945343, NULL, '127.0.0.1', 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0),
(1015048, 8, 639, 'Secondo post', 'Esempio di post', 0, NULL, 1284945343, NULL, '127.0.0.1', 0, 0, 1289790515, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 1, 0),
(1015049, 8, 638, 'Test', '', 0, '', 1285363354, NULL, '127.0.0.1', 0, 0, 0, 0, NULL, '', '', 0, '', '', 0, 0, 0, 0, 0, 0),
(1015050, 8, 638, 'asd', 'ASD', 0, '', 1285363364, NULL, '127.0.0.1', 0, 0, 1285363364, 0, NULL, '', '', 0, '', '', 0, 0, 0, 0, 0, 0),
(1015051, 8, 639, 'Prova', 'etst', 0, '', 1289786602, NULL, '127.0.0.1', 0, 0, 1289789917, 0, NULL, '', '', 0, '', '', 0, 1, 0, 0, 1, 1),
(1015052, 8, 639, '', 'Hai provato con....', 1, '1015051', 1289789917, 1289790243, '127.0.0.1', 0, 0, 0, 8, NULL, 'cantonesehouse_map.jpg', 0xffd8ffe000104a46494600010200006400640000ffec00114475636b79000100040000003c0000ffee000e41646f62650064c000000001ffdb0084000604040405040605050609060506090b080606080b0c0a0a0b0a0a0c100c0c0c0c0c0c100c0e0f100f0e0c1313141413131c1b1b1b1c1f1f1f1f1f1f1f1f1f1f010707070d0c0d181010181a1511151a1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1fffc000110801e0028003011100021101031101ffc400b1000100020301010100000000000000000000040501030602070801010003010101010000000000000000000001020305040607100002020102040404020706050400050501020304001105213112064151611322324214526271c1d1233315078191b1432434a172c25316b2d26344f09293b32582836517081101000201030302030605050001050000000102112103043141125161712205f08191a13213b1c1d1e142f152622314a27292b21506ffda000c03010002110311003f00fb6e64b2246d636b90cd58192931d66aa39af9b47fb311384f55fd5b505a816681c3c6dc88cd2272a37648e7f78d84f44f2544eb86752b6a983a070dcd908f95b33b571ac2d128bb3d4a51c6d3c0ef34d20092cd312d2009c021d7905f2c8ce4c2c3030ee888cee42a28d598f203035edb49f709d2f5952b5233ad584f02c7fee30ff0c5633a93385fe6aaa2ee3b84346b19a5e27e58e31f33b1e4a322d6c26232a6ad04cd2b5cb67aadcbe1e11af822febcca23bcac9392830180c06030180c06030180c06030180c06030180c0606ab3662ad11964e5c9547324f20313384b7ed1b64deefdfdd1fea5869143e1121f0ff9bcf26b5ef28995c668aa06ebba2d38d5235f72dcda88221e27ccfa0cadad84c42b2a5568bae499fddb531ea9a53e27c87a0cce216788dac6d7234d554c9518969eaf883e2d1feb1889c1d57f52dd7b702cf5dc3c6de23c0f91f5cd6272a4c37648a4dc36896195aeedc3e33a99eb7d327a8f26cced5ef0b44b555b70d98fae33a11c1d0f0653e4c32227296ec20c06030180c06030180c06030180c0606ab3663af1191f8f8220e6cc790194dcdc8a46656ad72e7bbab72dcf60edeb3bec66b36e81a310d6b45951c33002b44578fbb2fcabf98e7cfceeff00e8ddc5b3e3eddbddace91a24f6c7746c1de7b58b1047eddcaada5aa16900b34ec0f078db910791e473cdbdb36d9b7b4f7ed3044e55d57b7778abba56b7bd6f2fbeeeb5d644dae3f663af142b2001e69162003390399e5e19e9daff00b7e4dbaf8c4f531de5d454a895a3e904bc8c7aa590f3663cce77b676636eb88656b665bb3554c06030180c06030180c0604696bcf14ff794982591c1d0fc9228fa5bf51c8c7784aa6df696c1beb2b55ad050f76d258ee3a4b0aabdd58c12a933280ce3afe2e3c0e695b65598c2abb9bfa9bb86df0b57dbf6b9367a6e24828eedb942c90c965074a578a11f175c8e7f765be16d0e590eaea6df6af6d556c4d614eff5e345b92a8551eef48668e445e03e6ca5ab95a259ab69a476827430db8ff8911ffd4be6329129560de6517e4b0d2ebb4ea21ab1ac7d52d89fc7dad3e22ab9261778433810fa2cd199ad511d41b8cf57e97fccbe4d91d3584f55e51bf5aec02681b51c994f356f2233589cab31849c9429f74da65f75af50d16ce9fbd84fcb28f5fcdeb99dabde168947ab6e2b08c46a8f1f09a26e0c87c8e444a5e2ad66dde70cdc36c85bff00d671ff0048c44797c09d1d10000000d00e000cd546ab76a0a95de79dba6341a93fa87ae44ce0850c427b963efed8e93ffd680ff96a7c4fe639975d6574ac94180c06030180c06030180c06030180c06030180c060303c4d3470c4d2cadd288352713296769a125995771ba9d3a7fb4aedf40fc67f31c9ad73aca26576082351c4668aa26e9b94742bfb8475cac7a618873763c8656d6c26232a8ab5e5f71adda3d7725f9cf820f045f4199c4775927250ce04431d9a739b7406a5b8cf58f0593d47936474d612badbf71ad7a1f7613c41d1e33c1948f023358b65598c2564a153ba6d0f249f7b4888ee01f1a9f96551e0debe47296af785a2512adb49fa90a98a78f84b03fcca7f58cac4a70df84180c06030180c06030180c060303c4d345044d2cadd28bc49c8b5a2b1994c4650a19a012b5ddc64489a38da586b3302c9128d4c8579eba0f2cf9be6726dbb388fd2de348c3e69dd1dd7bdefdb445bdac1157ed58ed259da37ea85accd526ad26b1cf72bf2685cae8eaba1519bec6d536e7c7adfa4c74ce7b44faa93395f6cfb36eefdd23bc77a5aa9b8c95168d0afb5bca23b2bd4584f3ea7e35d0fc2afaf4fe9ccf316ac6d5333af7edecb563bcbb4a751a2ea9666f72d4bc657ffa47a0ced71b8f1b55c475677b65273d0a180c06030180c06030180c0603023d9a8ed22d8aefecdc8fe493c08fc2c3c41c8984b4ee30c1dc75a0a57358a7a5623b73d11a74d83006644ea607e0f73a5b51c786695b655987070f71773766518efefd1c74a4dc6ecf66cedf0e9358b72c87a7dd96620a56af1c61037c24f01c78e4c0eff6bbf43bb76917a056ab6ebc8d0b1d43345347a752752f075e3e1cf226b92270aeb55b7037e31ee2d4bb0c2d08529d6ac8c7a8c95fc049e1c7c333f8aebcc954c0ce0449209e09cdca242d8ff3223f24a3c9bd7c8e474d612b8db77382f464a6a92a709616e0ca7d734adb2acc61332c856ee5b155bd2aca4b4527295a33a75a78ab652d4894c5b09f1451c51ac71a85441a2a8e400cba09658e28da49182c6835663c80181ceb4926e9616d4a0ad38ceb5613f51ffb8dfab3199cafd133250c6030180c06030180c06030180c06030180c06030180c0c3ba468ceec15146acc790181ab6ea4db94cb76cae94e33ad585beb23fcc71fe03158cea999c316f7b6dccad0d9d8996507dfb0410214e47ffea3e19e88ae3595161d54f65dad15dd99221d2bd44b3bb1f01af99ca5edde5310ac822b13d837ae0fdfb0d228b5d4449e43d7cce63d759592b2506030181166af3473fde52223b4bf303f2c83f0bfedc8c7784adb6ddd60bcac0031d88f84d037cca7f58f5cd2b6cab3184ecb215dba6d2b6f49e16f66ec7fc39478fe56f3194b57298956d5b6ceed5ec27b3723fe2447c7f329f11948959272506030180c06030180c0603030cca8a5dc85551ab31e400c4ce1289563fbf9d6c4c34ac9c6b4279bfe761fe19f3dcfe6f9cf8d7a37ac63e2f9ef727684fb5edf6bb92eba377145bed6b14f77123075a525b8a3f65b520227b2ceac9f2f8e536f7a2d3148fd3e33a7be149858769ff247de374df7b71e6afdbd348f5ec51280d2bf674f8a7a6a7e4f8be162074bf978e46e56f3114b6b7fce3da5358ccbb3a55194fdc4c009d874aa01a2c69e08a0676b89c58daaff00c95bdb3a4744bcf5b330180c06030180c06030180c06030181a2dd44b0158318e78ceb14cbf329fd9e98984abb72daab770c95ebdfb336d7bd540eb5efd5f6899229474ca9d33c7344e92003a91d0e5ab6ed289842ee0dc1bb6f6f8bb37b16846dbecb5e4b10565e98960aea7496d1d474b3f530545f17235f872cab5f6456bbb852108b736e9dbc437db5abfac5ba52b519e992097e1d24d1b937872f8b9e26b94c4e1d4e66930180c08d62ab9956cd67f66e27cb27830fc2e3c4644c7a272b4da7745bc8eac9edd980f4cf1f300fa1f5cd2b6cab3184fcb20c0e7774b0d73741b7cdac55a201c46dc0cc7ff68f2ccad399c2f1d123fe03cb0830180c06030180c06030180c06030180c06030180c0600900124e807124f96046a755b76984b20236d88ea8a787bcc3c7fe518ac67e0999c2fe58cbc0f1237b6594aab0fa751a6b9aa8a9a7b46d5b0c325beb7e03e3776e7e81468326fb933ac91089189ef5917ad8d00d7ed6b9fa14fd47f31cc3aeaba664a18c06030180c08f6aa191d6785bd9b71718e51ff00a5bcc644c2561b5eeeb689af617d9bd18f8e2f061f893cc65eb6cab30b2cba10b72dae0bd18d4fb73a718675f994feb1e995b572989c2a21b13473fd9dd023b4a3e16fa641f890feaccf3da564ac94180c06030180c06030181576a49edc53cd0c2d66ad55678eba101acca80908a5881a13c38e7179dcc899f0ace8deb5c467bb87ed3ee996eb8b94cff30ef3dde5f6aed093ae38b6aab038eb8a54fa3db0dc386b231e1f0f11e5dedac693a523bffba7edf82b12edb7497b5bb8b6eddf65baeb76a40056dd225ea0a1d87574071a0eb1e4a751e39e4a45e968b4693d97eba3ded3b6c10c307440b5aad64116df4d06890c4a341c3cf4cfa0e1f17c7e7b6b6952f6ed0b3cf7b230180c06030180c06030180c06030180c0606ab5562b31f448391d51c70653e60e2632989546e9b541bb7b15b7099e8ef554f56d1bec1a0915bf09d78303c991b830f5e3935b76944c7a3b386311a01c0b1e2ec005ea6f16d079e68aaa33258c0caa9660a39b1007f6e071527f512f4d7afc1b56c66ed7dbe4314b61ec084f50257e5e9238953a6873ad1f4eac5626f6c4dbd9cd9e7da6662b5cc47ba46d7de77b71df13b7ee6dbfca6f598faeb4a25fb852342daf00a3e556d083cf33dee0446df9d2d98f834dae64cee785ab8977b4284146bac108e038b39e2ccc799273c31187b66729392830226e1b6d6bd0fb72821978c72af06461c883916ae53138532cb66ace2a5fd3adb8436070597f637a665d349592f250c6030180c06030180c06030180c06030180c06030181019a2bcb34b34821d9aa067b7618f486118ea61af82281ab1c44797c13d1d050b5b7daaa92d09a29eae8023c2cae9a69c8152472cd546e9a68a189a5958246835663c80c4c8e74bcbba585b7382b5233ad480f8fff00238ff0cc739d57e899928630180c06030180c0d16e9c76029d4c7346758a65e0ca7f66261394bdaf77779052bda25c03e07e4928f35f5f3196adbb4a2616d97551770dbab5e87da9c723aa3af06523c54e45ab94c4e14ab258a76053bc4166fe059e4b20f23e4d9974d2564bc943180c06030180c0ce04090c97e76ab092b590ff00a99470d7f229ff001ce4f3f9be31e35eada95c6b2b48e348d151005451a2a8f0033813395dc9f74762c77370fe7bb3ee0db06f7d3ecdcdc2055227ac78324a8740cca0eb1bf356d398e19e9d9e4623c6d1e55f4f7566a95b0ecb46ad282b5588c7b6d6e35e363abcae78b4f2b1e2cec78f1cec70f8d333fb97eaada71a42f73a8c98c06030180c06030180c06030180c06030180c060789e08a788c52af521f0fd63d7130979a3b94db7bad5bce5ea9d160b67c3c964fdb8adb1a493196dc20c0f70ff00163ff997fc703e3fb24bdb06cf7252ee29dabd76bdf720234a921113cea7a3db562cdaccbf0f88d4f867d36ec6e629348ccf8e3f87f47cfed4ede6f179c4673fc7faacf64976b7fea8ec906d32fbf4a8d4fb7122b348074c5337cee016e120e3e7c331dd8b7fe7b4dbacce7f835db9affe8ac57a447f57d93388eca8f74dc67b1336df45fa3a7fdd591c7a3f2afe6cced6ed0b443deddbbcb1cab4b71204a78416392c83c8f937a62b6ed24c2e73455a2e53af720682c2078dbfbc1f307cf2263298950c9f73b648b0db6325463a416fcbc964f5f5cca731d56ea9792830180c06030180c06030180c06030180c06067021849b73b0d56bb14ab19d2d4e3c7ff008d3d7cf2319d13d1cb6f1ba6f2bdd13edd155dc8c144c716d5b2d180a57b6aebac935ab6e3d9f6be92a5869a79b0cda2143fa6db7dda52dc1b384da764ad7ac43bc6cb3bfbeb0588c0767a732923a1cb8ea56f9703aa9e77dde7eb3a8db623fba8c8d3dd61f51fcbe5994ce7e0bc689584180c06030180c06030181aacd586cc7d1203c0eaae383291c883898ca72d9b76ed3412ad2dc5b566e105ae4afe41bc9b26b6ed28985de68ab45ca75ee40d0584eb8dbfbc1f307c0e44c64895138b3b64ab05b6325673a416cf8792c9e47d7329d17eaf76aed7aebf1cd145230d631338404ff8e9fa32446da3765bd1c81fdb134523444c4fd71c8542b16898e8597e300faeb816184180c06043b334b3cdf6554e8e78cf30ff002d4ffd4739fcee646dc623ab5a53bcac2b578abc2b0c4bd28bff0013e673e6ed6999ccb46c2401a9e0073395153239dce5e91a8a111e3e1eeb0ffa46767e9fc2cfcd656d6c7c538000683801c867758180c06030180c06030180c06030180c06030180c060303cc91c72214914321f994f2c0f580c08f6ad3c6c90575f72dcc748a3f2fccde832265310dbff0086f6fd8026dcf6fad76f30d66b32448598fe923c3967af6f91b958c45a5e7bec6dda733584bdb7b7360dae56976edbebd495c74b3c31aa123cb50317debdf4b4cca69b34afe988868ddb7495a5fe5f41b4b07f8f373112ff00ee3e19e6b5bb4368869ad5a2ad088a31a01ccf893e24e444612cd8af0d888c52af521fef07cc6260296e73d075ad7d8c9598f4c170f307f0c9fb7116c7544c657a082011c41e473555e668629a368a550f1b8d194f104626073b34326d4c7a18cfb683d3a83d4f01f26fcb994c63e0bf54a475750e8432b0d558722308670180c06030180c06030180c06030180c089234f76c1a150f4e9feeac0ff2d4fd23f31c8eba4254ddf77cd5afb6f6f76e5d14b7d92e44b5a6f73a6285ca48ebf7680eb224aa8e021f98f1fa73588c2b32dbb46e11f7aedd7b64df127dbb78d96758b7434669214f77a3a95e0b084164746d7a75d472392849a5b7edd1d38f68da2015361a848d1387bcfaeada9e646bc58f89ccad39f82f1185b001400068070006106030180c06030180c06030181e278219e268a55ea46e63130979a7b9cdb7ba55bedd7598e905b3e1e4b27edc56d8ea898caf81046a3883c8e6aabc4f0453c4d0cca1e371a329e44644c64725bb6c3156b304d60192ac2dfb8b7a753c2a79c727e28ce65318f82f13952cb5edfdc4064a40dd7b3d51d8ea5f8c296f6a3834e291ac67566fece6709747b4dfb37239cd85883c33345ee4058c4fd201d53af8f8e99284ec20c08b72cc81d6ad61d56a5e5e48be2c73c9cbe546d57dda5299f825d3a71d587db4f8989ea9243f3331e64e7cbee6e4de732d5bf282aedccf7a66a90369590e96661e3f917f5e74f81c39bcf94f445ad84b4448d151142a28d154780cfa388888c43099670830180c06030180c06030180c06030180c06030180c0604293af7099abc4dd35233a5894702c7f02febce473f9b88f1ab6a571aca6e75d8b45bb62055555324f29e98615e6cdfb313294fda76b35434f61849766fe2c9e0a3f02fa0cbd6b844cacb2caaa779ddcd7d6ad623eed97a99cfcb1278bb7ea194b5bb42d10e661ddde9bdc6e98a4a551baecbf51361a32353675d7a5934e3a0e391104cba204300c38823507d0e40606248d24464750c8c34653c88c08f5ae58da4f44a4cdb693c1b89787f4f9ae22d8f826632d9dd1b9ef6942083b760fb8dc3717f660b857aabd652a4b589bd140f857ea6d066aa3e7ffd3eb8db6dddcf62d987f36dcefef13d8dc2ed966754a49d0af3cec3eb90f52c49fa81c0efee6dd3edaed3d3532d263d52d51cd3f347e9e63329ae3a2f1397b8678a78c4b130746e4462247bc20c06030180c06030180c0603018116c4d34b30a550813b0d6594fcb127e23ebe4323da12acee4abddf4cc15bb66435aac15e4b535848639e4b3655804aefee03d2b203c5978f91cd6230acce5ce6c1b65fdcf7fdde86e3b429a9b8cb0cddcbb35bb0b6bd895e3d60b952c8f990fb5d262e68402ba71c943abab436dab59b65d8a215b6c472d7265d4b4b21f98759d5998e9f1313af86656b67485a230b48e348d1638d42a28d154720303380c06030180c06030180c06030181e648d24464750c8c34653e381a6add9b696114c5a5db49d124e6d0fa379ae22d8f827197408e9222ba306461aab0e20839aa832aba956019586841e441c0e5b79d863ae15ca3cdb72b16e98d99658091a128ca41e83e23329ae3e0bc4e532a2d65ad12d50a2b8502209c140c0db8423dcb4610a91afb9625e11443c4f99f4198723911b55ccaf5ae5ba85115959e43ee59978cd2f99f21e833e5b7b7a772d996c95988aebf6a59a4fb1a874908fdfcde11a9ffa8e7bb87c49ddb7b22671ab741045044b1443445e5e7fa4e7d3529158c43099cbde5906030180c06030180c06030180c06030180c06030180c0876249ad4c69d63d3a7fb89bf08fc23f31ce6f3b991b71e31d5ad2bde5630411410ac510e9451a019f3969999ccb444b7692b45d6c0b3b1e98e35f9998f2033ed665e7884bda36b7898ddb7f15d9469a7846a7e85fd796ad7bca2656b97555bbb6e86a8582bafb9766fe1a7828fc4de832b6b61310e4f74508b636fb48ca93fb3236eae3ae2363afad5251f83a900ff8652216997aa5b02cf6646bb423af5ba001046fd486427e2317485e989c7cc9c9b2728744380d0721cb20301802011a1e20f31811617b1b53992b832d027596b0e2c9e6d1fecc889c27ab776aec1db3b1edd3bec912c35ee4af6ed4c58b33c8e756677624f0f2f0cd6272a392a5dc7d5bc58ef5dcf769f6decb43f6fb5d49c102d4ce7a3ee3a0297119ff002d7c7e63923ab969a491a6edb23a4f05851234519063950f1eb8c8e1d599dabde168966ada86cc7d719e5c1d0f0653e446444e52db84180c06030180c06030180c08d6ac4bee2d5aa03dc97e51e08be2ede9913ec951770efcfdbd6a86cd1ecd2ef14b7b8a636ae432a895dd57564890fcefd1c54750f4cd2b5c2b33967fa71dcfb7ee75ae76b3d892c4bb6461216955e29da949aac625d74612c5a1898ebc4af56bc72c84fa9b46d3b4452ecbdbb09af1c8fd7b85b69249a4d7a42f4996567919ba400356e0333b5b3a42d11dd6704114112c510e9441a01911097bc20c06030180c06030180c06030180c06008041046a0f020f88c08f4feeb6e9fa6b8f768c9aeb093c622013d4a7f0f98c9a6938ec5ba3e690ff503bc2d506dda7df60daeacb61a082068237e2a8b23004aeba2ac839f3cfa1b7136eb6f18a4de71eae2d3937b4794de2919f474fd8fdd5dc93f765bd8377b51ee11ad61622b2b1ac7f0b2c6eba04038324c35d73cbcae3d236a2f58f1d718fb7c1bf1f7effbb34b4f969d5d45edb26a2ed6a8275d76e33d41e1e6d1fecce3dab8d61d389697dcab0aa2c21f703f08d07cc5bf0e9e799ee6ed695f295a2b33386ddbe9c885acd9d1ad4bcc7822fe15cf97e5726776d9ecdfa689b9e510b70bb2215ab5be2b728e1e48bf8db3d3c6e3ceedb1074d658a9552b45d0a7a893d4ee79b31e64e7d4ed6d452b88616b665bb3454c06030180c06030180c06030180c06030180c0603018112d5895a514eaf1b0c3577f08d7f11f5f2cf1733971b518ff002694ae7594da9522ab008a3fd2cc79b31e64e7ccdef369ccb56eca0d3b4ed72997f985e5d2c91a430f3112ff00ee3e39f6f5af7979a67b2e334550375dd129441547b96a5e10423993e67c80cadad84c4655952ab465e69dbdcb7371965ffa57c80cce216cb7c889246d1c8a1e37055d186a083c0820e4a1900280a06800d001c80180c06030180c086f0cd52479e9a878e4d7ee699f9240781d0720723a744a8fbb7b7775ee59eadfd9b71582bc1ed75c32f52bd49abcab2ad88827361d3d2c8c346079e6b1312acc61affa79b65ab3623ee859cedfda4b57dbedcd83e245820d3fdcca7a80ea9578f4383d1e79285caeebb0ef3bada8f60b892eeb49164b2a81bd9911c955d5f4e86d4a9f8949ca5abde16894cab6d27ea42a639e3e12c2df329fd63d72b129c37e106030180c06030180c08f6ed344521857dcb5370862fd67c80c4ca6167b56d6b4e26690fbb6a6e33cc7993e43d065eb5c2b33971bdcff00d30b136d92c1db1b836de4c8b662a763aa7823b08dd6b34058fb90480f2d094fc99642facdab1fb9acab0ff3c92044dc6e44bf0c7a0d58293f169d44f482733b5bb42d10d95ab455a111443451c49f127c493e672223096dc20c06030180c06030180c06030180c0603018191e23c4ab01fa4a9196af5845ba3e49dabba4ddbbb758dab75edeb57668ec9755f604918eb558e43abc52f1411eabd2746d7439f47c8db8ddb45ab7888c7aff00770762ff00b7135b56675f4fece83b052fee3fd42dc77cfb09eaeded5fd946b09ed9e02244e1d2835658ba8851a0e59e7e64c576229989b67faff57a38b136de9be26231fd1f53ce3baaa87dbe88bc6d451857e3cbe5d4f3603cf3e5fea3caaee5f14e91f9bd14cc4376731745bf745645541d7665f8618fccf99f419b6c6ccee5b1034d3abecab3bb75d894f54b21f13e43d067d4f1f6236ab88636b65233750c06030180c06030180c06030180c06030180c060301811ae5a68ba618475da978449e5f98fa0cf3f27931b55ccf55e95ca451a6b562209eb99fe29a53cd9b3e5b77766f6ccb649cc856ddb325994d2acdd207fb9987d20fd23d4e74385c39dc9ccf444ce357499f56f2a1ee7b943420f71f5691cf4c310e2cede432b6b6131195456af37b8d6ed90f7251f11f045fc0bfa3338f595a5272506030180c060301819c0893579a39fef29308ed0f9d7e89147830fd791ef0944dcbb7760ef0aff6fb9359482088c72ed31ca61895cf112e91856623e9e3d3e6b9a56d956630e4fb5f79b5db2f5e3dd2d46adb858b335bb36d12068b6da5fe9a9810a74e925811ebd2abc5babe1cb21f427af4f7ba706e5459e199d03d799e3789fa4f10248e408e01f261ae56d5ca62516b5a7690d6b29ecdc4f9a33c9bf321f1199c4ac939286703180c06030181a2ddb15d1745324d21e98621cd9bcb13294eda36a6add566c9f72f4c3f78de0a3f02fa0cb56b85665679742af78dd1e1229d4f8af4a387946bf8dbf5652d6ed0b4421d4aa95a32a097763d524adf3331e64e562132dd84180c06030180c06030180c06030180c06030180c0f625940d03b01fa4e4887664b95646bf5e524a8fdf4323128ea3cb53f09ca4cf8ea98d7459a5f16ab472c6191245ea218687f4671fea1f518b57c29dfacff0025ebb789d5e7386d42242a7db5eb70350bcb5fedcdf8fb16ddb78d51338556d4166b32c9609fbdeae89636e0635fc2a3cbd73e8f85c68db8ff00933dcb67e085ff009753fe4fb86e1f68feed0b2d4d6af58d647ead1086d38061e99edcc33c267fe41b304d669d607278463dc94f488d246242a70e9f738f86341b9775da5edfd9a5c8dac75040007e9ea28250bd7d3d1a943d438f2c603f9a6d4639241697a622030e993a8927a4742f4f549a9e1aa03807dd36a45819ee46ab678c2746e5a8525b87c0013a12da71c60698b7fd9a5167a6492335676ace1e290b3ba0d49455562c3c7872f1c68272bc6f1a4b13ac90caa1e2910eaacac35041f2380c80c06030180c06030180c06030180c0d16ed2d78c683ae573d30c639b3665bfbd1b75ccad5ae65ef6fa2d0069a73d76e5e323f90f055f419f2dc8df9dcb665ba6679c40bf725f7053a87fd430d5df988d7ccfaf967b389c59ddb7b226711997aab5a3ad088a3e438b31e6c7c49cfa7dbdb8a5710c6d3995b6e17e0a359a7978f8220f9998f25033799c2911952411cf34e6f5cff0070c348e2e6b127e11ebe6732ebacac9592830180c06030180c060301811ed54323acf03fb36e3fe1ca3c7f2b798c8984e50a7db369ddaec9b94bb7c03bbaad56829d89875000166429d5f0901db5e5a8cbd6d944c390fe9876877354dfe0dd2d35981122957783b81636e7b72ac65d7a959e196159448f1b8208eae9d3400e5d576f3ee9b6eed7775825e9ad536668a13bb33aa05b4e3a9e305b41f02b47af1e25b4cadab94c4e1ee1b13453ad3bba2ccdfc19c7f0e55f020f9fa667d3495941637d6b17ea59ad23c514684da80b3160fd7d02b984291ee3ebd43561a73cbc421d06df796ec523889e078a468a5864d3a9594f11aa9653fd872049c80c06069b76a3ad0991f89e48839b31e4a313384a56d1b5c88e6f5d00dc907c0be1127e11ebe796ad7bca2656d97555dbbeebf68ab0c0049766e10c5e5e6cde832b6b61310aea753d80ceedee5994f54d31e6c7f6652216948c20c06030180c06030180c06030180c06030180c060300480093c00e24e041890ee72f5b0d28467e11cbdd61e3ff28ce173f9d9f96bd1bd6b8f8adbd072ce32cc8058e806a4e6bb3b56dcb456bd65133855777778edbd9f46bdbbd04d616d4beca8802121ba4bf1eb64e1a2e7d571f8d4d8ae23af7961ada53290a7bed1dbb7cac1ebbcf1473c45b40fedc8037448012391f3cf4e33aa3a68a6ff00c3433ba9b0c142d81227b6e11a49666962975d3898faf4c60cb35bb5a386c4d31b6adeec33420741e1ef43145af2f0f6b5c818adda7047b78a6f6c303662b0eeaa41e98e92542a38733d05863104cb5d6ecaae95648156abb2a2471cbecca5995240ff00bc6eaf8797d3c8f1f4c789965fb3ed0a72c2d7c916ebc94ae3c91925619483a42da0d0a8d40d7f4f864e1396d9fb6a69e6655b88d55ed4967ed9d1cf50953a487e9d0fc0788d0f1f1c8c2163b76da76cda36edb8b7b9f655a3afeef4950deda85d403fa31832dd90180c06030180c06030180c06030355ab31d688c8ff00a1547366f00329b9b9148ccad5ae651a8356175beeec447742aadf6bd6bd7146e484d175d7e2e93c7c74cf98e5722dbb39ff0016da468b6cf1a50f70bcd0f4c100ebb72fc8bf847e26f419e8e3ec4ee5b103cd4aab5e3235eb95cf54b29e6cd9f53b3b31b75c430b5b32dd9aaa8b1acf72c0bd717a48ff006d5fc235f33f98e4759cca7a2564a0c06030180c06030180c06030181a6d548ec2aea4a4a87aa299783291e58984e5ee0ddaeb4525098a45b9346c2a58607da91f43d27fb0f3196adbb4a261f25eeaed6abb56d5b36c9ddfbb7dfee7bb5862b5abab082145733da960817e39e6919c46a48ead1f80d172eabea1b143bbee94a45ddf6d8f6ddafa635dae9972d6e3441a06988d55188d3450751e3c722632989c21ee7b6da86c568e7b26bb43216a9b888d640c594a15915b41d5d2dc0e67d3aadd559b7d2b0d6e38d16cc7662b5ee4b2bf52c71c2add4c1988d257b038311fe196ca1d66543035d8b115785a594e88bfde4f801ea713296cdab6d965946e3794897ffaf5cf28d4f89fcc726b5ef28995d668aa0eebb9a518468bee5894f4c108e6cdfb078e56d6c26232abab5a4567b165bddb937191fc00f055f203338859232506030180c06030180c06030180c06030180c06030180c082dd7b8cc608c914a33fbf907d647d0a7cbcf38ff50e6e23c2ada95c6b2b54444508802aa8d1547200670976259238a369246e9441ab31f01888c8a9ff005d75fef2395ab04ff689a73fcce3f37967d07d3f87348f39eacef6ec93257d93b8e24a3bed1867b159bac579d43af56847b91ebcf81ceb44c4e92cb58e8bba94ead4a9154ab12c35a0411c30a0d1551468140f2033455c1dfa94764dcb78bf4eaf5cd46381eaa339088d2f0673d474d38f8e673a2fd5b27ee2df638a1aff006f0fdd4934f1fdc892b11d10471c8bee0ebf6919cc8411d5ae835c64c360ee0de1bdcb4c2b470577a8925440b287fb93d2e44ca4f01aeaa463284bdf12849bf55a3bacfed6d66bcaf044d27b514d3aba86eb6d46ac89c547e939322a6c6e53c05eeecf79ac53dbf68b3611aca993df5af22b05d5b4d41d34eb1919f44b66e3dd173efe7ab0fb66a486cd52142ab23c50973a127dd2daf33d3d3e471e461136edf775af02d5aca2479e577f7a668f41ed441ba07bccabc7c78f019194cc2c57b8b786964b0c95c578ac53aef4e30b2757dcd48e77e9994f1d1e4d148e072d94234dddfb9c11fbea6b5af7aa3d95a88a15a0713ac4aaec7c17a8ebafd5e991930bed9ed5db54e66b8b189a09cc2af1bc4c597a5581916167547f8be5d796984266406030180c06030180c0f13cf141134b29e945e6722d68ac665311972bdd1bdee14bf972c2218373de2735f6f96d9fdc5640bd4f2b0faa4d3e55f139c1dddefdeb4ccfe8af66bfa74870fbbdcd8376dcb6db0fbecb67bb76a9dabd3eecab49d36a5b0cdac75ad327542daf15f9b8127148b5627e5f927fc73afc63bab2fa66cdbcf721db0bf706db150dccc86282ac1309d65e903f7808f9518f100f1039e78bf62b6bf8d272d23dd634eab441a598f5da978cafff0048f419f49c6e346d571dd95ed948cf4286030180c06030180c06030180c06030180c0d766b4362231ca355e608e60f983e7898ca5aaada8e0b7026eb1a4af175252dc19412a1f4d509fa49e91c7c7262d8d25130e8b3455e2c5786c42d0cc81e371a329c898c8e7e7867da582c84cbb713a24dcda2f257f35f5cce631f05faa5060c0153a83c411843ccb2c70c6d24ac15146acc70979db36f92f4a97ee274c0bc6a573ffee38f33e1935ae75944cafb34551371dc60a35ccb27163c228c7ccec7901916b6131195357826799aedcd1adc9c947158d7c157f5e65ef2b2564a0c06030180c06030180c06030180c06030180c060301810a7925b539a559ba40ff007338fa47e11f98e7379fccf08f1af56b4a7795941045044b144a15106800cf9c99cce65a3d9214124e807124f9640a962db9cc18f0dbe33f00ff00bac3c7fe519dbfa7f07fcacadad8d3ba77f8676d8345aa69602b0631cf1f18665e0ca71309ca5ed9bbbbcbf657808ee01f030e09281f52faf98cb56dda5130b230404bb18d499074c8481f10f23e79755a5f6ca2d53ed4411ac238a27429553e07a4f0c8c272a7fb89eacff69b8471f54847b56020092f4fcbaf932e67998d2538489563990c73c693213d452450c35f3d0e4e47a6656043468c0a18882838c679a7fcbe98c8f2cb0b486468623237cce51753a0d39fe8c641d2178fdb782268fa8374145d3a8723a79e323d164627ae34219833e8a012c07486d4788034071930834766dba9587b31fb934eead1ab4e7aba518eac3f313c35278f0c0988112358a3458e25f963401546be830190180c06030180c06061dd2342ee42a28d4b1e40644cc446652ad97eeec412ee095cce95d19e8d22c10caea35058b701af86b9c0e6f33f72de3138ab688f18f75476ef707687f52f6097ee284766b45285b3b65e4491e3954023ae33ae9cfe13e3cf3c9bbb77d8b693f7c22262512ef6d6fcfed51dce5dbeaf69d39c4b576edb6291279c237541049d5f02a8e67a39e99a6ddeb3fa73379f53c665d5d5af2995addae3664e4be11af828fd79dbe271236a3fe4adef9d23a2567b19980c06030180c06030180c06030180c06030180c0f32c51cb1b472287461a329e470969a97e7da9845658cbb71e11ce78b45e8fe6beb88b63af42632e811d1d43a10cac35561c4119aa832aba956019586841e208c0f906e1dd7dc09bc6f75a85dadb46d5b2c9ed7ef6149b52d218d38b82dab30f3d0675f6f89b55a57e59bdadeee5db93b96bda3ca295afb3ded1dd5bfbf71ec94b71b75b77db776f8e268e148829577427e10092af191e591bbc4db9dbb4c566b6aa69c9dcaee5626d17ad9f5ece4ba68f7aec14ab35898e88bc80e64f8003cf22670988ca8e249ed58fbfb834908fdc42794487fea3e39975d6564ac94180c06030180c06030180c06030180c06030180c06030225a9e579453abfee1c6aefe11afe23ebe59e2e6f2e36ab88fd4d295ceb29b52a455611147cb9b31e6c4f3273e66f79b4e65ab7650555899b7198c11122946749e41f591f40f4f3ceb70385e53e56e88b5b1f14d555550aa3450340072033e82230c0c20c0d56aac5663e87d4153d48ebc19587220e26329cb6eddbb4b0ca94b7123dc3c20b5c964f43e4d935b76944c2c771dc696db467bd7a5582a574324d2b9d00519a2ae1362ef79b7b977f9fb8eb45b576dd55a8db634faad8d27ebf8e7d7e477f81914710a465671dd30be0f3d0648acb196a49a7db5cf3d792c9ebeb99f4eab754cc94180c06030180c06030180c06030048009274038938143be6f346a6d76b79dc3dc1b1edca6598c6a59a40bcdba47355ce372f953b96fdba3788f18cf752f7d5adef7cd9f68b9da523dfd927677b8f42e0a3232f47ee5bee07c4b1abf1902e874cf071e2b4b4c5f4b7bc67f244ce7a28fb6aa3772ee37378dc6ea57b5b67b301de7619678a3b5114121a92bc8cc67f6c9d3af9e6db93e111588ce7b5bb7bfb22b197d22bc5359985db4bd247fb784fd0be67f31ce8f07871b71e53d4bdbb42667459180c06030180c06030180c06030180c06030180c0603004060548d41e041f11811609a7da58b460cbb713abc238b45ea9e63d3113e3f04f57415ec4362159a170f1b8d55872cd2272a3e352db93b7bbcfb8db73da27bb5b7090cb046910951fa2532461ba9245e97d74d79ae77a2bfbbb54f1b444c38b36fdbddbf9566625ee8599b7feffd86c6ddb54f4e96dc3595648844a8199e47d02a46ba2349d23c5b9e2f11b7b368b5a266c5667737ab35acc443ec366cc15a079e77091a0d598e706670ed39f5336e1656ed95e8893fda573f48fc6df98e65d755fa2664a18c06030180c06030180c06030180c06030180c060301811ae5a78cac100ebb52ff000d3c00f166f2033cdcae4c6d573dd7a572a3d97bd7b5ff009b7f278a791ed4cd2aadf742b5e79a01acc91ca78314d0fa7967cfef6d6e5a3ce5a7943adcf12cadbb624b52b51acdd207fb9987d23f083e673a1c2e1cee4e67a2267119488a28e18d628c74a20d1467d2d6b11188613397ac94180c060789ebc5622314abd48de1fac626329419e2a73470edddc110b94239525ad3c9af4fb919d504c01d1b43cbab86227b4931e8aada7b0afc9dddbc6f9dc33c72ed62ff00df6cd4519bdb0c2bc517bf635e0c53dafddaf25d58f88d3488556fb1efd6bb9f70b7257af1ff00e2712b5786c4aadee5cb01875490f1d0429a15048d58f2d34e31d46d9e19f686e9935976d3f24dcda2d7c1ff002fae67318f82d1aa502180653a83c411cb2506030180c06030180c06030338141bfef942ad29eddb94c7b5d621667404c93c8c74482151c599db8683395cce4cda7f6e9d5b56b88ccadad6ddb7ef1b3fd95b8196a5845ebaaff0305e042b053fde3385169adb31d56eae793b366d8f7f3b8ec33c55b62bacc77cd966526bea7899eb282047213f30f95bcb5cdff7fceb8b466d1d27bfde8f1d745bd3ab14ded3a42b5f6f83fd9d44508a38fce506807a0ceb7078731f3dfaa2f6c690b3ceab1630180c06030180c06030180c06030180c06030180c060301819c08bb32ca77594d13d34175fb907e4327ff001faf9e29d74e899e8e8f3550c0aadfb6eb16e38a580877aedd62b3fc8ffa7d7cb297ae56aca255b71d9425415910f4cb13706461e0465627296ec20c06030180c06030180c06030180c06030180c06030345cb62ba0d075cd21e98621cd9bf6663bfbd1b75ccad5ae65caeebbe77052dde4daf62a75efef6954ee178da95a206207a561842ab92598e9af219c0bcc6efcf79988ce1accf6854c747b3a6ec4edadc1b65dcb77db4a99b6ea70692c901b6875ebd1e0e00315075c4db72372d1e5113dfee574c3a0ed2afbbedbdb3476598b0be158b2bc8666ad033931c6f21e2cf1a10bafa65a9b1fbfbb331d168d2332e8eb568abc2228c701cc9e64f8939f41b7b7148c43199cb665d06030180c060799238e48da39143230d194f2381597eb42db5dad9b74324bb1dd8da079519965895c69a7503af4f91c44e3e0998cb97ee3df7b93b3fb728ecf3588e5a0629953b82226a95820f6fd9857a21b51a5878d9fa5993a0f469c0b70bcca22123b43bf7737a9b6ecfba2fdcdfb8ed333ee0f141341b5b3010497957e1fb8975e958d17e2e7c06b8ca30eb6dd3976a632c00c9b61e2f18e2d16be2be6b949ae3e0b44e5be391244592360c8c35561c8e10ce030180c06030180c0ce0419e496dced4ab374aaffb9987d23f0afe639cce7f33c23c63ab5a57bcb9bef7d877dab736cee3d8abaeebfc8d253ff8f4cfeda49d4bfc681c03a585e43ac11a13a6878e7276376b3135b4e3cbfcbedd936cf55476c77334f551b66b8bbc776efcfef6e734cb2256a11427a5d658490621083d089f33b733a7c434dddac4fcd18a57a7acff00aa225dd166dce50cdfec223f08e5eeb0f1ff009467abe9fc2ff2b2d6b634ee9d9db606030180c06030180c06030180c06030180c06030180c0603018111fdfbd68d0aadd2abfeee71f42fe107f11c8eb384f474156ac156048205e88e31a28cd6230a4b61200249d00e24e488d4772a57839ad2893db3d2c391fd3c7c0e445a2533184ac942af74da3ee1c5aaac21bc8340df4b8fc2e3296ae755a2506adbf759a2954c56a3e12c2dcc7a8f3072b12948c20c06030180c06030180c06030180c06030180c0d56acc75a132bf1f0551cd98f20329b9b914ae656ad732f346a4aa5aed952f69c7c318d3e05fc0baf0d73e5f95c99ddb7b36d234845ed6df36bee2dba2df2a41ed4cfd75e6595545889a37d1e1908d74218711ae65bbb76a4f8ca2272e23b07b5bb97658e99df270fb86dd5ced9b26dd03110455a33d26d4a01d1e4940f1e4386746d8deb78d23ace667f97c115ae3597d06a545af191a9795cf54b29e6cc73b5b3b31b75c433b5b2df9aaa6030180c060301802010410083c083c41c0af78d29c6f0cd08b7b3c8c1a6ace03fb655830600f35046ba64671f04f5717dcbdb5b7f6e4d67ba2856af7feea04aab7f7073221b972e4405abac0708e01c7551f0a823865a50e83fa5fdc7dc9bc7f3383781ef4551a344b5edaac6d232eb22c5223491cf16bf23a9e5c08d72f1285fdedbe4a12b59a23ae06f8ec531cc7e78c7eacce6b8e8989cbd413c53c425898323788ff00038894bde106030180c06030225a9e592514ea9fdfb7f11fc2343e27d7cb3c3cde5c6d4623f534a573aca6d4ab0d5844510f847124f327c49cf99bde6d3996b2dd95140b436f9b70b8f46bc75e3b2eafb9598d42b58910680123e6d07339d8e0f16d7c4dbf4c2b3315f8add555542a8d1546800f019de88c3130830180c06030180c06030180c06030180c06030180c0603018116c4b6269c51a7fee1c6b24879449f88faf9647b42577428414ab2c108e038b31e2ccc79b139ad630acca4e4a1cfee371b7299a9c0c4518ce96661c3dc23e853e5e6732b4e745e230d72d228e93d2220b308d1081f0b28fa18796463d05a6d7bb4770344ebecdb8bf8b0373fd2be6b9a56d956630b0cb210373da62ba16456f66dc7fc19d798f43e632b6ae5312abaf6a4f78d4b69ed5b4e3d3f4bafe243e399c4f6959272506030180c06030180c06030180c06030181e269a386269643d28a352722d68ac665311968a35a5b128bd69743ffd684f2453f511f88e7ccf37973b96c4746f1187cb3bd7bd367ddb7adaa5fe75776adbabd9976ebd0465e958af6d982c7694c8bd332237c0e06a02bea736d8d8b56b3a44ce33eba7a7b7f66732b8ed1da3b8bb4fbe2fd0b1b80dea8eff0059f7159c442168ecc1a2979154b269306e2c39b6994dd9aef523118989c7e298d25de53aad1754b337b96a5e32c9e5f957d067738dc78daae3bab7b65273d0a180c06030180c06030180c082f0b533234510b1466d7eee8300ca41e6501e1fd991d13d5a773dbfb86eed9053ecdbf4f64db442e3ee3d9334c927d31a427a5157cdb5d4796691398d15729fd3ab9153dde5bd7ebc9fcdf76b4db345d339b2d2b6dc0fddd8776e90c9ef062a4283d3a70c884bbedc36992191aeeda3e32759eb7d320f35f26c8b57bc113ead55ee413c2650dd2abfc50dc0a69cfab5e5a6444e52a9abdc2544b66fb4715291c8a1d0ae659235f9a42806bd03f17f6f2c64c2ed1d5d15d486560195871041e20e10ce03018116e5a91196bd71d56a5f907828f166f419e5e572636abeebd2b96c8c53daeac8f2c83a80eb9e427e2627c7f667ce457737ef111199b4b5996bda64bf65e4bb3931c12e82bd6238851f51f539e8e6d76b6e236e9adabfaadefe91ed0ad733ab172c496e66a5589545e16a71e03f02fa9c70b873b9399e8b4ce212628a38a358e350a8a340067d256b158c43099cbd64a0c06030180c0606cfb79bf01c9c487dbcdf80e3064f6241a9652140249d35e006bc864e0cbc44d0cdd420904ae9d2648c021d3ac6abd4a78839181964743a3020fae079c80c06030180c06030180c06046b5665574ad597aee4dc235f051e2ede8322652b6daf6d8e8c0541eb99cf54d29e6cdfb3cb34ad70acce5372c851eedb8496666dbaa37481c2dd81f483f429fc4733b5bb42d11dd88218a08962897a51790c84bde108f6aa098ac91b186cc7c62997983ebe63226129db5ef0667fb4b6a21baa397d3201f521fd597adbb4a261699755c84ddcfb06f7ddd3f6940b2497a9d57b726e1181edc4d1c8b198d5fea705c7501cbc72b6ae531384b8e7b15ec0a7780129fe0ce3e4940f2f23e999f4d2564ac94180c06030180c06030180c060301818775442ee7a5546ac4f80c4ce354a8b73df36ba4b5b72dea53576c9274af519d5ba3dd935e879980d114e9a02dc3383cbe45b7a66b4e90da23c5c577b47b9ff00e4f761d89b71ddf6fe85bbdc5429ce626a8ea02c52d39c711314d58c03e6035f2ccb631e11e5889e91eff1f6f7567aa476a76e2588eceedb8ee55fb9bb57788237861b5582da6b513008645d3a7ac0ea573f31206bcb1bb79cc56b135bc4a6b5cbe87452cac5d53901dbe5897946be0833a9c6e052911368cd95bdbd1233deccc06030180c06030180c06030355bbb4a9c426bb662ab093d2249dd6352de40b11c734a6ddaf38ac655bee56bada70a9fe7fb157b3f73b7ef340c9211ef55fb98fa65fd1c78365fff0026f46be33f833ffd3b53fe51f8a2eedd9bb6ee36937786d5aad4b6ca72c126c34b484b3bb995fe35f8c7b9f2b01c18665d5b39efe95f72f74cfb96db44c7036c566b3ccb5f6f894d2a71742490c4b3aeacb327b863923974274ea1cf11d512fa46edb27becd66a055b0c349636fe1caa3e961e7eb8b57bc2625c9ee6b602dfb80c71c7eca4162170c2785352ad1c7c3a02375716f2e394cac9db0bdefba310b2b6a9450059595408d26d57a23858730a9af57ae992895e6106047b96fd855545f72c487a618c789f33e8330e46fc6dd732bd6b96da147edd5a494fb96a5e32cbfa87a0cf97dfdf9dcb665b2b771d8addfdd7ee1e458ebc7d21011d4481c7972e67c73abc3fa96dec6c78444cda72cad4cce536eda959c51aa7f7c47ef65d3846bfb4f867838bc59ddb7b3499c465b2b568abc2228c7c2399f127c49cfa7dba452310c2672d9964180c06030180c06072e9db5bd4fb7c0d72277bf1d4a0824321eb5963004e41d79f99f1c9c19493b3ef34ad31ab55a4a8ad7a3ad5d1c28459d4188807805d75fd1938328753b5f798e87ba60237359ab0493abe210a6d91432007cbde0c08f139184e51e7d9f71d96959dd22aab0ee95c549aacba802690a181e17239ebd7ae87c74c630672eba8d434f6fad5096668631ee163a9eb73d6daff006b6250db90180c06030180c06030181a2ddaf6155517dcb129e98221cd9bf60f1c8994ac368dafecd1a599bdcb93719a4ff055f419a56b85665639642a376dce5128a148ff00aa71ac92f84487c7f4f9652d6ed0b4438bb322da8ea37f2d12d18ec3c612675612c8df074c80ff000e424ea85bc7864446099cba1d916e2d464b0aea8ae456598eb288be9121f31ebc7cf02c3203034daa9159401b5575e31cabc194f9838984b54d6f70b7467d9e5b8db75f9d0c75b7489549d0f3650df08934c9adbb4a261c4af6d6ed1779d9edaedead26d9b4c1b7c1059dec020886773258113f36b32b28f8fe9f9b9819a2aed77bdcfb2b60dbe9ecfbb5c8a8c2eab0d08e5621d8ae8aa10f32dae44c6531387a63636e9857badd70b1d20b7e07c95fc9b32e9d56ea9592830180c06030180c06030180c01200d4f00399c082aa7729753f0edf11e27feeb0ff00a4670fea1cdcfc956f4ae3e2ac4ef1ec5dfaecbdb2d3456cd85922fb69632609d633d32a465874bf41e074e59cefd9dca479998942ed2ed5b7d916ee52a924527684dd76a01270b55e724031757f9a8cbf293c574d396997dedd8de8899fd7fc4ad70e86b42f3ca2e585e8d3fdb43cba14f89f539d9e0f0ff6e3ca7f52b7b7684dce8b230180c06030180c06030180c060707fd46af15aee7ed1a938ebad62629347e0cad62253ff00039d9fa74e36b7263aff006972b9f19dda44f4fef0a1dfbb76d55ededceddedbe8561fb8976f9a9b86721ec2a31d072428dfdf9ead8dc89dcac45ad3d739f830dfa7fd73335ad7a631f17d036186c2ec1b35da8fd373ec6b7b818fc328f6c7c2ff00b7387cb8c6f5b1eb2eb71a7feaae7d217db14bb53898d5ad1d4b6edd57215508c5cfd4da0f8b5f3cceb312d6616d9642b775d9d6dfefe0222b8834593c197f038f107296ae5312ada33a81f68f08ad6211f1570341a7e24f35394895a52b250d36ed2568bad816663d31c639b31e40667bbbb14ae656ad7250a4eac6d5ad1adc83c3922fe15fd79f2fcae4db76d99e8df18d13b3ca216e175e322bd61d76e5f947820f176cf4f1b8f3bb6c41d35962a544ad1f483d4ec7aa590f3663e39f53b3b51b75c430b5b2dd9a2a6030180c06030180c0ac97b8e8acf1886bc9629bd88aa1baacaaa25986a3452352a35d09f3c9d04797bb6b43b453dce7a4f1437225b11ab4abafb2ea1811a29d5be2f97fe38d12dd2f7240b6da0868cd32fdcc74a297ad543cf2d75b28342380e87e27c3084fdbafc37a8417614e98e52dfbb900629244ed1b71d3c194e87191bc924927893cce40c6030180c06030180c06069b76a3ad175bea493d31a0e2ccc7900313384a5ecfb5c9131bb73437651a69e11a7e05fd796ad7bca2656b975559bbeead5ba6b561ee5d9bf86bcc28f176f4194b5b098853d8d9bdea26b8b32433bc8b2cb6e33a485d5836bc7f4723c32910b3456d93dc94cdb8463ee16456692191962b0538a4b244085eaf3d72d3285c6406030181aecd686cc462957a94ff00783e63d71309286e9352916a6e0fd50b70af6cf8f92c9e47d726b6c69289873fdc22c56dedb7edec2597accf1768ec71b12b258084895c9f84cd2724fc23d78e68ab56c3fd48a97f62a8fdcf1450beeb2c506d2605631df33c6b22fdbc6c59d5a3ebe870c783039131917f3453ed2e166265dbd8e91cfcda3d792bfa7ae6531e3f05faa50208041d41e208c94180c06030180c06030180c082ecfb8ce6b42c4558ce96661f51fc0bfaf393f50e6f8c78d7ab6a571acb8beebeefdc2b6f860d86c57dd763a51187b9768ada35ead182c1a6aea342e7a5be21a9e9e9ce7ececc4d736d2d3fa67b4fc4b5b5731db1db9bcdfab255a1b8d5bfb5a7dbc35bba62b67dcabb6c25665ac9540052693a3f7ac5be2d7e2f0d37dddcac4e662627fdb8eb3eb9f4f456225f5b40fb84e2ccabd3550eb5e23f51fc6dfab3d3c0e178fcd65af6c6909f9d662c6030180c06030180c06030180c06073bde1d9e7b87ec6686f350bb40b18670a5868c436a3a4ab060ca3420e7bf87cc8d9cc4c6625e3e5f13f77131389854ee1d83dd1b943257dc3ba8d8ad34a2796130c9d2580d0683af451e4bcb5e3a67a69f50daa4e6b4c4e1e7bf0b76da5afa3b3a5522a74ab5284930d589208cb7cc56350a09f5e19cbdcbcded369eee96dd3c6b158ecf166a33bad8aefecdb8ff008728f11f8587883994c2eb1daf774b64c132fb37507ef213c88fc487c46695b6559858e59083b9ed715e407531598f8c33afcca7f58f3195b572989537f306ac5e1dc17dab118d4683559072053f4f96637dc8ac66cbc467a36d1a924b2fdeda5d243fc088ff0096bffb8e7cd733973bb6f66d1188c2c33c2945bf745645545f72c4a7a61887327ccfa0cdb6766772d88148d3dfa566661124a23f69ee4cfaf5c9eeb74058483a0e8f5d73ea38fc78daae2195ad95dc72c3282d138914315ea5e2355e073d0cdeb0180c06030180c0603029ed76d7bfbc47684d1c3452cc36c431f5a92d02f48431ebd1a9fc5ff0d78e48932f6fecb2415a1314a8956aad14e895959aba0002391cf978606f5dab6a5916410bf52da8ee83d7fe74500aea7972f6d470c9c8d956ad6a7563ab550a43197650c7a8eb23b48dc7fe66390366406030180c06030180c0d76278abc2d2ca7445fef27c862652d9b46dd2c928dc6eae9291fe9a13fe5a9f13f98e4d6bde5132bacd1541dd7734a5100abee5994f4c108e64f99f41e395b5b0988caaea55788bcd3b7b96e63acd27fd23c80cce21648c94180c06030180c0f32c51cb1b472286461a329e4709565da7464a876cdee2373677606394b32c90329d54fb8855d743c9d4823116c75e84c65591ec3b276e5e9b7cdea38e6dbe9bc55bb52bc2924fec44501d123d1ff7f24bd5aca4927f1019aa8f3b57f50f71ee2dfea51a9520a9b633581b8d5bbd4d7523afd23f7d182ab5cb337c3af5861c41c0e86cd39b692658419b6c3c5907168b5f11e6b994c63e0be72911c89222bc6c19186aac391c219c06030180c060301815bbaee304514dd7612b55806b76e3b0558d7f083f88f8678399caf1f92bada5a52bde5c96f1fd44fb08e8d9daeb8b7d936d4d7b9bec22447a1207e97965575259743f8781e79caa717ca67ca7fecf4f55e6dddc6bf6a5d977ea9b5ed82c45b9ed894e3d93b9698415d6a7b6b2dcbf348ada4b25899dd591b5074fedcf4cef478cda7189ce6b3ebda3db0acc6afabedfb6d22a62a95e1828f5fb965a0892116ac683ae57540a0ea464f0b8b379f3bfdcb5a7c7e2bafd1c07967698180c06030180c060301819d3812480aa3566620003d49c91852ae9d71bac880e859195c03e5aa938c0f41188d469c75206a352073d07a6b8c02c6ec0b01f08e6c74007f69c606194a9d0fe9f3e7819084c9ed6abeee9d5ed752f5e9e7d3aeb8c0c15234e441e2082083fda3031903d2a96d74d38789200e3fa7270235ca6b3e875315888feea65e0ca7f67a644c2625336cddda47fb3ba0477147c27e8900fa97f665ab6ed28985ae5d540bab04ee9d48afed1ea5623520fa6703ea9cdacff00d75d7d65b6dd67abc670daa3ddbb1d487ad8753b1e98e31cd98f20334dbdb9bce20845a95a4576b367e2b52733f817f02fe8cfa7e271636abeecaf6cb65ea91dca92d594b08e51a3143a368083c0f872cf5a8f70411410a430a848a31a2a8e5843de030180c06030180c06030180c06030180c06030180c0607992448e3692460a8a35663c80c0f1b7536bb2aee17074568ceb5217e1ff00f71ff562b19d6499c365fdced58dc176ddad8095086b7634d563507e5ff98e6fe388ccaab0dc770868d632cbf131f8638c7ccec79003296b61311953d6826695ae5b3d56e41cbc235f045fd79947acac9392830180c06030180c060195594ab0054f020f223022c13cfb43eaa1a5db58eaf18e2d17aafe5f4c889f1f827ab96efbd82dc8f7776daea49ba4ddc52d2a13fd808e3963dbebeb237548cc9ab1935d58f25e1e03358951228ff54abd3dded6d1bf2a1b103c7f75f60a24ab41262b1c51cf348f1c9312ec033470f4af50074c91d35ddb26a0ed668297acc759ea0f0f368ff666735c745e272f504f14f12cb13752378faf91c8891aee5eab4e312da93db8c9e9ebe96201f52a0f48f53c3250de082010750791190180c06030225bb12b482a55e365c6acde11afe23fab3c7cce5c6d47fc9a5299d67a28fbc7b5f73b1436d6d9a2af724db6dadb9f6ebaec915bd011a3c8164d195be35d548d4670b67911e53e79f9a3afa34b465c6ee173b87df85a4ee9af6bb9a7b8958767ede627a2b1f574d982ca159266f875eb95ba40f2cf5d2b4c7e8f931faa7afb4ff652665dced5dbdb26dcb3ed9b0d614b6e794cb77a19c8690f0e88fa8b74a8d34d1780f0193c5d8bef4c5afd216998aafd115142200aaa34551c8019dd88c31670830180c06030180c060302b3ba403db1ba061aafb3f10009e1af1e0327b0aadc6e56ad667bbdb23db860ac4de78236f6be7fdde8a57a4b8e3ae835d3133e8946deb7bdc64ddecdca2eeeb45adc745d633a08fd9dbd9f41a7c435790eb8992219dff71b17ee5b75b73ad084dc8abac43a636068860a754f8b56274ff86267242f7b55ef472474adccf3c11d2a5346d2a8051e4565750401f0fc2381e39308956ec8db2c42b2ee30cd27738b9fea0c6b219ccc64d0b759d17d9e8e7c7a7a7971c889fc5328d42feebb4ecb55c4f33c53d49e4f6bda0fecb231e8283407973ea27cf4c8ccc418ca4edfbaeff6a54a6d69a31f793426cc6048e625ae255fde345129f88f06e8d3f4e4c4a2506fee3bdcdb4c22e5a76166b54b6f208b4f6643332b14551ae9d2a35075e3c712984db9be6faaa22ad30fb4fb9b11c7bb4bfba2e914513c7d4c229471924917827c5d3c34c664c2c76b9f72bd2dd7dc27f8228a248a3893a620f2a75348a5d164f0d472d31285a6cf7ef59a8c920f71636e84b401fde28f1d3f5e72b95cdb4d26bb71699f58869e1113aa4e7cf4c4c692d1950588038939aec6c5b76de35ea4ce1557a19a9ee5f75707bb59874c330e50ebe0cbebf8b3e938fc2aec6bd7dd9cdf3184c0410083a83c411cb3d8ccc06030180c06030180c06030180c06030180c06030180c0600900124e807124e046a551b76984f28236d88feed0f0f7987d47f28c5633f04cce163bfd3b76f6c7ab534124855492740175e3ff0cde93113aa88db5d34d836a91adcaae7a8bbba8d0963f4ea78b1d796372f13a9108d0a4f6ac7dfdc1a49cabc07fca5ff00dc7c73cfd7595d2b2506030180c06030180c06030181110d8db2433d4064aac759ea7e9faa3f5f4c8e9d13d54f0ff4df60dcb743b93d81736992c1bd1edd2463aa2b64a1622652add1d5186313023ab8e6b13952618ee0ef5a507784759ad39836a427f96d5fde59b97665d12311af1e8823d4c8cda202e84b0d3246fedcdc26ee0d8a0ee6dba94941ed9632edd31422408c57a94a92ba9d39e676af785a251aedbbed1df9a7b2dfcac2310910549149e060903fca7c9b91f1d322354b34379346c1ad72d472d58a155e8af1bb98e607f849d1d6d274c7c58e9c3c74c943a38a58e589258983c7200c8ea750548d4107207ac06046b96da22b0c23aed4bc234f01f99bd0679f93c98daae67aaf4ae5228515ab1104f5ccff0014d29e6cdfb33e5b7b76772d996c93990a29e8eddfcce53b754820bd28ff005db8471209343cd4b81d459b3a7c3d8beee9333e1089988d5650c31c31ac718e945e433e8ab58ac623a3099cbde4a0c06030180c06030180c0607a562bae9e3c083a1047e83923225751a290abf854003fb80d3191ae5dcea57b11559ed2433ca074a74f256f857a9954aa06e9d07511ae9a64e447dbf7e82e54dcacb4660a5b6c8e9d4c8c1d842a4b9e86455f45e9272724c314775dc2e146b5b7b53a762332c164c8afd2a0750138007b7aaf11a1231d47b5dfb6a303d81794246c91331470fac8748c0057ac873f291c0f86467dcc311770ed32ab98efa158e3795f547501231ac838a0e2bf52f31e2319f73045dc3b4c92a4115e4f719d6355f6dd7e271f0712802871f293c0f860c3d4bbe6db1258696ea225552d33146e90a87a5ba0f4e8fd2781e8d7438301ddf6d12c55dada2bcc0148de36551a93d21ba942a13d27a4369af8606b9674dd58d682d06894eb6474b233283a7c1d4abd6a4823a97519e1fa85ef5da99af4eebede225cdff513b1f7cee25db9766bf1ede94d264911e49a2eaf70a74e9ed2b6ba749e79e1e0f336e9b58b5b1399f55e7abb3ea586006570046a03b93c380009e39cce4da3737ad35d7329ac689f5e25540dccb0d75f4cfa3e0f0a366b9eb69eac6f6cb63a23a1470195868ca788233dea282d6dd3ed85a6aa1a6a1ce4afcda3f54f31e9994d71d1789cb6433c53c4b2c4c1d1b930c448f784180c06030180c06030180c06030180c06030180c0603022c503eef3989495dba26d277ff00bac3e853e5e7888f2f827a3a24448d151005451a2a8e400cd54799e78a089a6958246835663e0313239eeb9773b22e5852b5a33fe92bb7ff00b8debe598f59cafd133250c6030180c06030180c06030180c0ce04468ac549cdba1f39e33563c1641e9e4d91d3584a937bede827edddeecf666dd02770ef2ea97a49184527ef0ac739676e2a7daead34feccd6272acc6167db9d8e69cf5770ddecfde6e1493dba10c7aa54a89d1d1d30c7c3562ba8676e27d3250b5ddf641619acd50ab64af4c91b0fddcabf85c7ebca5abde168973516db3cb726fb464a41e358668c8227aea3e658469d3a49cfa89d72b129985fd7821af0475e15090c2a12341c82a8d00feec21ef0345cb62bc6345f72673d314439b3665bdbd5dbae656ad72cd4a8d56296ccc43db752d2393a28d06bd20f8019f31bdbd3bd7d7bcb7ec83b2ef37771bf206558ab46858281af51d741f16743ea1f4fdbe3ed44c4cdaf33f6d1952f3329b7ee4bee0a757fdcb8d5df988d7f11f5f2cf0f138b3bb6f66b988d65eaad58ab42238ff4b31e6c7c49cfa7dbdb8a5710c26732db9754c06030180c06030180c06030180c0addcf615bd3cedf75ecd6bab02dd8ba757ff4cdd4a636f0eae00f964912971edf02d4b952590cb0de92779ba47490b3f0d06be2327221a6cdb84b54d1bfbb19b6f5824acb1c117b4f22c9198834cde3d0adc00e678e0788fb70b491cd6aeac9344f5447d11955f6aa481c023f1369fd990659b1db30cb5da216c2ead7db5e83ff00de465f2fa7ab246d9b60af23cedf7207bd2d393e43c05350ba72fab4e1815cfd9148d6b75e39604f7925486cfb2def8134824219b5d341a69c3e6f1cae139594d5124de2dad7b9d315de992ed7f6faa4f82331e8921e09d4ba73e234e1cf31dee5ededcfcd298accc31b0f6dd7da1d991606223f66396388aca53ababf78e49f4e03f4e73b99cfdab6d4d6b3999f65a2b395c72e2796701aaa5dbf99cda7ff004223ff00eab8ff00a4676be9fc2cfcd656f6c7c5b6bcf63693f0f54fb71f9a3e6f17aaf9afa6772271f0633aafebd886c42b342e248dc6aac3966913951b32452dfd9e58646b9b680243c66abc924f51e4d99dabde168969ab6e2b284a6aaea749236e0cade446444a5bb0830180c06030180c06030180c06030180c0603033810cacdb8d86a55d8ac09feeec0f01f814f99c8c6744f471bbb77845b9ec332c5757b6763958a6c5b9c52335e9a4ad202d2c75d35d62f81b556e639f0cd6230a3a9ec4ee2ddae6df1d6dd6032357aeb20dfa16eba3710fcb2c521f165e2ca78ae48953cefbb4e1d815db623ac487fcd61f51fcbe5994ce7e0be309584180c06030180c06030180c06030180c060469ab4c938b9498476d46841f9241f85ff006e463bc2569b76e906e11ba15f6ec27c33d76f997f68f5cd2b6cab31873d5bf9aec574cd7e4965db0bb46ac18b05d4fc2ccbe47379c5a34eaaaf6fedb0ee0896ea4823b206b0d85e2181e3d2de6a730b572b44abeb5b7691ab594f66e47f3c67911f894f88cce256c365ab515684cb27e8551cd98f2032bb9b9148cc911979a14a4f70dcb635b2e3454f08d7f08f5f3cf98e5f2a776decf44691886bdcea5fbb623aa0fb5b791d53c80fc4fa1f934cd787bfb7b359bfeaddff0018ed1eea5a2674ecd96ec25348ead48d4d871d30c639281f51f41986d6ddf7efaeb32b4444414ea2d743a9eb9a43d534a79b367d3ececd76eb88636b65bf3554c06030180c06030180c06030180c06030180c060301811ee5a68ba22857dcb5370893cbcd9bd0679f95c88daae7baf4ae5be8d25ab115d7ae573d52ca79b31cf96dddd9bdb32d927321597267b931a7031102ffba987fe853ebe39d3e0f0e772733d1169c425471a468b1a00a8a34551e033e8a2222310c259c942284b34256b1406aac759ea1e0adf997c9b23a744f55d50dc6b5e87dc84f11c248db832b788619ad6d956612b250acdcf67161bee6b37b175470907271f85c788ca5a994c4a057b6cd2357b09ec5b4f9e23c88fc4a7c465225648c94180c06030181aaf596a94a4b4b5a4b7edea5e2899158200496f8f4f2c911e96f14ec57825b03f973da23ed61b5247d52a9e457a4e04dc80c06030180c0603018116679ecd8fb0a67494f19e6e62243ff51f0c8eba42555dc9de11f66ee3b7528eb0b7b63c324bb8c75d5e4b90a2951f76ca38344ba90fc35f1e433588c2b32d72768c52b26e9d892ed9b645b9a3fdeee8b07bb3fb72e8dd555c10a8799d1869af864a136850a90edb5761dafa9363db5160ebd753294fa41f2d79e6569cfc1788c2d9555542a8d140d001c80c20c06030180c06030180c06030180c06030180c08f6aa348eb3c0e61b71ff0e51fe0c3c4644c2729db7ee91dd0f4edc623b60692c0dc55d79752ebcc1cbd6d95661236ddaeb6dd13c55fabdb772fd2cc485d7c175e59a4da67aa18dcf6b82f463a898e78f8c33afcca7f6652d5ca6270a9a742c99fee2fb2bc916ab0aa7c83c3aff49cf98e7f26d6b4d73a47a3d35c63458e73528d7ef2558c70eb99cf4c310e6c7f666bb5b537b62047a755e2ea9a76f72d4bc647f2f255f419f53c6e346d5711d58dad949cf4286030180c06030180c06030180c060303d2a3b9d154b1f41ae06d14ad1e519fedd07f8e064d1b43fcb3fd841fd781a9e2913e752bfa46078c06069b7692bc5d44753b1e98e31cd9bc8667bdbb1b75ccad5ae64a350c01ed5a20d9906b237822fe11e833e5b91bf6ddb37e9a31b6ee52de9a678e302921e98653aeaec3991e99b72f895d8ad6267fec9eb1e9fdd4adb26e1725320a554ffa8906aefe11a79fe9f2ca7138b3bb6f65f38d65eeb578abc2b1463e11cc9e64f8939f51b748a4621e799cb665906030234d56459beea9bfb368733f4c83f0b8c8c7784acf6cdde2b9ac522fb3713f890373fd2be6334adb2acc2c32c843dcb6caf7a301f549538c532f0653e872b6ae5313853acf3d59c54be02c8784560704907ea6f4ccfa75592b2506030180c0c4b199609a10c14cb1491ab1e40ba151aff7e4c0e7f78ed6dcae548eb4566108b4d2bfcef1e92210496e823dc53a700dc01c4c272e872106030180c060301811ad5898c8b52a0ebb92f2f245f176c89f484a92d77cedddbb7a7db85495aa559238374de9b8a476ac2178c1897f7922e9a16e9e5ae695ae1599ca83b5d37add6cfb90eee6a777224ecbb9f47dcedfb8519651d2d0ab69d22160abd1a8656e7a8272c874bb1ec54b64da13b6765661562679371b9c01796525a40a0700598f10bc06676b67485a21791451c51ac71a85451a2819097ac20c06030180c06030180c06030180c06030180c06068b7512c2a9d4c7346758a65e0ca7d0e26131295b66ef234a295f012d81ac720e09281e2bebe632d5b76944c26d89f5f810f0fa8e71bea7cf9accedd3ef95e94ee8f9c06cd172e4552bb4d2f21c15473663c80cbd29369c408752bcad21b96bfdcc83e14e62353f48fd79f4fc3e246d57fe4caf7ce91d12f3d8ccc06030180c06030180c06030180c0d914324add2835f33e0302c60dba24e327c6dff000c0961401a01a0f2180c060080468788c08d350824d4a8e86f31cbfbb02aaea1a48d24fc235e3d43c7f47ae45ad158cca62328942b4934a2f5a5d1c8ff004f11fa14f89fcc73e679bcb9dcb63b3788c68afded375b7b8fdad557fb5e9559f43d2878f573fd073a1f4fb6c6d6cfee5e63cf33e3ebe9d19df3338859dab2b4abc70578c7bee3a6085790f53e83393b7b76dedcf599eed618a7505743d4dd73487aa690f366fd99f4fb1b11b75c430b5b32df9b2a6030180c0d16a9a4fd2e098e78f8c532fcca7f67a6261295b76f2fee8a7b801159e51cbf44beabe47d32d5b76944c2df2eab4dba95edc2d0d840f1b781f03e63cb2263228654b3b5b84b24cb449d23b5cca79093f6e6531e2bf54a0410083a83c88c94180c060301811668a7da5c24a5a5dbd8e91ce78b47e8fe9eb898c7c13d520c9180a4b001c858f53f331e407e9c215db5ef696e4b09288e210c9eda4a1c98dcea47482eb1fc608e2a35c9169903180c06047b969a2e98a15f72d4c7a61887327ccfa0c8994c296f770edfb7b5fd9769dd2ab77ac223964ab6755f75980758559ba575743f0853afa6695ae1599caea2913b83605dcb6515e96e560ac8b35bac27305888f43acb186898bc7f127ce34f039642bf69dbe5d936cfe4556cfdcdf9a492cee57910468af33753f4463509afd2ba9f5d4f1cced6ed0b442d2bd78abc2b1443445fef27c49c8884b66106030180c06030180c06030180c06030180c06030180ff000c08091ff34b0ae47fa1aedaa3723238f107c1467139fceff1a37ad70b7ce2cce5664024e8389396dbdbb5ed15ac66651338487a15a6aed0ce82457f981fd59f5bc4e2c6d6dc57bf779ed6cca9268ec6d4e127265a0c748ac7364d7e97f4f239acc63e09ea940820107507882391192830180c06030180c06030180c0606ead5de793a47003e63e5816f1449120541a0c0f780c06030180665552cc74503524f200644ca55225a776c452de9521a6cfd346195950cd201af5004fc5a0e4067cefd4399379f1a7486f5af8fc5bad56f688643d513f1461c739712940bb6e3ab0191f89e48839b31e40669b749b4e2044a75a50cd66c9eab52fcde48be0a33ea389c58daafbb2bdb2959eb666030180c0603035d8af0d888c52af529fec20f983e071319494f749e83ad7dc18c95d8e90dbf2f2593f6e22d8ea4c657a0860083a83c411cb355187447428ea191868ca46a08c0a0b5b7cfb5932d50d350e6f07378fd53cc7a66535c74e8bc4e5b229e19621346e1a3235ea1e439e322b61ee6daec5d8aad6324fee86633a2e9122a702cecc5741af0d74e78c985aab2b2865219586aac0ea08f42308301815db6ee97b64ec186ef76fb925aaf5c7ddc67a249dc9e0b1b04211e53c01e9e04f2cd5579ddb65f6ab23744bfcbfad2708a47bf5655e2ae87e21f0ebeb994c63e0bc4e5cf5da261af657ed9e7aecca94ad332bc623761237b6a1ba8cf24acda9e91fdc32d1aa1d0ed57ef4b6acd3b71223d648c968dfac29707f74ec40f8d42827f4e40b3c80c0d372dad68c3685e473d31443e6663c80c4ca621b6b6cd7569d8945810eef65084b2c82558491f0809aaf505f1e3c72d5ae35eeaccbe7ddcf437aadbfedd7b7dd853745b2c9b6ee76a8c7eec33d7727db9cc67f7d5a789c9d3a4b0e93c64e032e8757b66c3b6f69476f6dd8649e49b7298d930d894cab5f54542ca587501a20e04924f1ca5ad8e9d568858d4aa95a2e85259d8f54921f99d8f3272b1184b76106030180c06030180c06030180c06030180c060301819c080e5b7199abc44ad48ce96251f511f429ff1ce4fd439b158f0af56d4ae355ac6891a2a200a8a34551c80ce04ce571dd234677215146acc7901888c881537d31cdeed884a5094f4c53e9c57d5c79367d1fd3763f6eb998ebdd96e43a15656019482a788239119d762c3a248851d43230d194f1046073f6a94fb5319200d2edc4eaf10e2d0ebe2be6b994c63e0bc4e5ba2963963592360c8c35561c8e07ac20c06030180c06030180c0ca82c401c49e0302eab40b0c41473e6c7cce06dc06030321598e80127c860659197e6047e91a6079c0a0ee2deaad3dab73dd2d066d9f66af2dabbedf1697d842e635fff002e71b9dca9b5a36a93acce1bd6be31997cf3bbf71db774da63da7bfb718673b82456f6ed8fb6eb4b2ee34cab070c278ccdaa74702e638f5e3a678b66b359f2db8e9ded3a4fdbef5667d5d3f636efdd068415770fb6ddfb63d8f7a87764727b4f3572a3d9592a95ea1378371d3c79f0cf3efedd3398cc5ffdbfdfd16ae56314134b68dab4bd25785688fd0bf88fe639dce0712291e53d55bdbb42567499180c06030180c0603030e88e851d43230d194f1046047af62c6d2df0869b6d3ce31c5e2ff97cd7d31138f827195fc1621b112cd0b892371aab0e59a44e546cc914b7f6792191ae6da0073c67aa78249ea3c9b33b53bc2d13eae3eded51177968a597f7cc8f6e18ca065b2a07b0ac8da691716d40e079e572b3a4da289a5496224f5b9f7244d75547651d4a9e4ba8e59655332030283bca87766f9bb6cabb27daaecb0755bb17acb75aa4ebc216100d0c8d17cea09035e6466b12ab96ecfdcc51dfb7abb4ac5cee6ddafc8b46ad53206d63aa4a4b6a72748abc666eb11ebf34617a7ab03bddd7612b5d9e388495e4d1ad52427457e65e13c0820e6735c6b0bc4e59db23a295145200424924fd458fcc5f5e3d5e7ae4672612b086ab3662ad099643a28e407327c00f5c4ce12dfb46db2193f985d5ff0052c3f7311e22243e03f31f1c9ad7bca265719a2aafddb7414e358e21ee5c9b84117fd47c94656d6c26215b52afb219e46f76cca7aa698f327c87a0f0ca442d329184180c06030180c06030180c06030180c06030180c0603021d8925b53352acdd3a7fb9987d20fd23f31ce773f991b71e31fa9ad2bde5615e08abc2b144bd28a380cf9cb5a66732d1b0900124e8073395153213b9cda1d46df11e5ff7587fd233b7f4fe167e6b2b7b63e29ac88c85194142342a7969e59db608d058b1b437c3d536da4ead1f378bd57cd7d31138f8271974104f14f12cb0b878dc6aac38823358951ec80468796051dedaa6a6ed6f6e5ea89be29e98e47f347ebe999cd71ac2d12c56b30d98849136abc88f107c88c8894b66106030180c06030180c099b6c5d53173c9070fd2702d30180c089bbeeb4768daadee97e41152a5134f6243e0a835c0fcf7dcfdebbef70564dd7b9375bbdbbb05c9047b4ecbb60905865705a36b0f12c8ed23a8d7a40f879679afbf39c53b3bbc7fa5d2bb717df998f2e911fd91fb6774dd2934b6fb1fb9afdab95347b1b36f2d23c53a9fa1d2648a48fab43d2e386b95ff00d16acfcf1a36b7d276772b3fb369f28ed39fe6fb5f68f7945dedb157b5b746f51e4d63dd217f9eaca87a64849fc5e47cb3cff51e67edc78c75970e9b789d7b366dbdeddb56fba6f7f4fe7acd5b72af13b7d9d809edd9a8401eea1d4870fd47e1f9b99234ce05f62f148ddce63f9a7cb3384297b2374edeb1edf6051d9b67a16636fe6172c099ad2393c1e3015d5d557e86751978e445e3fec9b4cf6478fa2cfb6360a54768a1b5d4eb6da36c411c064f9e7917e695ff0049e39d6e0f1a6f69ddbf592d6f18c42cb748b8aca3c7e16fd59d960afc06030180c06030180c060302284b34256b1438a31d67a8782b7aa7e16c8e9d13d5774370ad7a1f7603c8e8e87832b7930cd62d95663093928566e5b38b0ff73598417547093e971f85c788ca5ab9e898940af6d9e46af613d9b69f3c47c7f329f1194895b0919283021f44db7bbcd557ddab26bf734fcc11a164f5f4c8e9d13d53bb5b69edbdb36b483b7ea435290d4fb50af4e8c789eaf1d7f4e6b139566171928545dd99c58fbbdbc88e57204f11f91c6bc5bd18652d5ef0b44fab84ff00fd89bbdbb5786d3b245629d197d979e7b06262da91cb4d353d2780f0ceafff00aea5623ced399f4872ff00f75ed33e35d23dd37b7bbb27bfddd06d1bced4b52e188cd50c5319a3d3a4b863af0e2aa742333dee0d229fb959cc47ab5d9e65a6fe168c4be8b9e17b50f73dca2a15fad875cae7a61847ccede432b6b6131195455ad2891ed5a6ebb937ce7c107822fa0cce23bac9392830180c06030180c06030180c06030180c06030180c06044b762669054a9c6c3fccfe11afe23ebe59e3e672e36abff2694ae7594ca7521a9008a3e5cd98f3663cc9cf98bde6d3996adf94147bbee31c8acbab7d8c6ea933460b3cb231d1628c0e27539d6fa7f066f3e56e8adade3f14bdbee54b309fb7050427db78594a3a11e0ca788e1c4798cfa088c3149c20c088a2cedd299e90ebaec759e9ff008b47e47d32234e89eabda576bddaeb3c0dd48798f107c88f039ac4e559848c9429f72d9e4f74dddbf44b3fe6c47824a0781f23eb94b57bc2d128d56e476032805268f84b0b70653eb94894e1bf2506030180c060301816bb62695cb78b31ff008604bc060303e75fff00d070cd2ff49f76f694b08a4af2cda78449282e4fa616af58f8be61fd403339edc6a33c704adba446bd8914346bac52684af88d3397b1fe59f47dbfd43331b7e33fe71fc251bb7df708bbf278b72b35f71b7668068acd45f6d618e1938c7220e1ab993556f43937c4d34d35578f368e44c5e62d335eb1db13dff1767fd24bbbaff2efea63f6f18e6dc63bc5b6d88e9d1eff00db680f1e07e21cbc48ce7f3e2be5b7e5d31afe2f99e74e77ef8f5fe48f18ddf76b5b56c1bfd494c976d93059b96c1ee3ab37b4d27ddc290ea9057899080acdf29e589f1ac4dab3d23b47c93edef2f1bea5b4edd692947b4c9b958dce2ae4b5ddcac906499c9d7a174e014790cb70b89fbb7f398c55799f18f75faaaa28550155468a072033e82230c1a6f275557f4e23fb3250a6c06030180c06030180c060301811a6ab22cc2dd36f6adaf027e971f85c7ebc8c778497fb9edc75aa8af5916ed8b2b55e3b0c51118a96eaea00ea3870cbc5b28c3ceddddcd34cd5ed44ab6209268a64afd73f5989637d61e804b70986a0f1c9f2461af72dff00b72f5096d49f728951dd64b495a7ea81e300b75fc1f0e80f1d722d894c661eeaee54cbc3565b3d7625d16393da91236665ea546723a5642bf4ebae4440902d29dccedc23f88565b3ef6be26409d3a7f6e48d995115e1b15a7372868243fc6ae7824a3f537ae474d612b9dbf72af7a1eb8890ea749226e0c8de208cd6b6cab3184bc943e09b058ed48ff9ed1ee767487eff00ee9625f75646e832c7f07b7a12daca3e13f4ea7c33e8b7a3727c676ffdb8fe1fd1c0da9dbf9a373d73fc571db536d963faa9b6aed0c26a1468fdaac89d6c83db8641c19fe261f10e2730df8b471ede5d6673f9b6d99acf223c7a4463f27d6afdeaf4ab34f31d1470551cd89e407a9ce1cce1da88ca9208e79e737ae7f1d869145cc449e43d7cf32ebacac9592830180c06030180c06030180c06030180c06030180c06046b96da32b0c03aedcbc234f2fccde833cfc9e4c6d573dd7a532d95e1836da8f2ccfab7cf6266e6c7ff00c7219f33337dfdcc46b696b33853edb4ef5cdd137297afeccb33429236ac0687a787e9ced72f7f6b6b6276631fb988ccc469eecab13339ec9fba5feaf76bc4fd10c2a5eed81c7a100d4a8fcd9cee0f0e772733d1acdb1ab9fdd2587a24eab6b0ed8f1a3edb27ff005a4d17e34771c5652dc55b9f967d2d2b158c43cf3399d575b351995ff98d89e4966b104718495151d5012e03f4f371d5a13922d3203018116482c579cdca042cc7f8b09f9251ebebeb91d3584ae36ddcebde8894d5254e12c2dc190fa8cd2b6cab3184ccb215bba6d0b688b103086ec7fc3980e7f95fcc656d5ca6255f5edb348d5ac27b36d3e68cf261f894f88ccf2b61232506030180c060302e36ff00f689fdbfe270246030181a6f52a97e94f46e44b3d4b51b453c2e3556471a10703f3dee9d9f176defb1765eff000a6efb05b0f63b62cd951205487835593ab9c9106f84fe1cf1f22935f9eba7abe93e93caaeec7eceec7963f4e7f8206f3152da6cd5edaed6af5f6add77b2dd56e28d516bc1169ee4cc0733a1d13d73cd169989bdb58abd9f51dfa7169e3b5115bdfd162366d87b66b412f65599286ff4cb1fe62ff10b81f42f15d5ff00311997504f153cb3cbe76dc9ff00b23359ede9f07ca4faf75cd7eff67b7f73f61055deedc6abb9dc8402e00fa449cdbd32db3c1f39c67e484f96357d5bb5ef476b6d8da24e840380fd79dbad22b188653395ce590d767fdbcbff0029ff000c0a3c06030180c06030180c06030180c08db8ed54b724ad1db0ad1569c58313af5ac9a2950a47e93ae4880f45a56ad5abcb1ed17ebc53c554c51fee9bdf29aba7806d10f0c8894b73f69eea68d1a296605a74dfdc6add0dd133af14690f33a36ac7cce5f08cbd4dda2f26f516e766e23cb1ce9653a914baf48e931239e2b1f1d71e265baeec3ba43792fd1ba14a57fb791648bde6601fac10078e4630652b2a1811ac569165fbba8e21b683e63f2ba8fa5f231de12b6da7711b85313f418cea5581e5d439f49f119a56d9856630d567b6fb7ad4ed62ced95679df8bcb2431bb1fd2c4139bd77af1188b4e3e2cadb3499ccc47e0db4365d9f6f767a146bd4771a3b41124648f22540cadf76d6eb3329aedd6bd22214cf2c96b77905d06392b9ff4b58fcbd3ff00701fa89cf34ce6756dd9332506030180c06030180c06030180c06030180c06030180c0d172d8ae83a57dc9e43d30c439b37ec1996fef576eb995ab5cbdedf44c01a598f5db978cafe5f957d067cb7237e772d996ef57b6e8ae3c26666f6e16eb317d2e7c3abf465b8fcbb6cc5bc7ada319ef1f0566b969bf724f7052a9fee186aee39469e67d7cb2dc4e2ceedbd939888ccb31d1acb55aab20922705650c35ebeaf9babcf5cfa7dba452b8861339978adb74356d4b3d726349c6b2575d04664d78c807831f1d39f3e7974256030180c06047b155ccab66b3fb36d3e571c987e171e2322612b1daf774b64c132fb3763fe2427c7f3279ae695b6559858e590817e8d3dc6203ac09a3e314c8475237ff008e632b6ae5312aa8e7b104e2a5f5093ff9728e09281e23c8fa6679c692b25e4a18c06030180c0b6db5b5ada7e1247ebc09580c0606ab3662ad0b4d21f857901cc9f00329b9b9148ccad1199c3e63fd5cab4aef6e599decc5ff0094eccd06ef428970258e25728401a83a3a16ead3cb387b7cbb6e6ee7fc2747ab6aff00b77acc75897c437f8377de377dcfb8f6f816c2d7963abb54f13849e2fb7884a7e13a8757364a919ef8b56b1149fbfedf737faaef4ee6fccf68c447dbef759b252df778ad54454648f70b280bd761fc26e4c5bd3c730aede6d88d5e08f57d13b6ff00a492c2124dc2400ebd4ea38927d73ad4ac56310a4ce5f4aa142bd1aeb040ba228d064a123034dd6e9ab21f31a7f7f0c0a5c06030180c06030180c06030180c0606bb15a1b1118e55ea53c41f107c083e071319494f759e83ad7dc18c95c9d21b9e5e4b27edc56d8d2498cab37d4d865eee886f3ed1ac283b45ef7cbd5eea715f5d32d38ca23a2aa3ee9dcf6cd96e7efcac70edd62ced2d3a9677e97e98092c0962469c0e479270eb3210ce04358e4dd2c3568495a719d2d4e3ea3ff6d7f59c8c653d1d1451470c6b144a12341a2a8e000cd947bc06043dcb6c82f4415f549538c532f0646f3195b572989c29e39e7af38a77c059ff00ca947c928f31e47d333e9a4ac97928630180c06030180c06030180c06030180c06030181a6dda8ab4265938f8228e6cc790194dcdc8a4665688ccb9bb7dccd47773522db2e6f1ba958cdb4a6a852945313d3d6eeca3af4f8ba471d38e7037a6dbdf34cc56bdb3ddae6234851ed3dd3bcf696e5717baf713b9f6c5895d36cde6231ccb54ab33fb36c429d61dc368adc47c2069af135bec46ec478462fde3d7e0ae71d5df58dd51a080d2fdecd6d03d71a11f030d43b03c40d3cf3cdb1c6b5ede2d3e2cd4a8b5e3235eb95cf54b21e6cd9f51b3b31b75c430b5b2df9aaa6030180c06030181a2d5449c2b0631cf1f18a65e0ca7f6626131295b76f4cd28a77c08adfd120f9251e6be47d32d5b76944c2aad6c37b6fdd66ddea289a10fee35652559811f11e1a03a1d4e873d117cc78ca8b9827daf7edbc95f8e3274653c248dc7fc41199df6fb4a6255a4d9dba515ee9eb818e905bf03f95fc8e613a755faa5e4a0c060301813b6c97a6468cf261a8fd2302cb0181891d234691c85451ab31e40644cc44665310874a07bd3ade9d7a608ffda447c7ff0091bd7cb3e63ea1cd9dc9f18e8f456be2adefeec6d83b9f64b89776d8ed6e295e5146ca8e8b092741e811cca5645d5b4d475687c73c7c6dfb6dda31388ca2d197c5ff00a45fd1eee5dab6e8eff763b565990247b0b28f79e746203b32923429a7ae9cf9676395ca8dcbf8edc667d55ad667597ddb65d9ab6db07c11aacf201ee151a69f947a0ce9f1b8f1b75f752f6cfc1639e950c06040dd25f85621ccfc4702bb0180c06030180c06030180c06030180c0c491a488d1b8ea471a329f1070356d7f6fef8dbafc6933c635a534aa18b463e9d4f8ae4d67b493ea87fd42ee6ff00c776fad7cd68ec57f74c5659e3f73a15d485d002ba75368b9a566267c7baab2cc964590cf76c1a151ba74ff75607245fc23f31c8eba27a2faad582ac09040bd31a0d00fd673588c2932da480092740389272473b72d4dbaca56091a1a1113d32a1d0c920f11f957fe3994ce5788c25ed9baca2514b70d167ff00266e4b28fd4de996adbb4a2617197551ef51ad76030cebd4a78ab0e0ca7cd4f81c898ca6270a266b1b7ccb5ae9ea858e95edf81f257f26cca74eab754cc943180c06030180c06030180c06030180c060303c4f3c7044d2ca7a51799c8b5a2b1994c46552fbb6db5371a0dbcceb56c6e4ed16d50c9a84ea51d5a16d3a43b0e5a9e3e19f3bcbdfbef67c7f4d5be223451f78764219b75de23dcf758685ff006e6de368dafdbf72cb44890828cc3ad358e350c1586a0667c7e4e315c5731d267b2b3085d9fb3edd4775bfba6d1b33ed1b1cf5a1a95284faab5c9e366633b424bf4850c07537c4dc75f0cd2fe5b98a4cf95f3f8158fc1dcd3a8d175cb31ebb52f195ff00c157c80cedf1b8f1b55c47552d6ca4e7a1430180c06030180c0603035d9ad0d988c72aeabcc1e441f30713096686eb2d475a9b8b6b19f860b6791fcafe47d726b6c6928985ac1429c13cb620895259f4f759787569ae9e9e39ae556c9e086789a29903c6e34653c88cacc6473f3c163697d1faa6db49f865e6d16be0de6beb99cc78fc178d525595943290cac3504722308670180c0f48ec8e197983a8c0bb86559630ebe3cc791c0f7810110ee963ff00f1d09e7ff75c7fd233e7fea7cecfc957a295f1f8ae0000683801c8670d66ab56a1ab5de794e8883fb49f003d4e4d6b369c40aea70cd34c6f5b1a4cc3f7317fdb43e1fa4f8e7d5703871b55ccfea65b97ed09b9d164603030eea8a598e8071381493ca65959cf8f21e981af0180c06030180c06030180c06030180d4606702059d6e5b8ebc1c1abb09249c7d1a7829f339cde7733f6e315fd4d695ef285fd43dab71ddfb5e6a5462362d3cf59c47a81aac73a3b1f8881c00d73cbf49e4677e6d79d6611b91a2c6c4b3cb32d1a7c6cc9c5dfc234fc47f5676e7d2145dedf420a359608472e2ee79b31e6c73588c2b33949c9439fdcaebee33352acc4538ce96a653f31ff00b6bfaf32b4e745e230da88888a8802a28d1547200610f166b4362231ca355e608e041f307c0e2612cedfba4d5245a7b837546df0d7b6793792bf91f5c9adb1a4a2617b9a2ad562bc1661686741244e34653913191cfcd0d8da5c2ca4cbb713a4739e2d1ebc95fd3d73398f1f82f9ca58208041d41e208c20c06030180c06030180c06030180c06061dd514b310aaa3524f20313384a0c2ab71fefad68946005a0573d20e9ce47d7869e59f3dcfe64de7c6bd1bc57c5f3cef4ee7eceee99a9453df7b9da11b491eeed50306af6081f6f34e0a7bab17e095069af1d74caec6d5f6e274c5fb7f6fe8a4cc4aebfa75bd6f5152dcabddb3fcd761a1308762df1fa967b51900fb6ea5407f689e8f707cda667c9dbadad1e31e369eb1e9f6f45a8eb69d798c86e5ae3664f957c2343f48fd79dbe1f1636abff252f6ce90979ec666030180c06030180c06030181e658a396368e550f1b7065384b4d4bd3ed4c22b04cbb713a24a78b45af8379afae22d8f818cba0474740e8432b0d558710466aa32caaca55802a7810788381cfdbdbe7db19a6a8a65a24eb2571c5a3f54f4f4cca6b8e8bc4e5b219a29a2596260f1b72618891ef083018122a5a303f1e28df30fd78122591b719beceb3e902e9f7732f91fa01f339c8fa9737c23c6bd5b6dd7bcade28a38a358a350b1a0d154720067cd4ce5a32ee888cee42a28d598f20062205445d5b8d816e51a5588ffa48cfd47fee30ff000cfa3fa6f07c63cedd54dcb63484fcecb0301802401a93a01cce0555db9ee9e84fe18ff89c08980c06030180c06030180c06030180c0e33bcf7adfe3ee5da762daef7f2e4b90b4d35955566e064d75ea078058b3adc2d9dbfdab5ed1e5873799bb7fdcad2b38cb959fbc7b8e2daa4dde8773c9b8c75278a39abc90a229130764d7e1e47da3ae7be38bb736f1b522b9878a79178af956f9c4bea135b9665821afa2dab31a48c4728c3a0666ff008f0cf90fa8726367311d5f45b15f288b4a7d3a915580451fe9663cd9bc49cf96bde6d3996cdd941b76bdb23a3091d4649e43d534cdf3337eccfb9ad70f2cce5372c873fbf6f512f5d54b095a14d05db8ec156353f4863c3a8e676b67485a23ba86b6f3356f71c342f4219151aaa001d229182c7323ebfbd0cc78ff00c3962212e97210c60799628a68cc72a8746e6a703554dc27dad961b24cbb79e11ce78b45e8ff0097d7116c75e8998cba0565650ca4152350471041cd5461d11d0a380c8c34653c41181cfdaa33ed4c648034db71e2f173687d57cd7329ae3e0bc4e5ba391258d648d83230d5587223087ac06030180c06030180c060301802401a9e0073381517ad196a5abad1bcbb7518de530c7c5ec3460b74a8f2e1c3cf38bcee6794f8565bd6be319eee16d5beebee28a8ec3bbee3155dbfbcea4b2edd2edcad1cd49e14f78c4c5b84d1b2706d7a75e59e6ad694cdab199a4eb9eeaeb2b2daf6793729e2bfbf543b377076fb2c12ee9442fd9ee35b99450383c520e71b0d51b296be34afcd5b769eb13f6ee988cbb1a95da6916ccc8238d07fa5ac000a8a7c481c3539d5e0f0fc23cadfa917b7684fce8b2630180c06030180c06030180c0603004020823507810791c08b0cb636a72d0832edec75920e6d1ebcd93d3d32227c7e09eabfad661b30acd0b878dc6aac33589ca8db92292fed335691ee6dcbaf5719ea7257f55f26cced5ef0b44fab5d6b51598fae32781d194f06561cc30f3c889ca5b70830225bb12b48b4eaff00b893e67f08d3c58feacf1733971b55ff00934a573acf459ed9a6dd108a0e29cdc1e2589e649f3cf97dc99bce65ae57505d8251cfa5bf09cc66b302ba773ba58f694fff00c7c27f78c394ae3e91f946767e9bc1f29f3b7445ede3f14f0000001a01c0019f44c0c20c0d535a8621f137c5f8473c0adb37649b87ca9f87f6e046c06030180c06030180c06030180c06030386ef8a7bd41dd9b26fd476f9770829c5edc91c0accfd5d52757050c47c32ea0e9a6b9d9e0de93b36a4ce265cbe652d1bb5bc4662151dd777b93b8f6b4daa0edabb4cbcea44b246e13a230cb1331e8501dbdc3ee13c06834cf4f1ebb7b56f29bc4e9febfd9e6dfb5f72be31498d7edfddf50a54d2b44baa813948d666e7ab2205d35f2e19f9afd47763737ef3139ae747d1ed44c52227b4246785756deb125899a8572574d0d9987d2a7e91f98e74385c49dcb67b273158ccba4cfab78d53bbee722c8285220db907ef1fc2243f51f5f2194b5bb42d10e4afc76c2c41ba2a564b8056924526412a23309e4eae0eada3823cb4f1c8888253368da239a57bd6abd730ca6396a431fc68afc4bcc84f2126aba0f0d302fb20630180655652ac0153c083c8e045827b1b436a81a6db49f8a21c5a2d7c57cd7d31138f8271974104f0cf12cd0b878dc6aac38839ac4a8f6402343cb028aeed73d277b5b7af5c2c7aa7a63ff547e47d3339ae3585a24af621b1109626ea53fde0f91c8894b66106030180c06030180c0603029b77ddf6e8abcb35eb91d1d9eb955b97a5711a6acc142751d07127427395cde5ce7c29acb6ad71acab97b8ae6d9dd75a0b334567b577d8d23d9adc414257b283f80ecbc184e38a37e2e1e39c99db8b52663f5d7afdbd8cea7f507b4f78dea4d9ac6d3b8a6d2db6cb3fdd5ae9d645ad6606865f67868240adf09f038e36f56b9898ce5335ca76c1b250a942ad3a509afb45150946b92496d3fcd909e24b73e39d7e1f1a667f72fd6516b62310bccea3130180c06030180c06030180c06030181eba416650ebd4801917a86aa18120b0f007a4e4e0cb0002a19487461aaba9ea523cc118c089eddaa13359a2bd48e759ea1e4fea9e4d91ac744f55cd5dce9d848595c23ce4ac713fc2e5946aca01f1033489cab30deb342d2b44aea65400ba03c403cb5192856ee5b3b3ca6e51222b83e707e4900f061e7eb94b57bc2d128956dacfd48ca62b11f09616f994fecca44a58b96cc215235ebb329e9863f33e67d0663c8e446d5732b56b96fa1496b23163d73ca7aa694f327f60cf95dede9dcb665b24e642b6ed892ccc68d76e951feea61f48fc03d4e74783c49dcb667a22671194dad2c95a358a162b1a0d15798ff8e7d256b1118861339481b9d91cfa4fe91fb3250c9dcec1f051fa01fdb81a64b765f8339d3c870ff0c0d5818c06030180c06030180c06030180c06030181a6d5b5ad1f56859d8f4c71af3663c8665bdbd1b75ccad5ae65ee854963eab161baedca3e33a9d147e15fd19f2fc8e4db72d996fec979e610770b72750a954ff00a971ab3f846a7ea3fab3d7c5e34ee5bd931888ccb35ab455e211c7fa598f363e24e7d46d6dc52b8879ed6999ca6eefba3560b5eb0125e9bf869e0a3c5dbd066b6b6148840a9545743ab192690f54d2b73663e395885a65e770db696e11c51dc8fdd8e195674427875a6a1751e23e2e592849c80c06030180c0889f73b6cad3d35f72bb1d67a9fe2c9e471d3a27aafa95daf72059e06ea46fef07c88f3cd2272acc37120024f003893928730f3ed77adbd8d86ec135c0359eaa382b200789f46f5cca63bc2f1ee9356c0b09d41191c7078d868ca7c8e23512442e7870d74d7a75e201e1a91e5c32708cb4b4d51442cd6610b65bdbaec5c69238fa53ccf0c606c0a09708eaed13744aa87528da06e96d391d0838c02a31e438799e03fbf18028c3d473d4711c7d7180e87fc27fbb1818c818c0ce0429e596d4e69563a01fee271f403f48fcc739bcee6c523c63ab5a57bcb94ef0b93d5a77b65df36795bb52cc7d30ef343599eb10032cb3c5c5d5a39007590700467276622d316acfcfe93dd369f5739dbdda9db9de9daf720a37ced7b9579041b9cdb630152696321e3b6203fbb25fa432c9a7503c8e6fb9bd6dabc4cc663b67afc1588cbe8f5e396e450c324cd3d3acaa8d3300ad61d0685885d069ae6dc1e1667ced1a2f6b634eeb3e59db606030180c06030180c06030180c0603018149736bde2c6f3bc4b537096844d56050a90c3289484975e32ab1e1e9e796c1956259ee0aff00cae1ae2c45f6ff0060ac8449d0f1cb602582153443d287e23203a70d32354a40b1dc5568c36fdcbb625b35ed1b110258a9463ed1456e0840f2e27275468841b7296ed06dc25b5f6956f4dd1661f7bad6192993c247264e92c7e6d7f46425d2f694fbe4b6e53ba09037db4047b8bd249d38961e0e7ea1e796aab281fd4fd9fbe772af417b52cbd6963694da2960d7d432809a91f371d722f13d93598eebc1b2cd2ed549ac4863ddabc11ac9675ea2640803873f502d91688c664896ba14a58d9acda21edbf0247caaa3c173e4f97c99dcb7b3d31d309b9e410770b922b0a9578da9073f08d7f11fd59eae2f1a776d8ec671acb356ac75a111a71f1763cd9bc49cfa9dadb8a462185ad996dcbaa6030180c06030180c06030180c06030180c06030181aec588abc2d2ca7451fde4f80195bde2b1994c4665ae85491e5fbdb4ba4cc3f7517311affee3e39f31cce5ceedbd9bc46230b0cf1251370ba605114203db978449fe2c7d066fb1b33b96c42623bcf4574db2493b40af664117533dbf6dda3791ca90bf1a91c175e033ea78fb31b55c430bdbca5e3b5f74b1b86d7149346faa22a9b2fc3dd71f3f4af3d14f0d7c737985213ea5678cbcd3b7bb6e6e32c9ff004afa0cac425232506030180c060301819c088f0d8ad39b9434129fe3407824a3f53791c8e9ac256b5b728370a529875122ab2c90b70756d39119a45b2acc61f3dd8e1ddc0dabed04d66ed282c05866ae90a5791a17543eea852dab10ba36bae561694c88f709dba466bb3940d09990c5657a5f51ee2b4beefb8a3cfa080be5a63513fb6a3b677d6bd721b31589b6f88033bb32b7b7232b6ba689a95d1b978f9e4c2255cdb25fb77370a4d03a45b27bd636c9c8f85e4b737dc7c1e65557a4796b9184e5e037714942bde5126dc9ba3dbb96408e5674b07a23aeacb13c6c4f447f0a93d2791c6a37df8fb865b76ab486cdcfb9864468d0490054354e84a7518fa0ca34f8406ea3a124627288288df52e508a09e6af4e38e9ad34649e62e35d2cab7ef02fa31707a4715c25be950de668287dc58bc1a782c4b6f49a452255d444381f874f21cfc72708cade9de26b6d70de62bb95cac246465d3578e30d27578038c09bd0de591810add895a514aaff00b971f1bf846be24faf9678799cb8daae23f534a533aca6d4a915580451f21c598f36279939f337bcda732d5bb2839f8b6ddadadda1b65486a4365c3ee76208d636b122eba062a0757a939d7e1716db989bcfcb0ada7c7e2b74454508a34551a003c0677e231a31670830180c06030180c06030180c06030180c0f5ee3e80751d0721af2c919f7a6fc6dfde7190f7a6fc6dfde71919f7e6ff00b8dfde71911eda59942bc53bc53447aa36ea2575f265e441c89ca52f6cde058635acafb17507c51f830fc487c465ab6ca2612279fabe15f97c4f9e703ea7cef2ff00ae9fa7bb4a53bb46719aa2ee1745584151d73487a214f363e67cb36d9d99bce2069a550c0acf237b96253acd2799f21e833ea78fb11b55c431bdb2919ba86030180c06030180c06030180c06030180c06030181e6491228da490f4a28d589c899888cca6211a9c0f7265b9614ac29c6ac27ff5b0f33e19f39cee64ee4e23a3788c2cf39a968bb723ab0f5b7c4ec7a638c73663c8669b7b7379c408b4eabab358b07aadcbf39f051e08be833ea38bc68daafbb2bdf3f049cf53330180c06030180c06030180c060469eac9ef0b751bdab8bc3abe971f85c788c8c7784acf6bdda3b80c4ebecdc8ff8b03731ea3cc6695b65598c3c771ee5636cd96d5eaeaaf3429d51ac9af493ae9c7420e4cc90a5dc771bb048d577d9a3ae042d66bdda9d6abfbb3f1a3c4ccdd5cc78e56dee986e8fb8b6d0bd162c4d04d0acad3472a146430223b823a9b462b2a91a1e3ae07993ba36c49e38a27b362c4f1a4b1a431f531122b385e2c3e20aba91e1830d707775096c5a84473ad6821ad3416871f79ecbba2c6a9afcc59341fdbcb4c64c371ee7d9d6096596dcb10863324e8ea432f4bac6c846a7e25775047ae32618b7dcfb6d7b5356f72ccf2c0ad24a614ea50b1fce75ea1f278e0c2a7bc764de3789b6d7dade2787a27f7e79cc82331cd100bfc278e4d4f8687f4e5ab311d50e42e76377f457eccf0efcaf2dcd59f6d89e628c85c1644123b85e1c89e389e452b8ace9f7a7c66757d52a548ebab7483d72317919b8b127ccfa67c6726f36dcb67d65e88e8df98255b76cc96656a555b403fdccc3e91f857f31ce870b873b9399e8899c4652218a386258a31d28834033e96b58ac62184ce5eb2506030180c06030180c06030180c06030180c06030180c0f32cb1c51b492305451ab31c8b5a22332988ca2d4af25cb097ac0291c7a9ab1723ff003b7e9f2cf9de6f366f38af46f15c2d339897a44676e95e79aececdb72de35ea899c374fb756b158d79d7a95bc79107cc1f0cfaed8e3576e9e30f3cda73952b1b3b74ab5ee1ebaec7482df87a2bf91f5cb74ea9ea9592830180c06030180c06030180c06030180c060301802400493a01c49c083121dca612370a111f814ff9ac3c4fe519c1fa8737cbe5af46f5ae3e2b6ce3acd56acc55a069a53a2af87893e0065ab59b4e2040ad0cd2cdf7b6869291a451ff00db5fda7c73e9785c48db8ccfea677b7684ccf7b230180c06030180c06030180c06030181a2d5413159118c5663e314cbcc1f23e63d31309627906f5b758d92f39a97254e9f7178861f8e3d7fc3262d9d27aa318d493b412dacedb9dd96e4f2c5ecc72e8b1fb4baf56a8003f113cc9cb78a32c4fd974ed464dcb124f624b31dab136817afdb55511e8392108ba8c7899458367da769dd10169d247b33db491c0e877b0a14a06d78050380cae9129d65e23ed6dbe2d7a2d4ca4470aa10abaac95a579239071ffe66561e23cb1a196c1db1b4335769da499e29e5b361980fdfbcc0160e0725eb55603f2e343250edbdb2940228e699bfd3cf5de4600b39b0fd6f231d79eb9318126c4d1d2ad0410832c8a8b0d743f33748d353faf3cfc8df8dbae656ad72dd42918034929ebb52f195fc07e55f419f2dc8df9dcb665ba5e60205fb92193ecea9ff0050c3f78fe11a9f13ebe59ece2716776dec899c6b2f75ab455e11146380e249e2493cc9cfa7dbdb8a46218da732d99754c06030180c06030180c06030180c06030180c060301818775442ee42aa8d493c862671aca50ebc2fb84ab6265e9a68758223f59fc6dfab3e7b9fcdf39f1af46f5af8fc56b9ca4b4dcb952957362dccb0c40850cda9258f255550589f4033d7c6e1df7b335e91eaacdb0d7b3eeed61c6816c54989f62d57ea651d3cd240406561ea33e8783c6fd9ae27acf76579caf33decdae78219e268a640f1b8d194f1071302865ab6b6c93a7469f6f3f238059e2f46d39afae65318f82f9ca4af43caf0a3879e20ad2c235ea50fc5491a78e4e10d572d55a50358b9288215608598313d4dc800a09d78630314eed0ba81aa5959757f6fa42b860e07568ca5415e1f8b18127d89bfedb7f71c6060c3301a946d073e07181e32030180c06030180c06030180c06041607719cc0848a519d27907d6c3e853e5e79c7fa87371f255b52b8d56a88a8811074aa8d140e40670a6576259638a3692460a8835663e0311191570abde9d6dce08853fdac27ff5b0f339f41f4fe1f8c795baa97b7684fceab1630180c06030180c06030180c06030180c06069b5522b31857d4329d639178329f30713096edbb7796395696e24094f082cf2490791f26c9adbb4a261759a2ad36ea57b703413a078dbfbc1f307c0e44c648950482ced92886db192ab1d20b67c3c964f2fd399ce63aafd52f0869b76a3ad17b8fc49e08839b3780199eeeec52b995ab5cc9b7d3915dad5ae36a4f0e6235f0519f2fcae4ceedb3d9bf4d213b3ca216e179e12b5eb8eab72fc83c1478b37a0cf4f1b8f3b96c41ef2c54a895e3201ea91cf54b21e6cde79f51b3b31b75c430b5b2dd9aaa6030180c06030180c06030180c06030180c06030180c0c332aa9662028e249e40626709428a33b9c824704508cfc0a787ba4789fcb9c1e7f3bcbe5af46d5ae3e299bacd6abed76a6a681ecc313341191a82ca35034e19e3e0d2b7de88b6b125a7470c7fa95b83edbdbd6e2ac9d3bf5d9204675e92b04206a4202752cc4f8e7d15be97b3899f1e90c7ce5d3ee8966d528e692a4d298ad0923fb5754b302052ab2a2b82ac7890c3c8e67f4fd89dbdbc4f5cad798caa6d54ee19f6df68d4944734f61d2508ab29fdd2889e6863751d6cda80dd434d388cf6eaabd36d1bfceaf34e2cfdc2a6d088c1ca9e3314bbc01d35f698f564e250dadb26ed2ac95644b02ac126e22aa8761a20e3578eba9d0fcbae3065aad41bb6d342cee21a65fb386b5d6591f84b3201f708753a6b20e07d71d1297b86c97d760a1232cad7e43ef6e3d0a64ea9241d655c0647e9576d148f97cb131a23291b953dd6f6c7b5c68a61dc127aad39e13988a060ccff286d3c7034dbda2d559e3bdd536e734b393b87b4823eb8e38245445453c3e26e7ae055aedf22ec924628da376fcea65f86c7b54d0ab686304f5b145d470facf964612df6b6fde16fd0fe5d15b5ad51e80af2c80bbb57f780b3d45997dbf875ea0558b7a64a1d5cba7bafa72d4e991243c640c804900712780192321411d4194a0ead5c302a3a4e8da9d74e0781c60cb11f4caa8f13acb1c9c524460ca743a1d18123c3181e9632c8ae855d1be56460c0ebc3c0e3034c762a4b3b578acc32585d7aa04951a41a73f841d78630366800666211546accc42803d49c607a11b972807c4398c60cb0574d78ab749e96e921b43a6ba1d397038c0f3901810e7796d4e695762a07fb9987d23f08f539cde7f33c23c63ab5a57bcac6082282258a250a88340067ce4cccce65a3d9214124e807124e054927739839e14223f02ff00dd61e27f28ced7d3f85fe7656f6c69dd3f3b6c18c06030180c06030180c06030180c06030180c060789ebc3622314abd487fbc1f318984bcd2dce6a0eb5af397acc7a60b67983f864fd47116c692898caf8104023883c8e6aabccd0c5346d14a81e371a32b71046073d66bd8da092034fb6fd247178b5f03e6b985be48cf65e35668d59659befad8d1f4d2087c114f8ffcc73e6799cb9ddb7b3788c461639e14a2dfbc2b46022fb9624f86188789f5f419b6ceccee5b1034d3a861ea9256f72ccbc6593f50f419f51c6e3c6d5711d58dad948cf4286030180c06030180c06030180c06030180c06030180c01200d4f00399c0828afb9cbf876f8db8f9ca47fd39c3e7f3b3f2d5bd6b8f8ac3eeaaa585a818098af52c63c14672ff66f34f3c7cb9c6539d70f568a8ad2f5304051875310a012081c4e5f8768aef5667b4a2d1987cfe9f676f7ff008b76cd192384dadaacc32c8a1d0f447d4e64657d7a5b50578039f5b58c5ad6ce968613d9d6f726ef26d5b44f7a100cfd416152bd6c75d4b148feb2aa35d3cb8e48dd06e12c9b21dcb589e75ad248eb1b074f71232ea0e8786a3a4919229366ee8bb6add68e7b0b6abc903cfb881524adf6b18899c49d6468c0b285d3c75d72225330ddb6f79ec959267af33bc5aa14a8f24447ef982abfbbd7d11824fcae41c44e0984d9bba567b9243636d77dba2a91dd0efd1d45cb68014278007ea3c3c7965bc9184bdbfbd36cbdd02256eb613f50051d54d6e2e3ad1995b5f02a4e22c8c2aea6f9b6cc6d6e54e0b495512179c7eec465ec411d851ab37c1f04c3a98fc23cf2b88eab3d47ddfb549024d5e1b13831cf34a2231911a56204a4bf574b69d5a8e9275f0c6861376ade24dc8deff4e6bc356544af2f583eea3c6b202403a83a364a133a9bf11fef3901903181904a90c398e232473d760b637397608637fb1ddec45704aa3e18e1e76a30de1fbc894e9f9ce4fb0814f74dfa034d8b4c535758e944acada1b73c7c10a88e4511f493f16aa06ba71c8cca70b1ecd4b5fceee4d6a498cd3d3a8cb1c8488cf4cd30728a401f07c3fa35f5c9844a05634a5dbfec6b40c77e17fae26589c3a113ab7b8d269a0455d75d4f1190978de374dded6d2941cccf63a6e2de4f6d871407da04e9a73e2313243d6f1b86f17291db9a4b3eee9ba0b6b1ab2b6916a6b8ea03cb8ae9cc626486eda85fad696d55b162582cee905778e4d591e092aaf53b6a38b6aa3e2c412b8ee48b799761dc62d91cc5babc445375758c87eb5e4cff0008f875e784429fb50777c1b22d0df66336f724f2b7baf2c7318eb90814968c91cf5d0678b99cafdaaffc9a56b1339eceaaa548aac0228f973663cd98f3273e62f79b4e65ab765055d891b7098d78c914e33a4f20fad87d03d3cf3adf4fe179cf95ba22d6f1f8a62aaaa8550154700072033e82230c0c20c06030180c06030180c06030180c06030180c0603031246922323a86461a329e446047ad727da4f44a5a6db09e0dc4bc3fa7cd7fc31138f826632e8639124457460c8c35561c410735511ac4e1b545f97ea3e79c1fa9f3a62676ebf7cff2fead76e9dda3384d9a2edc8eac3ee302cc7e18e31cd98f20334dbdb9bce2044a95a4f70dab3f15a9072f045fc2b9f4fc4e2c6d57dd95ed9d3b2567ad9980c06030180c06030180c06030180c06030180c0603018107e3dca531a6ab450e92c8381908fa57d3cf38dcfe77f8d5bd2b8d67ab5ef1bd8db192ac11296287a7c029e4b99fd3be99ffa2b37b4e2227f1f552fb9848db29454abbda9e512cd28f727b04f0d39f0f4cf2f37953bb68ac478d2ba457fafbad4ae3e2d63af72944d2a95a48758623f59fc6c3cbc867bf81c1c7cd62f6c6909d9d862d36e9c36961eb778a6aee64af3c4746562bd2dc0f0208f039234eddb2ed7b76d93ed9544df6965a569048e5d97de5e97e82796baeb881b1f6bdb64fb5ea47ff4913575208d6481d3a1e297f129e07f48c9c8d49b3d64aa6b0b76ca0e9116ae3e0543a85d393791eae631910a7ed7d9e2aa5615b2556308d1c6e3562b27ba1f89e61f8e9fd9959c2612e976ced1722166b5bb0256799a5903e926b6142ca87cb970f2f0cb4625133309117656d916dcd463925543257991c37157ab0475e33ebf04235193e28cb03b3e8c115828d34ef34562270ce3a985ae9f7342786bf0f0c60cb4ed1150816cad632a3c8631356988d63789047d43fe655194895a613b0830180c0f6b248a345620790c9c8cfbf37e338c9860cd291a172719032ca41058f1e78c8cfbf37e338c983df9bf19c64c1ef4df8ce3221dcb4d174c508ebb52f0893c3fe63e833cdc9e446d5733d57a572df4292d58cea7dc9e43d534a79b37ecf2cf96dddd9bdb32d9273215b76ccb6666a355ba40ff007338fa41fa47e639d0e170e772733d11338d5be186386258a35e945e433e96b58ac62184ce5ef2506030180c06030180c06030180c06030180c06030180c0601ba7a4f569d3a7c5af2d3d70226c866579dab929b6b92238dbc5b5e2c9e4b9c5e57d4a6b335a36f0f559e71176554b1d071272fb5b56dcb456b1aa267089ba6d765658efd61ef4b0a90f5dbc41e653c9b3e9f8fc18d98898d6cca7733a3c56b50d98fdc88f23a329e0ca7c88cf5c4aadb84180c06030180c06030180c06030180c0c8049d00d4e4810473c0c640c804f21ae480049d00d4e03204076937099abc0c56aa70b138fa8fe053fe27393cfe778c78d5b5298d65691451c51ac718e9441a2a8f019c099caed4f529095ad491a7b9a0ea95803a05f53cb358dfbf8f844cf8fa2308059b7393a8eabb7c67e05e5eeb0f13f94675781c1ff2b22f6c69dd3b9676d8180c06030180c08d2413c13fde51216c7f9919f92551e07d7c8e474d612b7db77482f464aea932709616e0ca734adb2acc618dd776afb64293d8563133741641d5a13c470cbd6b333a210a582a6f10aee1b74bd1653e1597420369c7a1c788ca5f6ff14d6c8f5ad9791abce9ecdb8ff8911e47f329f1199c4ad309192830180c06030180c06069b7696bc60e85e473d314439b31ccb7b7a36eb995ab5ccbd6df45a2ea9e721edcbfc46f051f857d067cb723916dcb665bfb26679c41bf764120a7578d971ab37846bf88faf967af89c69ddb7b19c6b2cd5ad1d684451f21c598f363e24e7d46dedc52310c2d3996dcbaa6030180c06030180c06030180c06030180c06030180c060302090db94c61424518cfefa41fe630fa07a79e71bea1cdc7cb56f4ae355aaaaaa8551a2a8d001e00670d66259638a3692460a8835627c862232376d566ada83de81fafc1811a329f2233eafe9dc7aededc4c7ea9eaf3ee4ce53b3dea2a773da1da53768911db1f3a724947937afae52d5ef0b44a255b696032e8639e3e12c0df329cac4a70df84180c06030180c06030180c0603018159dcb764afb7455e169d6c6e132c0ad50754e912fef25741c3e95e9d7d72442afdcbb94f56bc70c117dec75ecbddfba0e1d5ea103a4aab0e2e1871d727261efff00299a5920960ad02d57b54ea4b1cacdef13699559d342068bd5c3871e79194e114f756e5736c3663a7252af6045356b23e02a864d3db725d8b123c401e5a632612e2deedeefb84db4c44564ba93355dc2bea0afb12e8dd2e58f5ebe3a2ae993943753dde7dd2f5adbad225396412b5755d44852193a1886ea7570411a91d3a6ba699872a67f6ed31d70b574984bbfbaedfb3450c26295c14790455d3dc658a2d3dc95c6a3445ea1a9cf9ee2f06fbf136ce21a5af858c72c7244b2a30689d43abf81523507fbb3c7b9b734b4d67ac2d13955c923ee7274afc3b7a1f88f8cac3cbf28ceaf03839f9add116b63e29c000000340380033bac0c06030180c060301811acd476916cd67f66e47f249e047e17f319131e89ca5258abbcd5936fb8a60b234f762d78fc241ea427c0e6b4dcd7dd5b5515d2d76f4864883d8d9d8fc708d59e127c57c4ae6b1f37c55e8b4dc36d8371811f531cea3aa09c7065247f8798cc6d5cad13855c56268a7fb3babedd91f237d120f353e7e999e7b4ac9392830180c060301a8c0d762c455e132c87451c001cc93c80cadef148cca62332d742a48d27deda1a4ec348e3e6235f2fd3e79f2fcbe54eedbd9e888c461619e3112fde30058a21d76a5e1147e5f98fa0cdf6362772d881ae9d415e33a9eb99cf54d21e6cd9f53b1b31b75c430b5b2df9b2a6030180c06030180c06030180c06030180c06030180c06067020cef25c98d3aeda20ff7330fa47e01ea7399cfe6c523c6bd5ad2bde5650c31c312c512f4a20d140cf9d99cce5a3db32a82cc7451c493c80c0a9ea6dce51230d28467f7687fcc61f51f419dbfa7f0bfcecaded8d3bb64d5e78a7fbca242591f3a1f9251e4c3cfd73b38ef0c56fb6ee905e43a031cf1f09a06f994feb1eb9a56d95661372c8576e9b425a22785bd9bb1ff000e61e3f95c788cadab94c4ab6b5b6791ab584f66e47f3c47c47e253e232912b24e106030180c06030180c060303206a40f3e1922ba4dff006d8ec4d14896561af30ad35d310fb7595ba4052e1b5e25d472f1c09f665a9544b66c14f72842e59d48695236d0b68a0f0eae919234569f66b2cf7a1487dc999aac924ba46ceda0ea5e2dc7ab5f0c9159bc6d7b556dc69dd9d2797aac446b51af1233fbb5875a056f87e05e9d78f1f0d74c8136a1d8a4b12c4280ab6e487eea68acc423222594aea7e3217e352da0e1e3923d3d4861b30bd0af5abcb396d2e295d7a643ab08be2e3d478e838679b937dc8afc95ccad5c774da7576d495e7ab1c3ee162b34b1153a313ab8f8490a58f16d34d4f3ce56feff0026622b7af8d6663edd6568887c2e5df3bab78dd373b34fb8a286cc56e6a325495a28c254eb2a1d59868cbc0ea071cfa6ad2b48c4468c3abaefe97ee57776a9bc6d73eebfcc69ed96618a09d404f7226472c069c42f52e78b97c4a5e62d30d297c3e8888a8811005551a2a8e4065a231a40ce106030180c06030180c06068b551270ac18c73c7c629978329fd9e991309894bdb377679053bc0477070561f24a3cd7d7d32f5b76944c2db2eaa35ea15aec0629d751cd1c706561c8a9c89ac4a62549ee58a332d5bc750c7482d7257f46f26ccba692b754ac94180c060731fd45ee1dc762d862b1b7308ecd8b020f7880c514217d5436abafc3a7119d1fa771ebb979f2e910f0f3f7edb748f1ef2e66d6ffdd90d9bf493bad25dc36e8a6966aa2b420935d7ae450dd1e0067bebb1b53113fb7f2da7d7d7a3c56dedc8998fdcf9a23d3d3abb1eceb53efbb26dfbc5f21ac74c88500d17ae39193dcd3cc85cf8efff00a4afed6f7857f4e32ec703766fb599eae933e69ec47bb712ac3d447548c7a628c73663e19a6d6dcde7102353aae85a79cf5da978c8de43c157d067d4f178d1b55c77637b65273d2a180c06030180c06030180c06030180c06030180c06030180c0896e69a497ecea9fdfb0d6493feda9f1fd27c33c3cde5c6dd711fa9a52b9d653aad58aac2b0c43451cc9e64f8939f336b4da732d5b72a2a6cce3709857570b4c1d19b500ccc38f42ebcc0f1d33afc0e1794f95ba22d6f1f8a72aaaa8551a2af0007219df88606108d66a17916c40fecdb8fe494788fc2c3c462612b1daf775b44d79d7d9bb18f8e23c88fc487c465eb6cab30f5bf6fbb6ec7b64bb8ee127b7045a055035791d8e891c6bcd9dcf0032c871fdb7dc33f706d16ae7734516cd706e6f4b69895b59547b71b471b1fae5d4b7585e1c3d35ca4c44c26270bc8ac4f14ff677804b03e471f2483cd4f9fa653a692b25e4a18c06030180c06030180c0ca9d181f2232472f6bb6b729371baf1d51d73de4b505d6b2444b1afb7af541f1063a2370d31306597ed3dc99ef753bcd34a2c98ec99d163904c345531f4759fd0cfa0d386309ca36e3da5bf4db7d8ab12c7acb15b113a4aaaeb2ca13db2cccae02fc27e501b5d388c4c112e937bd9c6e6fb62487582acdee5ae990a369ec951a32907e6f2cb4aaaddcbb7e79eeabd128f5e0ad5e36aef2f5349ecda333c2e5b56d1d0e9a9cced7ac75988fbd6866876d5e4bc6dcd142abedda356bb375240f3396451a7e9e3d3cb90ca4efedc6b368fc47bed5d8f73dbadda9ee28449ea558ba0488c04d0b4bee955555d17e31a6bab11cce7939fbb5fd99c5a33a775abd58b3b46cd7adb241b7d511a36b62cfb31925bc55755fef39870b7391b9adaf3e2b5ab58ecb4ab468d3565a95e2aeada16f691535d396bd206b9d7999964dd90180c06030180c06030180c0606ab3562b317b720f5561c194f983898ca625b36fdda5af22d3dc5b5278416f92b8f00de4d935b76944c2ef3455aacd682cc2d0ce81e371a15391319141324fb5388e7632d06e11593c4a792c9fb73298f1f82f1aa50208d4710791c94180c0e3ffaa7b56e1b8f6dc0b4a07b0f5ed09658e3059fa0c6c9a851c4f16f0cea7d2b72b5dc9cce330e7fd4b6ed6a4623a4aa776eeeb97b6cbb5a3ed8bd15ab75da3f7fd83af5cea525562210dd1186d50ebab78e7b36f8be3689f38c44fafa74eff8bcbb9c89b5663c27331e9ebf73adfe9f6dd736fed0a156e4461b03dd768db98124aceba8f03d2d9f17ff00f4fbd5bf27e59ce2b8753e9db735da8895e5ab515581a694fc2390f127c00cf9fad66d3887bf08356096497ef6d0fdfb0d238fc235f21ebe79f4dc2e246d4667f532bdb3a425e7b99980c06030180c06030180c06030180c06030180c06030180c08b76d488c95eb8eab52fc83c1478b1f419e5e572636abeebd2994aa3492ac5d2097918f54b21e6cde79f2fb9b9379ccb648ccc556e369e7f76bd7eaf6a152d6e44e2da004fb69e6c73a3c1e1cee4e67a22670e724325ab14a5976e596b5884c704514bcd75eafddc84a04997a75656e078f1e1a67d2444446218ccba4d996fa6db0adf24d9504375105ba75f87aca92bd5a73d0e4a1330830345aa896029d4c73467aa19978329fd98984b5c494371bf4977a811f71dbd9a4a1236bed33b000ba8e5d6079f2f0c9adbb4a26147d81d87ba5073baf74c91cf7ebcd69b6caca7aa2ab1cf3bc8d2ebf54d229505bc1401e79a4aa97737dbb3f7641dbfb957a536dfb97badb6cf4e7692dc42040feecf194508a78aeaac78e83c72b31129e8b22f6284cb56f1ea463a57b7c83fe56f26ccfa692b754bc943180c06030180c06030180c0603418116d5894c82a5501acb8d4b1f9635fc4dfab3c7cce5c6d47fc9a52b9d652a95286a43d09c58f19243f33378939f31b979bce65acca465302b2dd992dcad4ea92a8a74b338f0fc8beb9d1e0f0a772733d11338498618a18d62897a5178019f495ac56310c2672f592830180c06030180c06030180c060303c4d0c5346639543a37307130978a7b84db6bad7b6c64a4c7486c9e69f95fd3c8e22d8ea4c657eacaca19482a46a08e208cd546248e3911a39143230d194f1046073f669cfb4b178834db69e69cde1fd1e6b994d71f05e272df1c89222bc6c19186aac3911819c210817dc2c18e362b4e23fbd914e85d87d2a47879e71bea1cdc7cb56f4ae355b02c069a9fef39c5fdcb7acfe29c3c4d347146d2cadd28835663911133295642925d9c5cb00ac4bfed613e03f1b0f339f41c0e1f84795baa97b7684ecea31630180c06030180c060303c4d345044d2cac11179b1c4ca5ef0830180c06030180c06030180c08f72dfb0aaa8bee4f21e98621cc9fd998f237e36eb995eb5cb750a46bab492b7b96a5e32c9fa97c80cf96dfdf9dcb665b256602befdb95e4fb2a8749986b2cbe11a9fd67c33dbc3e2ceedbd91338d655fb9ec35a5ae58eae95a098c309e5ef95d566d471eb523867d3d29158c43199ccb5ec7b7c3623afb94b59ebb8e978627665d64f6fa1a6788fcaedab0fd19642f30830180c0d566ac366231ca3873561c194f983898ca54bdc7b353ee2dabf907703baa7b8b2d0dc632474cc9fc3eb008d79e854f061c3262dea89850ee3b36e1b253e8ea87b5e8edf14536e1bd6d912fbb7ed33feeaad689896e9760bd6bf53108bc0e5d0bcedcef9da6fed15f6cee9b75a2df56073ba463e18525894bc89ee7f0d658e31d4e81b55e39338921630d85ad5e1b092fdd6cd6555ea5c1c7a5586aa18f91f0398cc63e0b75580208d4710791c94180c06030180c06030180c08b6edbabad6ac3aed49c87820fc4d9e5e572a36abeebd29940dbbb87b76bf704bdb5f75fff003da2caf14a0abccac85cbc7afccaa07123803c33e7776bb978fdc9e8d7cbb3a1cf2a55d76dcb3cc69546e961fee271f40f21f98e7bf87c39dd9d7a22671ab6d7af157896288688bfde4f99cfa5a522b188613396ccb20c06030180c06030180c06030180c0603030caaea55806561a107911811e0b33ed2df54db69f9979b43ea3cd7113e3f04cc65d043345346b2c4c1e371aab0e208cd62547a2011a1e20f318145776c9a83b5aa0bd75d8f54f507879b47fac66535c6b0bc4e510d83b8b0af5188848d6c4e381507e81ea7399cee6f8478d7ab5a53bcad2186386258a250a88345033e766733995de999554b31d140d493c80c0aad4ee73091b85189bf7687fcc61f51f4f2cedfd3f85fe7656f6c691d53b3b4c0c06030180c06030180c0d36adc55a30d26a4b1d11178b331e400c4ce1310db43689a7956e6e406abc60a9cd53c8b79b64d6bde5133e8ce406030180c06030180c06030355ab51d68badf5624e8883e6663c80ccf7776295ccad5ae5cb5fdff718b739e96d5b5befbbca45ee5f48e64af1548d87c117bafc3dd71c979f8f2ce06f5ff767caf3e35ecd6671a428bb47bcee6c9b6edb36e6f35becddcc2ff2bde67e3628b39d16aee07c7a4fc225fefc8ded88bcce34bc758ed3ef1fd1589c3e8fb85d788ad7ae3aadcbf20f041f8dbd33cdc6e3ceedb10d3de5e6a554af1f483d4ec7aa490f3663cce7d4eced46dd710c2d6ccb7668a980c06030180c0f134314d1b472a8746e041c2515648eb3c10ee91adba30c8b254b3228668645d4296d7cb5e0d88b63af42632e3ebff4facc1156dbfb9ecd36ec7edf7fbeab6ba8a4f76572c75ba7e50b1f571d3e7e1ae68a2e87f52e9eed72ad1edea1fcca84d7536fb36e42228c69c663146da3c8123f8ba80e9c25776694fb493245acdb693ab2737875f11e6b99cc63e0b672df1c91c881e360c8dc558723843380c06030180c06030235bb6d1158615f72d4bc238fcbf337a0cf3f27931b55ccf55e94cb87effdd06cf6f6ca1ba5cb74364dc04b26e5bad11209a59d34f6aa2c917c71f5ea482bc4e9d3e39c4dbb4eeccdbadfd27f8af69fc1456209f73b7b309365dc7639d98d5edeeefb53ac9b98942b328b70b6b298a51c0abff6e5e262b13ac5bd6bdbee55f44db67ee65a294774b15ac6f2c49b33d4464822427e1d03fc5ae9e7996c716376ff002c62beed3388ccad6ad68ab42228f973663cd8f99cfa2dbdb8a46218dad996dcbaa6030180c06030180c06030180c0d372fd0a290bdd9842b6265af092090647f941d39648f4b6a936e52ed89306bf044b34b0807408c481f172d7872c9c091ec4c792923c08c8c48c347d007b9aaf532a2803a8eac741a81e1e67270659304a091d3cb9e460cb1ecc9e2bcf97afe8c60ca1c7ef6d723d88180a2357b5031d0280352e9e47d3223313a267548d8bb946e733413547a529892cd759195fdc825242bfc3f2b7c3f121e23355171248a8ba9fec19e7e4f26bb35f295ab5cabd52342c51427592cc1469a93e39f21bbb937b4da7acbd10ce669554f236e33182324518ce9338e06461f48f4f3ceb7d3f85e53e56e88b5bc7e29aaaaaa15468a3800390cfa088606106030180c06030180c08f6ad8899628d0cd664e1142bccfa9f2191329c3229bd4824bb2d8acdbab7eee16b0da411b9e48343aff771cbd6bde5132e0fba7bbe0ddef27dd6fb6bb6766863658ada2988c3bad794130db0c35e43548dbe1719755f43cc9630180c06030180c060303c4f3c5044d2ca7445ff008fa0cadef158cca6232a4b9be6dbb5dda1637d66adfcc65fb7a2eca7d88988d544b272467d341af8f0cf9ee4ef5b7e67c7a437d2ba39eef5eccee0a2db86f3d996258bf99b07dff6980aabd941fc496a3b03ed5964e1a8f9bf4f1ccf637eb38aee76e93e9f1f65263d1d46d56f665ed6dba3dae998e8cf5d1686dd247d0c23d382bc67969e39946cdefb931fe595e318f64ea750c21a495bdcb32f19a4f5f21e833e938dc78daae23ab2bdb2939e850c06030180c060301818655652ac35523420f2230210ff00409ed4d10b7b4160cd0b8eb30953a82a0ebaa83c7d322271f04f5733dff4051dc6cf7c508d1ad7f2e1b7ed934119925372dc822599c2712111ba7d066b955376efea36d7b498b6bdf41db228e08fed12e4a65bcd001d1f717231a98413c3e2278f3c64745736d968b35bdbd7dcacdf14d50780fc51feccced5c6b098966bd886c442589ba90ff783e47112978b9b851a4a8d6e74816460885f802c780181bf0830180c06047b76c4015117dcb12708621e27ccfa0cc391c8aed5732b56b954770c9736ad9279695baf1f7259e9fb11648e99a5560df6eaa483a48074023913ae7cecee4eeee66d9f16d33a68f1d91ded1eff00b71afb8f46dddcb5488b75da9b5478662091d0ae4965238ab0d41ca7238fe1398d6bda5113942a5da4d437886c5addeeeffb9d60df606f34623a8b202acfd312c6ace54e9d4dab7ae7a766b6def96b58ad7b98c6b2ea6ad58eb47d2bab331d6473f33379939dfdadaaedd710cad6cb7668a980c06030180c06030180c060301815fbeed126eb5e940a81e38ad0966d4e9d2150956fff003e996c19541d87b8ca59bb2d749370bb5945b40fa2fba2445655d39feea3ead0f03c8e46253936ed93b8682b37db3cd1892f47043d51a158ec4717b27a502c68bd48dc1470d726225197adbfb63768abfbb24212ff00ddd46129218ac31b869343f8469a91e3888265e476fef0769fb74ac6bda5f606e13aca1dae744caf290afd48faa6bc5c6a7e5e59184e5e2cf6deeeb0566ad0cd34b10945786cb43d285a62e8088d50c03a4f031e8547c38c1955ff005a2fcb1c5b356fb9b15e95bb520dc5e9f517f6c46bc741cc06f3cdf6a3aca92f9e892d6d77b6fb15fb82cee37bef618a2580ca625a7d6037ba4f10483f2f2cd719d3087e8b91cbb93aea3c3f467c3f37916dcdc9cf699887aab18878cf22cd3b8d3bb3d090563a3fe1e4597c541f0d73adc2fa75af1e76d23b7ba93b91128bb7cb5deb05817db11fc2f11e0cac39839dea444462194a465906030180c06030180c08d3db90cbf6b5144b6db98fa507e273919ed09c351dd36cd8f6fdcf70757b73d3a8f764b0a06964469248d1576d4f515f68eaa3970cd2b5c2b3397cf2fecf1dddd36ddff78daaadd1bcf5cb6fb6a063652481d028dc2056d57ee618dfe32a0752ebe3a1cb21d7d0ed8a9b1ace6dd99afee37206a513c4f243626a80fee7ee5958754b12fc025f9b4cadad84c465d165126030180c06030180c0c3ba468cee7a5146acc7c0626622332988408ca4c1b73bcc21a35d4c91890e8a15412657d7d33e779bcb9dcb78d7a3788f187ce7bbbbbfb53ba6ed48e533ee9dad504a37fdb61134532890015edbc2bd124b5c10788d7424369c31b3b37db89ed79e93fc63e2a4cc4ae3fa6fb8ee752aee118b326e3da70c9edf6ddbb21d2e3a8e06121c06744e4b230d729c8da8b4c623179eb8e89a3b4a95a5eb6b567e2b527f722fe15ced7138b1b55f756f6ca567ad9980c06030180c06030180c0604443676c94cf517dcaac759ea0f0f368fcbf4644689eae6774fe9b43dc5bedddd60bb12edbbb34725a9511d37085e2896131433ab01ed48b18eb8e4561aeb9a44e55e8bcee6ee08f69dc36bdaebda4dba95455b7ba586e92b1d48f58e28006d4969d810bd3f17c272469d9379dbfb96bdadebb6e399057b0f5acc16233109991558b2027c55c687fbf296af784c4bc6e9616485b70721e0a9d0a945c1016c3c8103ce3c5632411e1ccf3d08889ca51e9efe2bdbb3eeda9b71ae8bd4ce91a9d1d78cae9d213f74a39924fa78e074a8e9222ba1ea470194f983843380c0d172da578c70eb95f84510e6cd996f6f576eb995ab5cb9beebdfb71ed6abb76e116defbc5fdc2ea55b15a1fe22406292590c4396a822d743cf3e7fcbff45a7ca71886b69c468a0ee5db6bf74247dedb36e2f676dfb6581abd6a51dcbf19494337da09cf4c137569ee6aba8e9d47103276adfb7ff5da3139f5c47dfeaacebaa6f6af6fb2d4a5777ba7f77dc90c931d9e7be124bb569c87f76b66451a1751a9f4f0cbc56772fe34fd33d71d1358d332eda9d45ae87e22f2b9ea9653cd9b3b9b1b31b75c433b5b2df9aaa6030180c06030180c06030180c06030180d06034180d06034180d06047b96da20b044beed894feea2f0ff0099bd0679f93c98daae7baf5a65be8d3fb78875b192663d4ee78f13f87c867cdee72f72d39f29fc5ae21273cc97aaa609a678c38678b4eb40788d796b9d3fa770a3767cadfa619ded86edc2e8a558ce609670081ed40bd6fc4e9c06a33e9b48860e6d775db374b31dadb7dd82f48f343ecc89d22568012eada1d3869c1b29319d61786cb3bf50ad34914d1d9d60447b7247175c70891430eb6d472078f0c212770bf5684114d2fb930b122c55d2ba7b8cece3a9741a8f0c6078a7bbed96e548239244b2e64535e58fa1d1a155660fa9e1f0c8a464e04bd53db12fb91fb44e824eb4e9d7cbab5d35c8c0cb274b74b322b69af49750741c75d09c60608015599d151f8239750adafe13af1c60c854a9208d08e6301902149665b1234151822a70b171b411c60f913c0b6475e89e8a3eecee7bbd9db86df53f91b6e1dbdb92b4573718a51f71f70dc93a0e9a929a951d43ab8e8411a36911857397cf3b336a5b5f77b06cd61eed0a779a5a16a31ad9db269c3bc16bdb93a74825d2482c404787e639643e9bb576eec7dbb329dba9ab7704917b72b2cb3bd78031ea7f66395e448119b8f4460652d7ed0b442daad4f699a595ccd6a5e32ccdccfa0f21e994884cca464a0c06030180c06030048009274038938106246dce6eb6d4508cfc2bcbdd61e27f28ce0fd439be5f2d7a37ad71f1715ddfdf14f7191fb78ed92d9d96dda3b6dab90ceb1cfd708596768a028dd70c29fc476651e1c751af9f678f35f9b3f34467ed3ebe8acca9767ed6dcf72df2bef3b8c72525a3724b67b8eb4ea1add654f6ea53aca17510687575751cb873d46d7dd88af8c6b98c63d27bccfb915ccbea35a29a79bef6d0d1c8d2088f111aff00ee39d1e0f13f6e333fa917b7684ccf7b3301819c0f5ed91af15d06bd4dd434047304ebc39e4e063a48241e1d3a962480001c492796300109f94ab71209560402398241e18c0c11a69c88235041d410791046300012401c49e030325481aea083a8d4104703a1e23c88c6079c064060670223c362ace6e50e0e7f8f5f924a07f837ae474d612a5ddb61d9263baf796dfb74bbb7732c2bf6d46460fed4f12048fda8642b1861f36a7fb08d73489895660ecbed2ee15a1b736f361a857a9fea3f95d66f8e6b529324d3db9b9b1791d98449c17912dc32703a9dd7665b24d8add31dbd346d46a922fe071e3ae56d5ca625ce47b69b36ec2197ed12411a5ca0102bf4c7ae888e080226d7905fedca4257c00550aa34503400790c94181a6dda4ad175b0ea627a6341cd98f20333dddd8a5732b56b9950dab8939dc76fa3bad687bc045d55ebbb2bb424a8744f6c91a861f369c81d73e7b7b76db968b5a27c1acce2310b0ed1ee08bb87668ae491086fd676afb8d461f157b917c32a68788e7aa9f1520f8e7937b6fc2d88e9dbe044e519761db765dfadee9b57b91dcdd934b3b7230159e5047faa68f4f85f4e0581f8bc46b9b6d45f7b14eb8eff00c93888d56b4ea7b0acee7dcb129d6694f327c87a0cfa3e3ec46dd710c6d6ca466ea980c06030180c06030180c06030180c06030180c06030345cb620450abee4f21e98621cd8feccc791bf1b75ccad5ae5ee85130754d310f6e4fe23f80fcabe833e5b91bf3b96ccb74ccc041dc2f3ab0ab57e2b6e389e6235fc4dfab3d5c6e34eedb1d8e9acb9983b93634eeb3db94a4b29bfc0f22b4ef1a9864758bde60edd7ae8ca34f973e9f6b6abb71e35633333acba0ddb75ddf70d99a1da222bb833ac56d03849218cfced1f570274e0a7fb737f2cc68a631289f6dbbc12ed1629eca62876df763fb41326bd3247d21babf4f3c083bbec1bbdfdc2fd86db652d7e2844452d98563658c291205d4368c3c8e2608959ee3466dd20dbabc767a27a16626bd3c0446ca638ba5d903291c5b970c753a22dfedb9c08e5dac7bf394b26ccd6e425e4925112a962bd3f447a0d341c3f4e460cab8769eec2bcfac4c434cb2c117b901d0184a36b108d62d3abc0687c7ab5c61394cffc5af4ced35c8a07b065dbd8b231e911c0c7de0bd44b74f49d08f1c9c2328dba76b6f32d37a75e24f674ba2bf4c881a332b86840eb591563e9fc23a81e44644c2625d568c9146243f1246a246275e2071d4e2510adb36d26af359926fb4d9eb82d6ae9d78a8e61341cbcdb2b1afc13d1cff716ff007e1dda7edf8b6b8771ed4b9b62d889a9b836e4466659658013edcded7c2cca082010413ae99ac44745563d917f66ef4ec79b69b922df5a4cdb6dc7d1d5cb42018a5fde057593a0a3124021f5d3964c4a13aad4a7b7b4957674593707548b71dea444f7a4f6c68beec88abeec801e67339b7685e23d536ad58ab4655352cc759246e2ccde6c7222304cb76106030180c060301819c0807ab7298c0848a519fdfc83eb23e853e5e79c7fa87371f2d5b52b8d65f3fdff00bcfb85bb907687dec1b15792d9820ee1ac04e8a444b2454e447e9114efd60fc5c187ca75d74f1edec57c7cf1e5a74fe7f044cea89b6763ef53f706f2db9d99764dc258ba377bd5e159695fad27c2d353676d6a4d22a0599743c81e397b6fd62b18f9a3b7ac7c7d63d08aeafa1ed3b740b5eb471c662dba9a2c542b1e7d2a340efeb9eee1717fcefd64b5b1a42df3a6c98c060303d47fc45ff987f8e48e4add3df9b6ddf9e1bb1c748de909a8d54bc8c018b5e997dc5e7ff2627298c3d6e7baef0f1df83aa53238b75e5dbfa0f42554a8ed1ca1b4f98b81f16bf172d31328788b71dc96b4b5a6b1251a7d56ba2c4716acd220fddc4781e0471f36e5ae32356dfbd6f30becb560795224342acd0ba903db9e25eb754e86ead3f1b3ae878687194e17fdadba6ed76ed986e93a6d9d346c6aa17ddb4ae499bf4345d0dfdb9312898526dd3ef31d4b095ec4d5e3aa96acc712a021e56dd2c0f8ba81254a0e4322329958ed57f7a9ac52b162c4924772dcd5e5aac804691884c8a57875021873d726112bcca860301811a7ad28985ba6ded5c5f1fa5c7e171913eb095a6d7bac7754a32fb56a3fe2c0dcc7a8f31eb9a56d9566309f9642bf74da63baa2446f66dc7fc19d798f46f3195b5729895657b32898d4b6bed5b4f0fa5c0fa90e6713d966cb5662ad11924fd0aa39b1f2032bb9b9148cca6b5cab6ed6dfd68cbb850820b1bc01ad5a96a468e155d78af5a2c84311e3a67cdeff002a376ff34cf8fb36c62310f9bef9bb769daeeaa56bb876d3b55bdc3a36fdef6eb80432ab83ad6b75acc642c8aa754731c9ae9d3aaf0cdf6e978a4c567311ac4c7e7130ce5d86cdda3276b6fd7f718378b3b82ee914712edd61559cc916a1656957a7ab453d3af4f2035274cc3ca77e22b15d617ad7bba6a750c5d52ccdee5a978cb21ffd23d0677f8dc6aed5711d59ded949cf4286030180c06030180c06030180c06030180c06030180c0d36ed2568c311d4ec7a638c73663e0332dede8dbae656ad732cd0a2e8c6d59d1adc9cfc917f0ae7cc727933bb6ccf46fd23109b9e510f70bcd0f4c100ebb72ff000d7c00fc4de833d1c7e3cee5b107bbc54a8b5d0eadd72b9ea9653cd9bf667d4ec6cc6dd710c2d6ca3276eec09bcb6f69b742bbb39666ba037b85993db27e6d38af0e59b21b3758ed25379f6fe98f70778e10e0a095a32e0c8b17b8c8864e9d7a753cf110841addd536dd04b5e7926b970d85860af662649e3ea4eb3ef7b2b2f50d38864539393090dded7191e4876b7e9af545ab31cc5a2946ae50aa2326a7e5d78e9c327c8c355cef0a89726916067a8165585e365d2c3208d75e23c1dcaebaf86464c33b8f70bd078ebd8db99b706f759a0899e64290aa3128628ddf56f70050c8bc79e8342523655dfa1b1bb2d0351eba390b1bce5a390b18fdcd7a194230fa74572dafd3a71c8165a640f32c91451b49230445e2cc79612d3568cfba3092c06876e075484f0797d5bc97115cfc099c2f8c10184c06353091d26320152a7c34e59aa8e2edff004dd6b6f5b5ee7b0df3b5d5a165ac4f4193dc87db91749961d48310938161c5780d00d38c4a5673584b72cd16d88b5ab4ae5addc8d42b4adc8f49006bcbe6399cdb3d1688c24430c5044b144a1517901fe271103de106030180c06030180c0853bc972634abb1545ff7330fa47e01f98e7339fcdf08f18ead695ef2aaef0ee5db760dbbec4cf2eded3c6e90ee490bcb055934d636b0ca088c31f17d06717676e6f6cf5f6f5f82d697cf3b7686fbdd56e0dcedc1b7ef1b3ee68db6f76bc122c5a9801786c345af4f5c64eb1bc4c4b2383c3419eedcb576e3119ada35aff4ff005eea4465f4ddb6923d5af4e37964dae8a88e033317926e8e00b31e240f0cdf85c4f29fdcb42d6b78e91d5719d8626030323890302a2df776c350ee2962c5786dd090c49524b08924df023290a486e25c8e032d38222535b78da925f6da6226081da0556621bdaf77da0da74993a78f4ebae9c71a0c53ee3db2dc352c7bb2571694308e58dc32066e90643d3a2063c14b733830db57773636e9770f6982c227eb894866610780247d593930d7b0ef726f3b62de58fda8cca51594f5c6e01e0e85803fdba646724b4d7ee69e5dde4a71d4478a0b06b4abef20b6a1188f78c1cfdafa81e7a71d31930f6770d936fa4b2569102d9692c47d464d6460fa48ecc14b6a35e1c3242af74edb6a9adb0f356569a787da96272ffe9e431bc84053f07896e4391e3ae464c24c5bad49ecb5486d09261a81d2adedb10a18aa49d3d05ba581d01d74c0f7950c060301811ed541332cb1b186d47c629d798f43e60e44c253b6bde3df7fb4b6043794715fa5c7e243e397adb3a4a2616997551371db6b5e87a25d55d38c72af0643e60e45ab94c4e151576e9c58f7ee4a27922d560d068a07e2d3cce7caf3b9537b4d73a43d35c4468b0ce7a553dc74764b94d22dd29457fe356ad04a81c99148652baf11a11ae6fc7f39b62a8c65b2a55915dac596ebb727cc7c147e15cfa5e2f1636a3dd95ef9f82567a9430180c06030180c06030180c06030181cff007af70d9d976c56a9d0b6ec7ba12694174892189a6964e81f3b2c684aa7263c09191acce23edda3f19d17ac477f6506d3dc1dfac4ed771a05dd6e074a735b8e08a4af32c5ef0f760a52da8d91a3f897570daf0234e39a4d6263d3fd713f7c7e0ca2711e5dbfaf4f7c6749d343ff0023eed88d8da5371ad7edc9b957db6a6fa2aac71234abacea6babb248f09e0747d35e074208c8ac79e31a7ea9f8c563afb6ba7dd94de7c339d748fbad33888fc35fbdeaff0078f7556ec9b1b8430d79b75a165eadeb8c3a200b159587dc584124bca8c0851f0a9d753cb59a62d6a4c7e9b7f2cc4fe712d2b4f9ad5eb31d3efaf96bf048ee8ee4ee4abbb5f3b5cd047436386a4f72bcb17b8f67eee631b28935062f6d17a8100ea78656b311f35bf4f9f8ff000d7f1b4338f9a2223f578797f4fe165bf726edba249b66ddb2b2457b7790ac76e64f71208950c8d27b5a8f71b8050baf8e3c67ce6be91333f74c47f19fc08b47845b1d711f8c67f288951d5ef9976b83745dcf73a9dc8f4e6821a8fb5fb11d9926b0dedfdbcb5924758995f40199b4e7ae9a656d7af8c4fbfdd3df3f7444e7f24f8cc5b133dbef8ff5ecdf5bbd4111d97da2dd8dfa7b33528f6443009616aea5e4d6479160d3a06bd5d7a1f0d73e7f956b6edb398f0c673afc3a75eba746f1388c4e93a7df9d7f86a956bfa9bb6c752adaadb7dcbb1cd53f985a112a2b56ac1ba0bcab2321660c08e84ea6f4cf27fe59899ccc6234cf6999e98febd16ac4ce23fcb3318f875546ebfd5ea7b2cbb80dc3a1e46b091ed554cb0563ed1a914eed24b6248e2f85a5fc5a9e401cde9c19b6223dfca7e16b57e3d99c5f319ed311f9c65d676d5aa9b96d75f76ab21b03708d66f7b9ea08f9469af05e5c33e83678b1b31867fbbe71943efede374d97b5edee1b6145bf1342b17ba9d69f1cc88415e1cc3119ac4fcd58ed9d7e111333fc1315cc4fae34f8aba1ef0dc64eed7aaaa24d9a1da8db78e1899e77b48cbd6a84713d20e9d2071272d3a56d3e93a7f7f8e635eca44e62b8eb33afdf138fff0019438ffa9fdb9bcecd7fdcdae6b42b59a95a4a114d5677696d38581925af2bc6a55be605c32f8e4f8ce231af967f28ca73899ce988cfda3aae364b3b25cd9aec9fcb64dbecd29d8df86d4a0d88ac423e173346d229f847c25491a656f68ad7cbfc7fa75fc0ae66de3df4fcfa293b77bee2b1bdcac9b25aa5b6a6cc6c9af2a096c584123743465598e8c0ebd2fa3789032634f2cf5ac574f49999eb3d31efd3dcb6be38ef6b6beb111dbedab456ef0d9370dab6a87b7f64f7a08f731b35caab62958548aca0b0fd13433c90b16d41d55c9041078e6b4db89b467f4cd6d3f0f1fb76566d889f58c7e7fc3efc2da877176bee3dc7376ad7a12c5ba575b32c12cd6215965e828930963491ed42241d3d3eec6bd4a355e194a57cab368edfcfe1f9c758ee9bcf8cc67bfdbed3d145bf6ffbb4fdc2576383ecdf6c690cf188abd9757ad1a2cd61c5c9aac712451ccaaac8e59ba8f0e194da999d7b7e5e91efaebd23b7c17bc62311acff00ae91f877fea9fb9f737763ecb63744dce86cebb67b905b5101bbf756d7a4c4917518fa525eb0074eadd47400e2da6b1ae7a57dfbc67eda6b28ad733e3d3be7dbd71d3d73af6786df7bb27dc5b72b8b056dbf69976f8aeeccf1fb8d21ba4095ccbaea8d106d55403af23a65eb4ae6267f4daf348f8f48ff00e5f933f3cd671a5ab4f29fe38fc21d5ffe51be45ded7b6eb504506d15f6c6bb5501ea9dd9263197723e155603e151c74e7a1e1916b78eddad3d6b3fc9af867c71de71f921f66f74771497211dc166bcb5f73db63ddaa98a3f6bed84a4f5572756f7022e9a39d09f2cd6d58acda93faa98ccfe5fc6258f945a2b7afe9bcce3eed63f2952efddcddc5bd2eed76b6f34fb73b776b97eda237a38d85c995439f76591e310a331e81a6a7c73cde59ac5a7a5ba47c2663f1d25b447cd35ff6f59f8c67f2cc26bff506bd58aba1db25b291d6ab6374b341e196ad4169bdb4218bab4ca5c1fe106e1c4e99a4d63cb1d2b9c667d7ae3f38f6d59c4ce23bdb59d3d23bfe53f84a5a77d527de86deb46cfd935a3b7aef3fbbfb636847eefb7d3d5ef69d3f5f474ebc35cac74d74d2663df1d7f84fe12b5a71d35c633ed9e9fc63f1556e1fd4c0fb65d9286df66b4a69dab7b4ddb0b1b413ad50419022b9751d63e590293fa326b599b444e93f2e63da6d15fe7f72d3189f58ccc7df1599fe4dfb77f557b72e77145b02b29b3239ae2713d6e36117574fb6121b2a35e018c7d3eb8a57cba7bcc7c23f869eb8fc59dade3119f6cfc67edd9d9e55630180c06030225a9e579453aa7f7ec35924f08d3ccfaf967879bcb8da8c47ea694ae759566f5dc34b63b7b56c35807dcb7891a28017542005d5e63d47e223f08e273835a4ee66f3d217b59f32a7b5c717f2bab0ed3769ff0052a9d85fe6174432182e2b3696669ec11ed495e51ab713c0e833dd37ce67313b53d3dbd3ef8531f8be9f4765d9a096cd6d9a9c54684d319afb40a104f36801e5e806b96e1f1adbb316bce90bccc57e2bc555550aa3450340072033b911862610cf3c0f660980d4a1d07a64e0cbca2b3300a09238e83021bec95de1dd2b9705f7295a5eb31ea63251100e5a9f9324476ed654942bdb7144ce2d98ba3493de107dbe81cfd3a7c5e7e18c19478bb26369219e4782d3ac514123cd5fdcf820919d0c60f00c43907fb0f8622a6535b63857659b6769d82caccfef05f94970ea0a1e6bf0e84788c7b0d7b26ca76bbd72dfdd8956e68c69a47d1145275024c5e41b9b0f3c4683c5ad82c5cb4a67dc0c95058166356881b29f116f6926fc3c7407981c3023cdda32388619b70021aab2a409ed10dd32c824d58f98d34c60cbccdd9d5a4e92f3c360a496fa16c42644f6ae4c673aafe246761e4473c8c4272995bb7e2adbc477e1b0224420b450c62232058bd91149a7c25069d43c7c3250e6ae7f52aaed326eb1df2b6a4a76670b1fbf124fd2a6211c6b1310cc34763ae9e1978db9946533b47fa8fb3f745afb5a35e6866485a69d26d354e97550355f85babab5c5f6fc4897579924c0603034daa9158401b55753ac72af06561c883898ca5bf6edde5495696e2409cf08671c1651fa9bd326b7ed289afa274f3f51e95f97c7d7387f51fa8f96694e9de7f934a53bcb46711aa3debb15380cb26a7c11073663c8669b7b7379c408956b4a6436ed68d65fe55e6235fc2b9f4dc4e246d47fc995ed9d23a25e7b19980c06030180c06030180c06030180c06056f706c35f7aa1f6b2caf5e543d75acc7a168df4d35e93c1d48e0c87830e07226b95ab6c399a3fd2f14f6a9a9c1bcc95acb23c552dd3ab0d54acb2ff0015a3af19e83238f84c84eba70cbda7318f867be623b7c15ae939fb67d7dd2e0ec4be9b2c5b64bbe12694b158da27af46bd6156483e52228cf4ca0ebc4364daf33313fe5fca7b22b5c663ac4ff1f5cfaa59ecaacdda73f6ebdc95fee98cb66f955f71e579c5877e8f94753f00bc80c79626b311fa7edf9f55e9698b4da7599fe98fca1e37fec94ddf736b83729a9c169208b74a712232d94ab219611d6df1444313a95f987039149c4ebac6738f7fb63f053a56223ac4633ed3f6fce537b9b67ab7eb4139b0f42e6df27bfb7dd840668a4e929f237c2ea558a953c0e677bf8fcd9c7f3f6fb77d56ad6263c71a7f4e93f6eda282b7f4dac5d8ecee1bb6ed2cbbe586824a979208a0101aae2585bedd358d8f50f8b5f987039f3fbff5099b7cb1a77f7d31fc267f8b6f1d313ac63fbff18894d6fe9ed95af5e6afbdcf16ff000d896dbeee628dfdc79d4a480d76fdd84e93a2afd39e6ffd319c78fc9318c7df9ebeb92633d759d31ed8d3f868e77bcfb4775a15e950edc4b8cd2d23b6d9b426abd3246ce5889566659437512c5e204e7a38f68dd9989c444cc6235d31d3a7b6989eabd666bf375b6667f1ebedd566bfd32613ff0033877796a6f6cc0fdd2c114f1a2182381e21149f0b0d220431e20e77f676fc231eb9cfdf69b7dd8cbcb8d223fdb8c7dd18fcdd3cbdbbb5dbd962d9f74886e9511516416fe332b20f9df4d3893c735be2d39c15cc4756bbfdb3b759d922d96b81468c0f0bc31c2a084104cb3040ade04ae99336cda2d3ae3fa4c7f34444444c477540fe9b6d62adcac2dcc23b90de85ce8ba8fbf64666075ff2cc7f08f1cae67111de3c75ff00e99cff0065f3fc7f2f19ae3f399cfaaa6e7f4d37586bcf254dde4b7b8dcb3b634937b10565823a12a90f1c687a0909a92bf565e2fac7c6d39f79acc7e1953c7e5c7fc711f8c4fe3eeeaf65eda4a142e57b969f73b3b948f2ee16e44588c85c69a08d3e14551c00194bd626be18f975fcfaad5998b7977d3f2e8e5edff49e6b304a963b86cd9294bf97edeaf0c4a21815ba943953accde04bf3cb79cf979ff9e6273ef139e88c463c634aeba7c74ebedd961b1762bcdf7123ef728de5b70adb958735a040b2568441d2912fc1d0e83c3965b6ef1888f4f2ff00e5d7f3e9f82b6ae9f74447b626663f8ff3586c1fd303b46ff5373fe6f24f5e81b9f6748c112054bd2091c3c8bf1c8432f066e397a5a6235d7e58afe1d3fbfaa2f19ffeef2fbf5cff001d3d1a7bdbfa515f7ddcd777a3692a5e52259219ebc56e092541a2388e52023e9c0b0e7c35e5994571398fb7ded26d98c4a28fe936e82cd2bd5fb864ad66a0790473d686f2fdc4ba75d8d66ff374f843782f01935cc4e7db11ed1f6eaadb1318f7ccfbff00a2e6dff4f64b7bbc77a6dde6f6256ab36ed4d638c25b9e910d0bf573886a0752af06e59a56713a74899988f499fb67e2ace66b8ef8c4cfac2c773da76eafbe3f70da9d875513b77dae834653219351f57571d34cced8f0b567a59a45a71111da72e5fb63b265a3696e5fbf35e8ebd74a5b55499113edea46c5a347287f78e35d0bb713959bcdb5b759eb3ebf6ebf127ae9d33338f4cfdb0dfb9f65d99acdc9769de24da61dccf5ee5545786d472bf408fad3defe1314500f4fe9cac574f19fd3e9f1ebafbff5f52675f28fd5ebf0e9f6f4469bfa6f5758e1a5ba59a7b73c15eaee1482a4a6cc751cbc5fbe6f8e36ea63d457e619a796bac7cb9ce3de2223f957f057188d3f562633ed39feb38f4ca4c5d890c7bcfddff319bf950b67704d98c69edada31fb5d7ef7f10a74ff0097cb5e394edafcd88988f6cf5fe33f8a663d34ce33ef8ff48fc1cc6d5d85bfdbb9629ee1f75b7ec50d3b54b6f8e792a4ee896db8f41aeee5fa79eb2e87c32f49ff0029fd5f2fe568b7f2c7bfdc9dc9d711d3333f8d663e3df2e9f6aec73b66ebf735b769c6d8257b3fcabda8c0334aba316b1fc529d5f108f90c8ace231e9188f68fe78ecacd7fbfbcff002cf77fffd9, 52304, 'image/jpeg', NULL, 0, 1, 0, 1, 0, 1),
(1015053, 8, 639, '', 'Aaaaa', 1, '1015048', 1289790515, NULL, '127.0.0.1', 0, 0, 0, 0, NULL, '', '', 0, '', NULL, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `forum_reports`
--

CREATE TABLE IF NOT EXISTS `forum_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_id` (`forum_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=465 ;

--
-- Dumping data for table `forum_reports`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_scores`
--

CREATE TABLE IF NOT EXISTS `forum_scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `voted_post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `voted_post_id` (`voted_post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=215 ;

--
-- Dumping data for table `forum_scores`
--


-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `banner_url` varchar(255) NOT NULL DEFAULT '',
  `approved` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `approved` (`approved`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=92 ;

--
-- Dumping data for table `friends`
--


-- --------------------------------------------------------

--
-- Table structure for table `hosts`
--

CREATE TABLE IF NOT EXISTS `hosts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `target` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `hosts`
--


-- --------------------------------------------------------

--
-- Table structure for table `images_upload`
--

CREATE TABLE IF NOT EXISTS `images_upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `data` longblob,
  `size` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `images_upload`
--


-- --------------------------------------------------------

--
-- Table structure for table `join_requests`
--

CREATE TABLE IF NOT EXISTS `join_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `born_date` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `date` varchar(50) NOT NULL DEFAULT '',
  `motivation` text,
  `program_name` varchar(255) NOT NULL DEFAULT '',
  `program_data` longblob NOT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '',
  `passport` varchar(255) NOT NULL DEFAULT '',
  `agreed` tinyint(4) NOT NULL DEFAULT '0',
  `refused_because` text,
  `handled_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `handled_by` (`handled_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1028 ;

--
-- Dumping data for table `join_requests`
--


-- --------------------------------------------------------

--
-- Table structure for table `jokes`
--

CREATE TABLE IF NOT EXISTS `jokes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `jokes`
--


-- --------------------------------------------------------

--
-- Table structure for table `library_books`
--

CREATE TABLE IF NOT EXISTS `library_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '',
  `author` varchar(100) NOT NULL DEFAULT '',
  `pags` int(11) NOT NULL DEFAULT '0',
  `year` int(11) NOT NULL DEFAULT '0',
  `rate` int(11) NOT NULL DEFAULT '0',
  `available` tinyint(1) DEFAULT '1',
  `original_owner` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=107 ;

--
-- Dumping data for table `library_books`
--


-- --------------------------------------------------------

--
-- Table structure for table `library_feedbacks`
--

CREATE TABLE IF NOT EXISTS `library_feedbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_id` int(11) NOT NULL DEFAULT '0',
  `sender_id` int(11) NOT NULL DEFAULT '0',
  `rate` int(11) NOT NULL DEFAULT '0',
  `operation_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `library_feedbacks`
--


-- --------------------------------------------------------

--
-- Table structure for table `library_operations`
--

CREATE TABLE IF NOT EXISTS `library_operations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `book_wanted` int(11) NOT NULL DEFAULT '0',
  `book_exchanged` int(11) DEFAULT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `agreed` int(11) NOT NULL DEFAULT '0',
  `closed` int(11) NOT NULL DEFAULT '0',
  `price_offert` varchar(100) DEFAULT NULL,
  `starter_id` int(11) NOT NULL DEFAULT '0',
  `receiver_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `library_operations`
--


-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE IF NOT EXISTS `links` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `links`
--


-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112474 ;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `ip`, `timestamp`, `user_id`, `text`) VALUES
(112455, '127.0.0.1', 1283644565, 8, 'pierotofy (8) effettua il login'),
(112456, '127.0.0.1', 1283644674, 17008, 'utente (17008) effettua il login'),
(112457, '127.0.0.1', 1283644689, 17008, 'utente (17008) effettua il login'),
(112458, '127.0.0.1', 1283646310, 8, 'pierotofy (8) effettua il login'),
(112459, '127.0.0.1', 1283648376, 8, 'Creata nuova guida: Guida X'),
(112460, '127.0.0.1', 1283648406, 8, 'Creata nuova guida: Guida X'),
(112461, '127.0.0.1', 1284251700, 8, 'pierotofy (8) effettua il login'),
(112462, '127.0.0.1', 1284261274, 8, 'pierotofy (8) effettua il login'),
(112463, '127.0.0.1', 1285362383, 8, 'pierotofy (8) effettua il login'),
(112464, '127.0.0.1', 1286656804, 8, 'pierotofy (8) effettua il login'),
(112465, '127.0.0.1', 1286656992, 17008, 'utente (17008) effettua il login'),
(112466, '127.0.0.1', 1286660549, 8, 'pierotofy (8) effettua il login'),
(112467, '127.0.0.1', 1289785678, 8, 'pierotofy (8) effettua il login'),
(112468, '127.0.0.1', 1305910203, 8, 'pierotofy (8) effettua il login'),
(112469, '127.0.0.1', 1305910319, 8, 'pierotofy (8) effettua il login'),
(112470, '127.0.0.1', 1305910429, 8, 'pierotofy (8) effettua il login'),
(112471, '127.0.0.1', 1305910836, 8, 'pierotofy (8) effettua il login'),
(112472, '127.0.0.1', 1305916439, 8, 'pierotofy (8) effettua il login'),
(112473, '127.0.0.1', 1307643587, 8, 'pierotofy (8) effettua il login');

-- --------------------------------------------------------

--
-- Table structure for table `medals`
--

CREATE TABLE IF NOT EXISTS `medals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `medals`
--


-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `description` longtext,
  `age` varchar(10) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `born_date` int(11) DEFAULT NULL,
  `last_login` varchar(30) DEFAULT NULL,
  `is_founder` char(1) DEFAULT NULL,
  `interests` varchar(255) DEFAULT NULL,
  `employ` varchar(255) DEFAULT NULL,
  `icq` varchar(255) DEFAULT NULL,
  `msn` varchar(255) DEFAULT NULL,
  `aim` varchar(255) DEFAULT NULL,
  `yahoo` varchar(255) DEFAULT NULL,
  `web` varchar(255) DEFAULT NULL,
  `medals` varchar(255) DEFAULT NULL,
  `review_message_shown` tinyint(1) DEFAULT '0',
  `library_disclaimer_shown` tinyint(4) DEFAULT '0',
  `personal_info` text,
  `real_name` varchar(255) DEFAULT NULL,
  `real_surname` varchar(255) DEFAULT NULL,
  `working_exp` text,
  `reunion_pass` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `email_activated` int(11) DEFAULT '0',
  `webhost_activated` tinyint(4) DEFAULT '0',
  `webhost_pass` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=501 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `nickname`, `description`, `age`, `location`, `mail`, `image`, `born_date`, `last_login`, `is_founder`, `interests`, `employ`, `icq`, `msn`, `aim`, `yahoo`, `web`, `medals`, `review_message_shown`, `library_disclaimer_shown`, `personal_info`, `real_name`, `real_surname`, `working_exp`, `reunion_pass`, `skype`, `email_activated`, `webhost_activated`, `webhost_pass`, `twitter`) VALUES
(4, 'Piero Tofy', 'Analista e programmatore C, C++, Java (con conoscenze avanzate sulla crittografia e sullo sviluppo di applicazioni per dispositivi portatili), Delphi, Visual Basic 6 e Php. Ho anche solide basi di VB.NET, C#, Javascript, Html, Pascal, Assembly x86 e MIPS, Python, PL/SQL, Perl, Ruby e Objective-C. Conosco le basi di Ruby on Rails e quelle sull''uso dei Web Services, possiedo una discreta conoscenza sul Reverse Engineering, conosco le librerie MFC, Managed DirectX e le OpenGL. Padroneggio discretamente il programma di modeling 3D Blender, Adobe Photoshop CS2 e Adobe Flash MX. Da marzo 2009 ho cominciato a sviluppare per l''iPhone/iTouch e subito dopo ho iniziato a sviluppare per Android. Ho una buona conoscenza nell''uso di Drupal.', '16', 'Duluth, MN', 'admin@pierotofy.it', 'pierotofy_piero.png', 607903200, '09/06/2011 18:19', '1', 'Hockey su ghiaccio, pallavolo, camminate in montagna, programmazione e aikido.', 'Studente', '318386970', '', '', '', 'http://www.pierotofy.it', '|4çMedaglia per il progetto Multiplayer Poker||2çMedaglia al vincitore della 3° edizione per il miglior banner del sito.|', 1, 1, 'PieroçToffaninçAmericaçDuluthç12345çBrainerd Aveç2187286412', 'Piero', 'Toffanin', 'Lavorato per l''azienda Info-Synergy nella costruzione di una libreria crittografica.\r\nLavorato per Icslab.it nella costruzione di un applicativo per la memorizzazione, gestione e stampa di cedolini.\r\nLavorato per 3 settimane come stagista alla Euris Solutions S.p.A. dove ho svolto un lavoro di ricerca sulla tecnologia Silverlight.\r\nHo sviluppato il gioco 3D Tunnel per l''iPhone (www.3dtunnelonline.com)\r\nLavoro come sviluppatore e amministratore server per il dipartimento di Business ed Economia all''University of Minnesota Duluth.\r\nHo sviluppato l''app "Pro Card Counter" per Android (www.procardcounter.indieappsalliance.org)\r\n', 'k8s19AP5', '', 1, 1, NULL, 'pierotofy');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_tm` int(11) NOT NULL,
  `viewed` tinyint(1) NOT NULL DEFAULT '0',
  `important` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `from_id` (`from_id`),
  KEY `to_id` (`to_id`),
  KEY `viewed` (`viewed`),
  KEY `deleted` (`deleted`),
  KEY `multiple` (`multiple`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `messenger`
--

CREATE TABLE IF NOT EXISTS `messenger` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `msgfrom_id` varchar(255) DEFAULT NULL,
  `msgto_id` varchar(255) DEFAULT NULL,
  `message` longtext,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `msgfrom_id` (`msgfrom_id`),
  KEY `msgto_id` (`msgto_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19445 ;

--
-- Dumping data for table `messenger`
--


-- --------------------------------------------------------

--
-- Table structure for table `midi`
--

CREATE TABLE IF NOT EXISTS `midi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `artist` varchar(255) DEFAULT NULL,
  `song` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18883 ;

--
-- Dumping data for table `midi`
--


-- --------------------------------------------------------

--
-- Table structure for table `most_visited`
--

CREATE TABLE IF NOT EXISTS `most_visited` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(255) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=200 ;

--
-- Dumping data for table `most_visited`
--


-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `small_text` text NOT NULL,
  `full_text` longtext NOT NULL,
  `data` bigint(20) NOT NULL DEFAULT '0',
  `read_count` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `refer` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5591 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `small_text`, `full_text`, `data`, `read_count`, `member_id`, `refer`) VALUES
(5590, 'News di esempio', 'Questo è il paragrafo di una news.', '<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>\r\n<p>Testo</p>', 1284941544, 2, 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6066 ;

--
-- Dumping data for table `newsletter`
--


-- --------------------------------------------------------

--
-- Table structure for table `newsletter_queue`
--

CREATE TABLE IF NOT EXISTS `newsletter_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `body` text NOT NULL,
  `type` int(11) NOT NULL,
  `headers` text NOT NULL,
  `resume_from` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `newsletter_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `news_comments`
--

CREATE TABLE IF NOT EXISTS `news_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `news_id` (`news_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `news_comments`
--

INSERT INTO `news_comments` (`id`, `news_id`, `user_id`, `comment`, `ip`, `timestamp`) VALUES
(1, 5590, 8, 'Commento news!', '127.0.0.1', 1284941564);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `notifications`
--


-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `online`
--

INSERT INTO `online` (`id`, `ip`, `timestamp`, `user_id`) VALUES
(1, '127.0.0.1', 1307643587, 8);

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE IF NOT EXISTS `partners` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `partner_name` varchar(255) DEFAULT NULL,
  `partner_url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `top` tinyint(1) DEFAULT '0',
  `position` int(11) DEFAULT '99',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

--
-- Dumping data for table `partners`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll`
--

CREATE TABLE IF NOT EXISTS `poll` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `vote_id` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2805 ;

--
-- Dumping data for table `poll`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll_questions`
--

CREATE TABLE IF NOT EXISTS `poll_questions` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `poll_questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE IF NOT EXISTS `programs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `program_name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `programmer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `categoria` varchar(64) NOT NULL DEFAULT '',
  `pro_votes` int(11) DEFAULT '0',
  `cons_votes` int(11) DEFAULT '0',
  `approved` int(11) DEFAULT '0',
  `screenshot_filename` varchar(255) DEFAULT NULL,
  `rates_score` float DEFAULT '0',
  `rates_count` int(11) DEFAULT '0',
  `comments` int(11) DEFAULT '0',
  `website` varchar(255) DEFAULT NULL,
  `long_description` text,
  `support_windows` tinyint(1) DEFAULT '1',
  `support_linux` tinyint(1) DEFAULT '0',
  `support_mac` tinyint(1) DEFAULT '0',
  `support_bsd` tinyint(1) DEFAULT '0',
  `timestamp` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `approved` (`approved`),
  KEY `programmer` (`programmer`),
  KEY `screenshot_filename` (`screenshot_filename`),
  KEY `program_name` (`program_name`),
  KEY `type` (`type`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18741 ;

--
-- Dumping data for table `programs`
--


-- --------------------------------------------------------

--
-- Table structure for table `programs_categories`
--

CREATE TABLE IF NOT EXISTS `programs_categories` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `descr` varchar(64) NOT NULL DEFAULT '',
  `descr_long` varchar(255) DEFAULT NULL,
  `congiunzione` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `programs_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `programs_comments`
--

CREATE TABLE IF NOT EXISTS `programs_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id` (`program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `programs_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `admins` text NOT NULL,
  `developers` text NOT NULL,
  `recruitment` varchar(128) NOT NULL DEFAULT '',
  `os` varchar(128) NOT NULL DEFAULT '',
  `license` varchar(128) NOT NULL DEFAULT '',
  `programming_languages` varchar(128) NOT NULL DEFAULT '',
  `creation_date` varchar(128) NOT NULL DEFAULT '',
  `forum_id` int(11) NOT NULL DEFAULT '0',
  `releases_count` int(11) NOT NULL DEFAULT '0',
  `svn_requested` int(11) DEFAULT '0',
  `svn_repname` varchar(255) DEFAULT NULL,
  `svn_pass` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `svn_requested` (`svn_requested`),
  KEY `name` (`name`),
  KEY `programming_languages` (`programming_languages`),
  KEY `forum_id` (`forum_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=553 ;

--
-- Dumping data for table `projects`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects_bugs`
--

CREATE TABLE IF NOT EXISTS `projects_bugs` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `submitted_by` varchar(128) NOT NULL DEFAULT '',
  `fixed` int(1) NOT NULL DEFAULT '0',
  `priority` int(5) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `fixed` (`fixed`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=202 ;

--
-- Dumping data for table `projects_bugs`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects_files`
--

CREATE TABLE IF NOT EXISTS `projects_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `size` bigint(20) NOT NULL DEFAULT '0',
  `version` varchar(20) NOT NULL DEFAULT '',
  `release_date` varchar(128) NOT NULL DEFAULT '',
  `notes` text NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT '',
  `release_require` text NOT NULL,
  `owner` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1602 ;

--
-- Dumping data for table `projects_files`
--


-- --------------------------------------------------------

--
-- Table structure for table `projects_todo`
--

CREATE TABLE IF NOT EXISTS `projects_todo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '0',
  `sender` varchar(10) NOT NULL DEFAULT '',
  `assigned_to` varchar(10) NOT NULL DEFAULT '',
  `date` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=570 ;

--
-- Dumping data for table `projects_todo`
--


-- --------------------------------------------------------

--
-- Table structure for table `query_stats`
--

CREATE TABLE IF NOT EXISTS `query_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` varchar(255) DEFAULT NULL,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=536710 ;

--
-- Dumping data for table `query_stats`
--


-- --------------------------------------------------------

--
-- Table structure for table `quiz_attempts`
--

CREATE TABLE IF NOT EXISTS `quiz_attempts` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `mail` varchar(128) NOT NULL DEFAULT '',
  `language` varchar(128) NOT NULL DEFAULT '',
  `rank` int(2) NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `browser` varchar(128) NOT NULL DEFAULT '',
  `hour` varchar(5) NOT NULL DEFAULT '',
  `day` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `quiz_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE IF NOT EXISTS `quiz_questions` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer1` text NOT NULL,
  `answer2` text NOT NULL,
  `answer3` text NOT NULL,
  `answer4` text NOT NULL,
  `lang` varchar(128) NOT NULL DEFAULT '',
  `rank` int(2) NOT NULL DEFAULT '0',
  `true` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `question` (`question`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `quiz_questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `referendum`
--

CREATE TABLE IF NOT EXISTS `referendum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `preference` varchar(255) NOT NULL DEFAULT '',
  `voter_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=87 ;

--
-- Dumping data for table `referendum`
--


-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `descr` varchar(255) NOT NULL DEFAULT '',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `context` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `reviews`
--


-- --------------------------------------------------------

--
-- Table structure for table `reviews_cats`
--

CREATE TABLE IF NOT EXISTS `reviews_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `descr` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `reviews_cats`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_queries`
--

CREATE TABLE IF NOT EXISTS `search_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `query` (`query`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1594 ;

--
-- Dumping data for table `search_queries`
--


-- --------------------------------------------------------

--
-- Table structure for table `stallman_editions`
--

CREATE TABLE IF NOT EXISTS `stallman_editions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_date` int(11) NOT NULL DEFAULT '0',
  `end_date` int(11) NOT NULL DEFAULT '0',
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `winner_id` int(11) NOT NULL DEFAULT '0',
  `manual_title` text NOT NULL,
  `work_url` varchar(255) NOT NULL DEFAULT '',
  `judges` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `stallman_editions`
--


-- --------------------------------------------------------

--
-- Table structure for table `stallman_partecipants`
--

CREATE TABLE IF NOT EXISTS `stallman_partecipants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edition_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `subscription_date` int(11) NOT NULL DEFAULT '0',
  `work_url` varchar(255) NOT NULL DEFAULT '',
  `comments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=120 ;

--
-- Dumping data for table `stallman_partecipants`
--


-- --------------------------------------------------------

--
-- Table structure for table `tutorials`
--

CREATE TABLE IF NOT EXISTS `tutorials` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `dir_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `members_name` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `cache` longtext,
  `timestamp` int(11) DEFAULT '0',
  `old_text_format` tinyint(1) NOT NULL DEFAULT '0',
  `pro_votes` int(11) NOT NULL DEFAULT '0',
  `cons_votes` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `body` longtext,
  PRIMARY KEY (`id`),
  KEY `approved` (`approved`),
  KEY `dir_id` (`dir_id`),
  KEY `type` (`type`),
  KEY `members_name` (`members_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1181 ;

--
-- Dumping data for table `tutorials`
--


-- --------------------------------------------------------

--
-- Table structure for table `tutorials_categories`
--

CREATE TABLE IF NOT EXISTS `tutorials_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dir_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dir_id` (`dir_id`,`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tutorials_categories`
--

INSERT INTO `tutorials_categories` (`id`, `dir_id`, `name`) VALUES
(7, 1, 'Informatica'),
(11, 3, 'Linux'),
(21, 4, 'Internet'),
(5, 6, 'Sicurezza e OS'),
(29, 7, 'Protocolli'),
(8, 8, 'Hardware'),
(25, 9, 'Visual Basic'),
(3, 10, 'Java'),
(15, 11, 'PHP'),
(4, 12, 'Pascal'),
(16, 13, 'Perl'),
(24, 14, 'Windows'),
(26, 15, 'C'),
(10, 16, 'C++'),
(12, 17, 'Delphi'),
(6, 18, 'C#'),
(1, 19, 'Masterizzare CD'),
(13, 20, 'Masterizzare DVD'),
(20, 22, 'Files Immagine'),
(19, 23, 'Video Digitale'),
(27, 24, 'Mp3 e Audio'),
(14, 25, 'Prolog'),
(17, 26, 'Ruby'),
(28, 27, 'ASP'),
(23, 28, 'Python'),
(18, 29, 'Google'),
(22, 32, 'Ruby On Rails'),
(2, 38, 'Scheme'),
(9, 39, 'iPhone');

-- --------------------------------------------------------

--
-- Table structure for table `tutorials_comments`
--

CREATE TABLE IF NOT EXISTS `tutorials_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tutorial_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id` (`tutorial_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tutorials_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `usenet_groups`
--

CREATE TABLE IF NOT EXISTS `usenet_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `usenet_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `usenet_posts`
--

CREATE TABLE IF NOT EXISTS `usenet_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT '1',
  `messageid` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `post_date` int(11) NOT NULL DEFAULT '0',
  `post_from` varchar(255) NOT NULL DEFAULT '',
  `post_references` varchar(1200) DEFAULT NULL,
  `replyto` varchar(255) DEFAULT NULL,
  `contenttype` varchar(255) DEFAULT NULL,
  `contenttransfenc` varchar(255) DEFAULT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `subject` (`subject`),
  KEY `messageid` (`messageid`),
  KEY `post_references` (`post_references`(1000)),
  FULLTEXT KEY `body` (`body`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86275 ;

--
-- Dumping data for table `usenet_posts`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `os_browser` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `permission` int(11) DEFAULT NULL,
  `verified` int(11) DEFAULT NULL,
  `md5` varchar(255) DEFAULT NULL,
  `previous_login_timestamp` int(11) DEFAULT '0',
  `last_login_timestamp` int(11) DEFAULT '0',
  `signature` varchar(255) DEFAULT NULL,
  `last_login_ip` varchar(16) DEFAULT NULL,
  `biometric_hash` varchar(255) DEFAULT NULL,
  `disable_biometric` varchar(255) NOT NULL DEFAULT '',
  `wiki_enabled` tinyint(1) DEFAULT '1',
  `avatar` varchar(255) DEFAULT NULL,
  `banned` int(11) DEFAULT NULL,
  `banned_reason` text,
  `newsletter` tinyint(1) NOT NULL,
  `forum_votes_pro` int(11) NOT NULL DEFAULT '0',
  `forum_votes_cons` int(11) NOT NULL DEFAULT '0',
  `forum_post_count` int(11) NOT NULL DEFAULT '0',
  `requirepwdreset` tinyint(1) NOT NULL DEFAULT '0',
  `developerpermission` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `md5` (`md5`),
  KEY `user` (`user`),
  KEY `mail` (`mail`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17009 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `code`, `user`, `pass`, `mail`, `ip`, `os_browser`, `date`, `description`, `permission`, `verified`, `md5`, `previous_login_timestamp`, `last_login_timestamp`, `signature`, `last_login_ip`, `biometric_hash`, `disable_biometric`, `wiki_enabled`, `avatar`, `banned`, `banned_reason`, `newsletter`, `forum_votes_pro`, `forum_votes_cons`, `forum_post_count`, `requirepwdreset`, `developerpermission`) VALUES
(8, NULL, 'pierotofy', '', 'admin@pierotofy.it', NULL, NULL, '04/12/2003 15:12', '<font class=small color=yellow>Admin</font>', 0, 1, '2e0f9a29bed76d2e7c635eacb307e4d7', 1305916439, 1307643587, '[left]\r\nFai quello che ti piace, e fallo bene.\r\n\r\n[b]TheKaneB[/b]: [i]sta chat sta diventando un ritrovo di pazzi esaltati e scimmie ubriache %-)[/i]', '127.0.0.1', '', '', 0, 'pierotofy_1283542569.png', NULL, NULL, 1, 12, 2, 4089, 0, 2),
(17008, NULL, 'utente', '', 'pierotofy@libero.it', '127.0.0.1', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8', '04/09/2010 23:56', 'Normal User', 9, 1, 'a0cdd710cf4e43b2230da91aeb3bc12b', 1283644689, 1286656992, NULL, '127.0.0.1', NULL, '', 1, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wall_followers`
--

CREATE TABLE IF NOT EXISTS `wall_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `following_user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`following_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wall_followers`
--


-- --------------------------------------------------------

--
-- Table structure for table `wall_posts`
--

CREATE TABLE IF NOT EXISTS `wall_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `trusted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`timestamp`,`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wall_posts`
--

INSERT INTO `wall_posts` (`id`, `user_id`, `author_id`, `body`, `timestamp`, `type`, `trusted`) VALUES
(1, 8, 0, '<b><a href=''/pages/members/profile.php?uid=8''>pierotofy</a></b> ha commentato la news <a href=''http://localhost/pages/home/news/5590-news_di_esempio/''>News di esempio</a>', 1284941564, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wiki`
--

CREATE TABLE IF NOT EXISTS `wiki` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` int(11) DEFAULT NULL,
  `term` varchar(255) NOT NULL DEFAULT '',
  `text` text,
  `source` varchar(255) DEFAULT NULL,
  `feedback_pos` int(11) DEFAULT '0',
  `feedback_neg` int(11) DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `member_nick` varchar(255) DEFAULT NULL,
  `abbr_for` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3029 ;

--
-- Dumping data for table `wiki`
--

